from __future__ import annotations

import argparse
import os
from typing import Any, Dict, List, Optional, Tuple
import tempfile
from datetime import datetime

import gradio as gr
import pandas as pd
from sqlalchemy import create_engine, inspect, text

from monitor.data import generate_synthetic_data
from monitor.drift import detect_drift, identify_column_types
from monitor.viz import (
    plot_categorical_distributions,
    plot_numeric_distributions,
    plot_numeric_ecdf,
    plot_chi_square_contributions,
    plot_wasserstein_distance,
    plot_jensen_shannon_categorical,
    plot_euclidean_categorical,
)
from monitor.notifications import get_notification_service

TESTS_BY_TYPE: Dict[str, List[str]] = {
    "numerical": ["ks", "wasserstein", "psi"],
    "categorical": ["chi-square", "jensen-shannon", "euclidean", "psi"],
}


def _write_temp_file(name: str, data: bytes) -> str:
    tmpdir = tempfile.mkdtemp(prefix="drift_")
    path = os.path.join(tmpdir, name)
    with open(path, "wb") as f:
        f.write(data)
    return path


def _test_pg_connection(
    host: str, port: int, database: str, user: str, password: str
) -> Tuple[str, List[str]]:
    """Test PostgreSQL connection and return status + list of tables."""
    try:
        connection_string = (
            f"postgresql://{user}:{password}@{host}:{int(port)}/{database}"
        )
        engine = create_engine(connection_string)

        # Test connection
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))

        # Get tables
        inspector = inspect(engine)
        tables = inspector.get_table_names()

        if not tables:
            return "Connected successfully, but no tables found.", []

        return f"Connected successfully. Found {len(tables)} table(s).", tables
    except Exception as e:
        return f"Connection failed: {str(e)}", []


def _fetch_table_from_postgres(
    host: str, port: int, database: str, user: str, password: str, table: str
) -> pd.DataFrame:
    """Fetch all data from a PostgreSQL table."""
    try:
        connection_string = (
            f"postgresql://{user}:{password}@{host}:{int(port)}/{database}"
        )
        engine = create_engine(connection_string)

        query = f'SELECT * FROM "{table}"'
        df = pd.read_sql(query, engine)

        if df.empty:
            raise gr.Error(f"Table '{table}' is empty.")

        return df
    except Exception as e:
        raise gr.Error(f"Failed to fetch data from table '{table}': {str(e)}")


def _tests_for_types(selected_types: List[str], all_tests: List[str]) -> List[str]:
    out: set[str] = set()
    for t in selected_types:
        out.update(TESTS_BY_TYPE.get(t, []))
    # Fallback to all if none resolved
    return sorted(out) or sorted(all_tests)


def _create_metric_card(label: str, value: str, subtitle: str, color: str) -> str:
    """Create an HTML metric card with color."""
    return f"""
    <div class="dashboard-card {color}">
        <div class="metric-label">{label}</div>
        <div class="metric-value {color}">{value}</div>
        <div class="metric-subtitle">{subtitle}</div>
    </div>
    """


def _create_empty_cards() -> Tuple[str, str, str, str, str, str, str, str, str, str, str, str, str]:
    """Create empty dashboard cards with a warning to select data."""
    warning_card = _create_metric_card(
        "No Data", "—", "Select a data source below to begin", "blue"
    )
    return (warning_card, warning_card, warning_card, warning_card, warning_card,
            warning_card, warning_card, warning_card, warning_card, warning_card,
            warning_card, warning_card, warning_card)


def _compute_from_dfs(
    reference: pd.DataFrame,
    current: pd.DataFrame,
    alpha: float,
    js_threshold: float,
    psi_threshold: float,
    wasserstein_threshold: float,
    euclidean_threshold: float,
    bins: int,
    progress: gr.Progress = gr.Progress(),
) -> Tuple[
    str,
    str,
    str,
    pd.DataFrame,
    object,
    object,
    object,
    pd.DataFrame,
    Optional[str],
    Optional[str],
    pd.DataFrame,
    Dict[str, str],
    List[str],
    List[str],
    List[str],
    object,
    Any,
    str,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
]:
    progress(0, desc="Starting drift detection...")
    results = detect_drift(
        reference,
        current,
        alpha=alpha,
        js_threshold=js_threshold,
        psi_threshold=psi_threshold,
        wasserstein_threshold=wasserstein_threshold,
        euclidean_threshold=euclidean_threshold,
        bins=bins,
    )
    progress(0.5, desc="Computing metrics...")

    total_features = len(results["feature"].unique()) if not results.empty else 0
    drifted = (
        int(results.groupby("feature")["drift_detected"].any().sum())
        if not results.empty
        else 0
    )
    pct_drifted = 100.0 * drifted / max(total_features, 1)
    stable_features = total_features - drifted
    
    # Feature type counts
    numeric_cols, categorical_cols = identify_column_types(reference)
    num_numerical = len(numeric_cols)
    num_categorical = len(categorical_cols)
    
    # Statistical metrics
    total_tests = len(results) if not results.empty else 0
    p_values = results["p_value"].dropna() if not results.empty else pd.Series([])
    avg_p_value = float(p_values.mean()) if len(p_values) > 0 else 0.0
    max_statistic = float(results["statistic"].max()) if not results.empty else 0.0
    
    # Critical drift features (2+ tests showing drift)
    if not results.empty:
        drift_counts = results[results["drift_detected"]].groupby("feature").size()
        critical_drift = int((drift_counts >= 2).sum())
    else:
        critical_drift = 0
    
    # Send system notification if drift is detected
    if drifted > 0:
        notification_service = get_notification_service()
        notification_service.notify_drift_detected(
            total_features=total_features,
            drifted_features=drifted,
            critical_drift=critical_drift,
            drift_rate=pct_drifted / 100.0
        )
    
    # Data volume metrics
    ref_samples = len(reference)
    cur_samples = len(current)
    total_data_points = (ref_samples + cur_samples) * total_features

    # Create dashboard cards
    total_card = _create_metric_card(
        "Total Features", str(total_features), "Features analyzed", "blue"
    )

    drift_color = (
        "red" if pct_drifted > 50 else ("purple" if pct_drifted > 20 else "green")
    )
    drifted_card = _create_metric_card(
        "Features with Drift",
        str(drifted),
        f"{total_features - drifted} features stable",
        drift_color,
    )

    rate_color = (
        "red" if pct_drifted > 50 else ("purple" if pct_drifted > 20 else "green")
    )
    rate_card = _create_metric_card(
        "Drift Rate",
        f"{pct_drifted:.1f}%",
        "Threshold: KS/Chi-square uses alpha",
        rate_color,
    )
    
    # New cards
    stable_card = _create_metric_card(
        "Stable Features",
        str(stable_features),
        "No drift detected",
        "green" if stable_features > 0 else "blue"
    )
    
    numerical_card = _create_metric_card(
        "Numerical Features",
        str(num_numerical),
        "Continuous variables",
        "blue"
    )
    
    categorical_card = _create_metric_card(
        "Categorical Features",
        str(num_categorical),
        "Discrete variables",
        "blue"
    )
    
    critical_color = "red" if critical_drift > 0 else "green"
    critical_card = _create_metric_card(
        "Critical Drift",
        str(critical_drift),
        "Features with 2+ failed tests",
        critical_color
    )
    
    tests_card = _create_metric_card(
        "Total Tests Run",
        str(total_tests),
        "Statistical tests performed",
        "blue"
    )
    
    pval_color = "red" if avg_p_value < 0.05 else ("purple" if avg_p_value < 0.1 else "green")
    pval_card = _create_metric_card(
        "Avg P-Value",
        f"{avg_p_value:.4f}",
        "Significance tests only",
        pval_color
    )
    
    stat_color = "red" if max_statistic > 1.0 else "blue"
    stat_card = _create_metric_card(
        "Max Drift Statistic",
        f"{max_statistic:.2f}",
        "Highest value observed",
        stat_color
    )
    
    ref_card = _create_metric_card(
        "Reference Samples",
        f"{ref_samples:,}",
        "Baseline dataset",
        "blue"
    )
    
    cur_card = _create_metric_card(
        "Current Samples",
        f"{cur_samples:,}",
        "Monitored dataset",
        "blue"
    )
    
    datapoints_card = _create_metric_card(
        "Total Data Points",
        f"{total_data_points:,}",
        "Samples × Features",
        "blue"
    )

    if results.empty:
        counts = pd.DataFrame({"test": [], "total": [], "drifted": [], "rate": []})
    else:
        counts = (
            results.groupby(["test"])["drift_detected"]
            .agg(total="count", drifted="sum")
            .reset_index()
        )
        counts["rate"] = (counts["drifted"] / counts["total"]).round(3)

    feature_type_map: Dict[str, str] = (
        results.groupby("feature")["feature_type"].first().to_dict()
        if not results.empty
        else {}
    )
    all_features = (
        sorted(results["feature"].unique().tolist()) if not results.empty else []
    )
    all_types = (
        sorted(results["feature_type"].unique().tolist()) if not results.empty else []
    )
    all_tests = sorted(results["test"].unique().tolist()) if not results.empty else []

    progress(0.7, desc="Preparing results...")

    feat_filter_update = gr.update(choices=all_features, value=[])
    type_filter_update = gr.update(choices=all_types, value=all_types if all_types else [])
    test_filter_update = gr.update(choices=all_tests, value=all_tests if all_tests else [])

    # Format table with styling
    table_view = _format_dataframe_with_styling(results)

    progress(0.85, desc="Generating reports...")

    csv_path = _write_temp_file(
        "drift_report.csv", results.to_csv(index=False).encode("utf-8")
    )
    json_path = _write_temp_file(
        "drift_report.json", results.to_json(orient="records", indent=2).encode("utf-8")
    )

    progress(1.0, desc="Complete!")

    # Generate timestamp
    timestamp_str = f"Updated as of {datetime.now().strftime('%B %d, %Y at %I:%M %p')}"

    selected_feature_update = gr.update(
        choices=list(reference.columns),
        value=(list(reference.columns)[0] if len(reference.columns) else None),
    )
    if reference.shape[1] > 0:
        first_feature = reference.columns[0]
        numeric_cols, categorical_cols = identify_column_types(reference)
        if first_feature in numeric_cols:
            init_fig = plot_numeric_distributions(
                reference[first_feature], current[first_feature], bins=bins
            )
        else:
            init_fig = plot_categorical_distributions(
                reference[first_feature], current[first_feature]
            )
    else:
        init_fig = None

    # Generate comparison tables
    progress(0.8, desc="Generating comparison tables...")
    summary_stats_ref_table, summary_stats_cur_table = _create_summary_stats_table(reference, current)
    missing_values_ref_table, missing_values_cur_table = _create_missing_values_table(reference, current)
    data_types_ref_table, data_types_cur_table = _create_data_types_table(reference, current)
    categorical_stats_table = _create_categorical_stats_table(reference, current)
    
    progress(1.0, desc="Complete!")

    return (
        total_card,
        drifted_card,
        rate_card,
        stable_card,
        numerical_card,
        categorical_card,
        critical_card,
        tests_card,
        pval_card,
        stat_card,
        ref_card,
        cur_card,
        datapoints_card,
        counts,
        feat_filter_update,
        type_filter_update,
        test_filter_update,
        table_view,
        csv_path,
        json_path,
        results,
        feature_type_map,
        all_features,
        all_types,
        all_tests,
        selected_feature_update,
        init_fig,
        timestamp_str,
        summary_stats_ref_table,
        summary_stats_cur_table,
        missing_values_ref_table,
        missing_values_cur_table,
        data_types_ref_table,
        data_types_cur_table,
        categorical_stats_table,
    )


def _build_compute_response(
    reference: pd.DataFrame,
    current: pd.DataFrame,
    alpha: float,
    js_threshold: float,
    psi_threshold: float,
    wasserstein_threshold: float,
    euclidean_threshold: float,
    bins: int,
    progress: gr.Progress = gr.Progress(),
) -> Tuple[
    str,
    str,
    str,
    str,
    str,
    str,
    str,
    str,
    str,
    str,
    str,
    str,
    str,
    pd.DataFrame,
    object,
    object,
    object,
    pd.DataFrame,
    str,
    str,
    pd.DataFrame,
    Dict[str, str],
    List[str],
    List[str],
    List[str],
    object,
    Any,
    str,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
]:
    (
        total_card,
        drifted_card,
        rate_card,
        stable_card,
        numerical_card,
        categorical_card,
        critical_card,
        tests_card,
        pval_card,
        stat_card,
        ref_card,
        cur_card,
        datapoints_card,
        counts,
        feat_u,
        type_u,
        test_u,
        table_view,
        csv_b,
        json_b,
        results,
        feat_type_map,
        all_feats,
        all_types,
        all_tests,
        feature_u,
        init_fig,
        timestamp_str,
        summary_stats_ref_table,
        summary_stats_cur_table,
        missing_values_ref_table,
        missing_values_cur_table,
        data_types_ref_table,
        data_types_cur_table,
        categorical_stats_table,
    ) = _compute_from_dfs(
        reference,
        current,
        float(alpha),
        float(js_threshold),
        float(psi_threshold),
        float(wasserstein_threshold),
        float(euclidean_threshold),
        int(bins),
        progress,
    )
    return (
        total_card,
        drifted_card,
        rate_card,
        stable_card,
        numerical_card,
        categorical_card,
        critical_card,
        tests_card,
        pval_card,
        stat_card,
        ref_card,
        cur_card,
        datapoints_card,
        counts,
        feat_u,
        type_u,
        test_u,
        table_view,
        csv_b,
        json_b,
        results,
        feat_type_map,
        all_feats,
        all_types,
        all_tests,
        feature_u,
        init_fig,
        timestamp_str,
        summary_stats_ref_table,
        summary_stats_cur_table,
        missing_values_ref_table,
        missing_values_cur_table,
        data_types_ref_table,
        data_types_cur_table,
        categorical_stats_table,
        reference,
        current,
    )


def _recalculate_drift_flags(
    results: Optional[pd.DataFrame],
    alpha: float,
    wasserstein_threshold: float,
    js_threshold: float,
    euclidean_threshold: float,
    psi_threshold: float,
) -> pd.DataFrame:
    """
    Recalculate drift_detected flags based on new thresholds without recomputing statistics.
    """
    if results is None or len(results) == 0:
        return pd.DataFrame()

    updated = results.copy()

    # Update drift_detected based on test type and threshold
    for idx, row in updated.iterrows():
        test = row["test"]

        if test in ["ks", "chi-square"]:
            # p-value based tests
            updated.at[idx, "threshold"] = alpha
            updated.at[idx, "drift_detected"] = row["p_value"] < alpha
        elif test == "wasserstein":
            # Wasserstein uses its own threshold
            updated.at[idx, "threshold"] = wasserstein_threshold
            updated.at[idx, "drift_detected"] = (
                row["statistic"] >= wasserstein_threshold
            )
        elif test == "jensen-shannon":
            # JS uses its own threshold
            updated.at[idx, "threshold"] = js_threshold
            updated.at[idx, "drift_detected"] = row["statistic"] >= js_threshold
        elif test == "euclidean":
            # Euclidean uses its own threshold
            updated.at[idx, "threshold"] = euclidean_threshold
            updated.at[idx, "drift_detected"] = row["statistic"] >= euclidean_threshold
        elif test == "psi":
            # PSI uses its own threshold
            updated.at[idx, "threshold"] = psi_threshold
            updated.at[idx, "drift_detected"] = row["statistic"] >= psi_threshold

    return updated


def _update_thresholds_and_recalculate(
    results: Optional[pd.DataFrame],
    alpha: float,
    wasserstein_threshold: float,
    js_threshold: float,
    euclidean_threshold: float,
    psi_threshold: float,
    feat_filter: List[str],
    type_filter: List[str],
    test_filter: List[str],
) -> Tuple[pd.DataFrame, pd.DataFrame, Optional[str], Optional[str], pd.DataFrame]:
    """
    Update thresholds, recalculate drift flags, and apply filters.
    """
    if results is None or len(results) == 0:
        empty = pd.DataFrame()
        return empty, empty, None, None, empty

    # Recalculate drift flags with new thresholds
    updated_results = _recalculate_drift_flags(
        results,
        alpha,
        wasserstein_threshold,
        js_threshold,
        euclidean_threshold,
        psi_threshold,
    )

    # Recalculate counts
    counts = (
        updated_results.groupby(["test"])["drift_detected"]
        .agg(total="count", drifted="sum")
        .reset_index()
    )
    counts["rate"] = (counts["drifted"] / counts["total"]).round(3)

    # Apply filters
    filtered = updated_results.copy()
    if feat_filter:
        filtered = filtered[filtered["feature"].isin(feat_filter)]
    if type_filter:
        filtered = filtered[filtered["feature_type"].isin(type_filter)]
    if test_filter:
        filtered = filtered[filtered["test"].isin(test_filter)]

    if len(filtered) == 0:
        return counts, _format_dataframe_with_styling(filtered), None, None, updated_results

    # Format table with styling
    table_view = _format_dataframe_with_styling(filtered)

    csv_path = _write_temp_file(
        "drift_report.csv", filtered.to_csv(index=False).encode("utf-8")
    )
    json_path = _write_temp_file(
        "drift_report.json",
        filtered.to_json(orient="records", indent=2).encode("utf-8"),
    )

    return counts, table_view, csv_path, json_path, updated_results


def _create_summary_stats_table(reference: pd.DataFrame, current: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Create separate summary statistics tables for reference and current datasets."""
    numeric_cols, _ = identify_column_types(reference)
    
    if not numeric_cols:
        empty_msg = pd.DataFrame({"Message": ["No numerical columns found"]})
        return empty_msg, empty_msg
    
    ref_stats = reference[numeric_cols].describe().T
    cur_stats = current[numeric_cols].describe().T
    
    # Create reference table
    ref_table = pd.DataFrame({
        'feature': ref_stats.index,
        'count': ref_stats['count'].round(0).astype(int),
        'mean': ref_stats['mean'].round(4),
        'std': ref_stats['std'].round(4),
        'min': ref_stats['min'].round(4),
        '25%': ref_stats['25%'].round(4),
        '50%': ref_stats['50%'].round(4),
        '75%': ref_stats['75%'].round(4),
        'max': ref_stats['max'].round(4)
    })
    
    # Create current table
    cur_table = pd.DataFrame({
        'feature': cur_stats.index,
        'count': cur_stats['count'].round(0).astype(int),
        'mean': cur_stats['mean'].round(4),
        'std': cur_stats['std'].round(4),
        'min': cur_stats['min'].round(4),
        '25%': cur_stats['25%'].round(4),
        '50%': cur_stats['50%'].round(4),
        '75%': cur_stats['75%'].round(4),
        'max': cur_stats['max'].round(4),
        'mean_diff': (cur_stats['mean'] - ref_stats['mean']).round(4),
        'std_diff': (cur_stats['std'] - ref_stats['std']).round(4)
    })
    
    return ref_table, cur_table


def _create_missing_values_table(reference: pd.DataFrame, current: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Create separate missing values tables for reference and current datasets."""
    ref_missing = reference.isnull().sum()
    cur_missing = current.isnull().sum()
    
    ref_pct = (ref_missing / len(reference) * 100).round(2)
    cur_pct = (cur_missing / len(current) * 100).round(2)
    
    # Create reference table
    ref_table = pd.DataFrame({
        'feature': reference.columns,
        'missing_count': ref_missing.values,
        'missing_pct': ref_pct.values
    })
    
    # Create current table
    cur_table = pd.DataFrame({
        'feature': current.columns,
        'missing_count': cur_missing.values,
        'missing_pct': cur_pct.values,
        'missing_diff': (cur_missing - ref_missing).values,
        'pct_diff': (cur_pct - ref_pct).values
    })
    
    # Sort both tables by largest difference in missing values
    sort_order = abs(cur_missing - ref_missing).sort_values(ascending=False).index
    ref_table = ref_table.set_index('feature').reindex(sort_order).reset_index()
    cur_table = cur_table.set_index('feature').reindex(sort_order).reset_index()
    
    return ref_table, cur_table


def _create_data_types_table(reference: pd.DataFrame, current: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Create separate data types and unique values tables for reference and current datasets."""
    ref_data = []
    cur_data = []
    
    # Get all columns from both datasets
    all_cols = list(set(reference.columns) | set(current.columns))
    
    for col in all_cols:
        # Reference data
        if col in reference.columns:
            ref_dtype = str(reference[col].dtype)
            ref_unique = reference[col].nunique()
        else:
            ref_dtype = "Missing"
            ref_unique = 0
            
        ref_data.append({
            'feature': col,
            'dtype': ref_dtype,
            'unique_count': ref_unique
        })
        
        # Current data
        if col in current.columns:
            cur_dtype = str(current[col].dtype)
            cur_unique = current[col].nunique()
        else:
            cur_dtype = "Missing"
            cur_unique = 0
            
        cur_data.append({
            'feature': col,
            'dtype': cur_dtype,
            'unique_count': cur_unique,
            'dtype_match': ref_dtype == cur_dtype,
            'unique_diff': cur_unique - ref_unique
        })
    
    ref_table = pd.DataFrame(ref_data)
    cur_table = pd.DataFrame(cur_data)
    
    return ref_table, cur_table


def _create_categorical_stats_table(reference: pd.DataFrame, current: pd.DataFrame) -> pd.DataFrame:
    """Create a categorical statistics comparison table."""
    _, categorical_cols = identify_column_types(reference)
    
    if not categorical_cols:
        return pd.DataFrame({"Message": ["No categorical columns found"]})
    
    comparison_data = []
    
    for col in categorical_cols:
        if col not in current.columns:
            continue
            
        ref_top = reference[col].value_counts().head(3)
        cur_top = current[col].value_counts().head(3)
        
        ref_top_cat = ref_top.index[0] if len(ref_top) > 0 else "N/A"
        cur_top_cat = cur_top.index[0] if len(cur_top) > 0 else "N/A"
        
        ref_top_freq = ref_top.iloc[0] / len(reference) if len(ref_top) > 0 else 0
        cur_top_freq = cur_top.iloc[0] / len(current) if len(cur_top) > 0 else 0
        
        comparison_data.append({
            'feature': col,
            'ref_categories': reference[col].nunique(),
            'cur_categories': current[col].nunique(),
            'ref_top_category': ref_top_cat,
            'ref_top_frequency': f"{ref_top_freq:.3f}",
            'cur_top_category': cur_top_cat,
            'cur_top_frequency': f"{cur_top_freq:.3f}",
            'category_diff': current[col].nunique() - reference[col].nunique(),
            'top_freq_diff': f"{cur_top_freq - ref_top_freq:.3f}"
        })
    
    return pd.DataFrame(comparison_data)


def _format_dataframe_with_styling(df: pd.DataFrame) -> dict:
    """
    Format DataFrame with custom styling for drift detection.
    Rows with drift_detected=True get a light red background.
    The drift_detected and feature columns get bold red text for drifted rows.
    """
    if df is None or len(df) == 0:
        return df
    
    # Remove n_ref and n_cur columns from display
    display_cols = [col for col in df.columns if col not in ['n_ref', 'n_cur']]
    display_df = df[display_cols]
    
    # Convert to list of lists for data
    data = display_df.values.tolist()
    headers = display_df.columns.tolist()
    
    # Create styling array - same shape as data
    styling = []
    
    # Check if drift_detected column exists
    if 'drift_detected' in df.columns:
        for idx, row in df.iterrows():
            row_styling = []
            is_drifted = row['drift_detected']
            
            # Apply styling to each cell based on column and drift status
            for col in display_cols:
                if is_drifted:
                    # Base styling for drifted rows
                    base_style = "background-color: #ffe6e6; border-left: 3px solid #ff4444"
                    
                    # Add bold red text for drift_detected and feature columns
                    if col in ['drift_detected', 'feature']:
                        row_styling.append(f"{base_style}; color: #ff4444; font-weight: bold")
                    else:
                        row_styling.append(base_style)
                else:
                    row_styling.append("")
            
            styling.append(row_styling)
    else:
        # No drift_detected column, no styling
        styling = [["" for _ in range(len(display_cols))] for _ in range(len(data))]
    
    return {
        "data": data,
        "headers": headers,
        "metadata": {
            "styling": styling,
        },
    }


def _apply_filters(
    results: Optional[pd.DataFrame],
    feat_filter: List[str],
    type_filter: List[str],
    test_filter: List[str],
) -> Tuple[dict, Optional[str], Optional[str]]:
    if results is None or len(results) == 0:
        empty = pd.DataFrame()
        return _format_dataframe_with_styling(empty), None, None

    filtered = results.copy()
    if feat_filter:
        filtered = filtered[filtered["feature"].isin(feat_filter)]
    if type_filter:
        filtered = filtered[filtered["feature_type"].isin(type_filter)]
    if test_filter:
        filtered = filtered[filtered["test"].isin(test_filter)]

    if len(filtered) == 0:
        return _format_dataframe_with_styling(filtered), None, None

    table_view = _format_dataframe_with_styling(filtered)
    
    csv_path = _write_temp_file(
        "drift_report.csv", filtered.to_csv(index=False).encode("utf-8")
    )
    json_path = _write_temp_file(
        "drift_report.json",
        filtered.to_json(orient="records", indent=2).encode("utf-8"),
    )
    return table_view, csv_path, json_path


def _on_feat_change(
    selected_feats: List[str],
    feature_type_map: Dict[str, str],
    type_choices: List[str],
    test_choices: List[str],
) -> Tuple[object, object]:
    if not selected_feats:
        return gr.update(value=type_choices if type_choices else []), gr.update(
            choices=test_choices, value=test_choices if test_choices else []
        )
    selected_types = sorted(
        {feature_type_map.get(f) for f in selected_feats if f in feature_type_map}
    )
    test_for_types = _tests_for_types(selected_types, test_choices)
    return gr.update(value=selected_types), gr.update(
        choices=test_for_types, value=test_for_types if test_for_types else []
    )


def _on_type_change(selected_types: List[str], all_tests: List[str]) -> object:
    test_for_types = _tests_for_types(selected_types, all_tests)
    return gr.update(choices=test_for_types, value=test_for_types if test_for_types else [])


def _update_plot_type_choices(
    reference: Optional[pd.DataFrame],
    feature: Optional[str],
) -> object:
    """Update plot type choices based on selected feature type."""
    if reference is None or not feature or feature not in reference.columns:
        return gr.update()

    numeric_cols, categorical_cols = identify_column_types(reference)

    if feature in numeric_cols:
        # Numerical feature options
        return gr.update(
            choices=["Distribution", "CDF (KS test)", "Wasserstein"],
            value="Distribution",
        )
    else:
        # Categorical feature options
        return gr.update(
            choices=["Distribution", "Jensen-Shannon", "Euclidean", "Chi-square"],
            value="Distribution",
        )


def _render_plot(
    reference: Optional[pd.DataFrame],
    current: Optional[pd.DataFrame],
    feature: Optional[str],
    bins: int,
    plot_type: str,
) -> Any:
    if (
        reference is None
        or current is None
        or not feature
        or feature not in reference.columns
        or feature not in current.columns
    ):
        return None
    numeric_cols, categorical_cols = identify_column_types(reference)

    # Numerical features
    if feature in numeric_cols:
        if plot_type == "CDF (KS test)":
            return plot_numeric_ecdf(reference[feature], current[feature])
        if plot_type == "Wasserstein":
            return plot_wasserstein_distance(reference[feature], current[feature])
        # Default: Distribution (histogram)
        return plot_numeric_distributions(
            reference[feature], current[feature], bins=bins
        )

    # Categorical features
    if plot_type == "Jensen-Shannon":
        return plot_jensen_shannon_categorical(reference[feature], current[feature])
    if plot_type == "Euclidean":
        return plot_euclidean_categorical(reference[feature], current[feature])
    if plot_type == "Chi-square":
        return plot_chi_square_contributions(reference[feature], current[feature])
    # Default: Distribution (category proportions)
    return plot_categorical_distributions(reference[feature], current[feature])


with gr.Blocks(
    title="AI Factory Model Monitoring",
    theme=gr.themes.Soft(
        primary_hue="blue",
        secondary_hue="blue",
        radius_size="lg",
    ),
    fill_width=True,
    css="""
        @font-face {
            font-family: 'SC Prosper';
            src: url('data:font/woff2;charset=utf-8;base64,d09GMgABAAAAAGmIAA8AAAACHtgAAGknAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGlob1AAcg7UwBmAAh34RCAqD0HCC43oLiXgAATYCJAOTbAQgBZE1B6dCW2LicQd1w6ab1SFwr/M20qonlrDqBVGvW1xA3cWj2cbDsQXjmCmwcQCbJz/37P///z832Ygx4fgOHv5V1Va1tU2onHRxJ3VE79KzJ3vlkJTMkMG5pOa6Ra8xUnLxfUZWZId1ZOjlLOTuGwhxxCAI+lSpgkXzgS7LRGwbVt8cOQohohBRiChEFJegcHWrb/cAc3fYCZ3QiWI4qC/wUISRphVNoXUYni+Z79ktb/2Ul3LrbLrD53kuIMcjpC5JMwlJSJrHmkN7fsdUDAkZiDeTBbv6+dgqIdn+V7lO7W08mp/HHypNTU1b5ta6+G8tTVtmtua9za6IL0ziRdN42T+IQsXbIK2rIqAQUdh6FWC3xIeUoaFHefLEY/f//a7qPvc+KRrC0ayJQGRWRGcMjS/g/ESn35vZDdlkE5dQmko4yDmq/SSHB7v9czizzJkz11nz7DLmmWXMbyQzxT7unLHvHK7DOfuSrOyZIqkkpDF1jV8aeKr25F7P9P69REX6yBSGOuExKIRSLGzzEJLaGCJy1Ro8tHKzZdbDXQhEoxgkH0mceO/rtzU/utlnGrPd5KPJrymceCAPCJJApGlofdu+/dSfObO5vUkqndojfbIGS1XOz7Q+7qY4GyfI2R18VHGhG1Flyy5QVlIK5nYPWwqrIjKsRmM1Rt2VnWncPx6JiLrd3zwkCSUQvXjYBAFJ4JmuusFkr/JPnS8JIsv+n5c1Jz3xCLZLW69TtyArKRTAP4qD2Qw8Hxxb045ZmAcNBQsUP8TvkrlyfFmW7eAhvqSXPdnC/WzLlq/3r9Pv5wrsZOZK14qLduutgZpGaIecyJbhEehqGilZlJJuAaAFKhFl+Z2t9vzyFxU1qOa3/Gb/hpff3/LsoBM07hsBN8aOaUiZxtPj8xOCIJMDKuEWCH/fW5HREVJJUv5lqm+7Kwgj0BH4EXbGWDcjdIRDL9M5NJWn3327e4e9vUM4gGI4MAFK4FdgiPgJdwdKx2ANAxxyqiyCP8RUOaTSrty5dO/KRVekTES//GavIbsT8kbiWCGJUoc4tUQZ05OQlxQdSH2F+oVC4yQ88H/vjv938WkB+Z5UOAeucTzBhKz515mu8qETdspbX6dmLO0ANHXqjpMjn0+nk0P6QckQQLAlWaaA9GUrsijMtLUTIA9T385b152GtdvedetaplBPtEf4btVmwDSiyQlnF5AF2CIKAB+e/z9Vk3Pfz3wPUJLdNShYwFiqMsEi2AFSKlhFCwj9f6Zb8wJonxyXD+njRvj8NC79ElvfU0btE2fltE+bGvy948Z5Y2kYAP4fjWlRGNj0JZBgQB8fUGuJ5amva8wDTEDzozX77M7HIyuOhTlnNjVTU6HZHDAp7tevan4nvckBoAS2rFjJE0Id/Hci2PdDPiSszpwtquJEb3v7fx19xLedjXDI3UIQETtPRAaZiogEu361drFartB0RJmYsTDkd3XDmGY145aa3Dc326ZxsVQiIEsUxeR7P6b1z2yp2dzdby0JoqJYSESxU2Yg+f43nRGrmMeUppcyrAzvQxK5Hr76fSYAvrOMyKt7SOyMcoHwUenFgTTJ5p6JtRiEDMWxYboSI8bi486SAZRnBKPriRv7Er91aUkkEOFu/zwdxtDvs1/PQ9I/HZAh/d9yzZGLw7mmZx7ZcRvMPY/9hcHnO9J77spK/ES+JX6l9xK/0/vqbUm8s7qG3yVzxkmSIybYJZHwrYaxV/wQWv5rJHChW2j+BBKSsz9a/BFNcqbG/LFsrEny+GGSZ82zVePMbOwCLpdadH/R88XKizVPmmC/5MLiiMmBsG7ZNRscAI0/QAImk7uqmE1AcgE7f4c7G7LgUxtIDhyfQyyQGZIvlz9Z/vLpeBLfU8Z8cLlVnoAgMrp4hH6iY1AEvVIbBoLRmt1MPM65csmKH3R6DVuPwU2GrxofFvDUrbnHNG1OuzpEz+kMGCXY5kKFZ8TwxkysTe0+q6v+TsMZRVySTOKMwc1SZjbVIazq2sCWHXsO3Hg87ZXG+34czTlvruRByVcw0BlrQjNyW0DRql2HTl269ek3YNBQRto3asz4mJ5ths6mOfMWuoQVa93Apoe27dj11J59B44cb/wYMrZLOxc4cEUIbSLESETO/hQoUaFG4xPKa0rN31NLtEXKHvS0WcoVOKFUkRTNmLHmnNrC0sraxrZ7ilYe8qEVKlKiTA08gnpEJE3IKNp06BpU+3pCrz4DhgxP12Gc+OcL2vjqlu/kB+vPmTN2D0AHgh4DRlBMYTY+LFixYXfOeRwKxhkup8cdHjvHiw8/AYKECBOJjuzTpRcbp2fLjn0dql5SncSZCy9I3vGxf771l8tXo2HK0ebW0/nhcwnRg3M27va4zEyqr2z+hsbwKaPjjO+z+oENbNlN7dM4/MCNR3LKFL1ceVDyFSzRZypune1rqtsMshYUrdp16NSlW59+AwYNjemzzWbobJozb6FLWLHWDWx6aNuOXU/t2XfgyPHGj7PDsF3KucCBa6p5dmrY2X50avrUA2EB8WAype9mKVfghFJFUjRjxppzagvq3JQuQ6as5tA85EMrVKREGeRq4BHUIyJpQkbRpkPXGLGxMDFPcVu2O44Ad3d3lyRJkjsAAAqYKfMItXrW5kttxY59HeilxolzXcQLkvfTl9EuWjaH531mY918Z3LhDMcVgTuH+FwSbSqTldxRSkO1Bi0K57ruU7YfIVat2bBlN+zvcGjD5Q2u1G1xr4d4rvZ6BfIp71F8U/lrdcBSsXVjIf1sQc4Zq9xLHpR8BVP0vyGAORtVpVoNHPyUcEbQdGatGVkLilbtOnTq0j3unt3QR/sxYNBQRs6ijBoznokzqqkxfQZmqs7KnHkLWTy7YcmyFWZtsWabje6U3fba76DDjvZYbb8n5MApR8443vv2dNC9qWcYL4UhrDNs7RrbpRwSZZhrV12Wbsx7k7p86JZUB92T6XVtWXyZyImiQIkKNRpTTTRaqODRU8qA0TBlzbyqxbdhqZJVG9akZoanaAGRWDJlWKWsZXIFTihVJEUzZqw5p7awtLK2se2+FVwe8qEVKlKiTA08gnpEJE3IKNp06BpUUXpCrz4DhgxnFNW4SdOZgTC7eh3cG7oSFpywvlxLmsm+muk7/bEfv0m/5NTv/tnlL+nfODvrB4AOBD0GjKCYwuzisGDFht0553Eox5zhYn3c4aF7UjJyVhSUKKqo3Tgx4iRIukAKjDR5ChQpUaZClRp1GtHBeo5PMHrGsWF9tuzYDwe6l3LWS+LEmUu9BMk7PqLO909+qOev9C7buWjwjnRPGvTfQ9isG9dScomUoAUeqzts2LLjwI3HZeRjVi3xncQ/RmySYDHnrZJqNXDwbUJzyWhB0apdh05duvXpN2DQUEbOlowaM56JM4ypzmDOQhbP9lvqclqxas26jW7KQ9t27Hpqr89l3wsHDh31pdaOd4V1d2zYnXMeR7mUC2fHgZGJ3NlSFChRoUZjqXWWFPgZJlPF/GwpVg15N0wiEnW2k27nuJKkzczVlta29tDIkw+tUJESZWrgEdQjImlCRtGmQ1eolvTo1WfAkOGMwhg3aTozSs1mDs3i9D4SGuu7P2tnuwegA0GPASMoJoXlwh19xDOuDWzZzfbdpB07duzYsWPH0hHd9IPhr6UlCg+obGwsOcfg+g93DnH2JNg89oJ02M30b7PXcg5q82q2iKVH68Xsfr1rm3cvWkwjnxfQV+kySoauzyrOBP4fgUwS1Sd0b5160n137OwmPnF+cwBYTz+0R/3SGQ7JByQffjWpZ93/Kggliuqc+jx3TnumYwAj85XnO0lbz+LYGa+xK8Eokt4XAAD+jvjknIeFIPGz64MBAA4ns5+6Hvhj6favaZuQOONxx5NJpnqHXiKDJIapI5jfGy9lcoD9D5DDDWRkZGRk5PrNy6WmV2fD/LET8VVJxL6rUglGmsxSE3XaSqfTomtg+gyLqFgJbijCE4m8/8SIEy9BkhTX3ZAuMyNKN2bC1HQ9/E78YV/mr9lbpx3z7mPBig27c87jmDmzgYaGhoaGhoaGhox8RG9aKT1rA+dArg9LPDroYkDm0OoGIbRSs/7n1UInERQbTly4iZMgQ5Y8RarUqNOiDU6HHn0GDBkxZi9Wuhy58qDkK1ChSrUaOHgEdeo1ILqFZNqsefc98M0PP536Y3D/Cqfb68cRAOTwBCKJTKHS6ByEQIzJFISKYljOwsrGf7eNGDNhyoxZc+YtWLRk2br7lJjNg9ev/g1odK0aHciyBwOwvbGXRIa4ext+9gmw81qs1z9qryOj7VMnI95uCDDubPsAkEtVT/TVQwoqbfg+0CLJ7do+qLRMQO6F/V7e5mvmQvFTxeqaux+jtSP/o4Xm2pXFtumvI2KHJngiZEk2ZRGYIYRhCzCVt7/zHfeJJssxvdMoAr/3+9YpmX0yoqQ56IxynB5GpN2Kn61lyqmdtDp5cfmhOrpFxQ6l+S3CNu9Nu3ZcRKgcETSCfHIZf2+2LeNupBUyUGbe4Rc6HoXt5frgW9Kf0HfG71g796dj2E/y7BPz4wjFf5RDF6ZlkzOqk+7gZaB7jBPfhO0FgyClxOZ39Z5G77oFepRxmnW2MkR12Kiqy1MdpF8sM5Gm0lMyzbG+6SGdVlMfn9QHTl0ID5m+nW2VGfZzJ5HPaAGQQrc8P8/VAprUiHEal/ml6YbJYj803o4axvyfdiaHoL+rhyrmuULRGVzaT8/a78xg0Q4LAl/vEH+Bfs5mmWm0g/oalXPJvU1CGadcbysgR2G/UF99FDxUB0E9NS18bAtt8zuIboMSSEyU+iAhJEFp2gC9KXJJfWBhD0GFBYldFUzDDCooHxBcpHCOczEiteGE8NkvScpP+kLkqO3iocGdNt9FlarY5soE5mK7thXU2yuzrK3eKlayvRgXOmzXbCmkH8bgYnTEA4jX4bb0+QuHEq0FCFdhobAPGu5NYnNz+xkyOhR9Hd18wev8SkoPaLfxknAp3lvq3eDcCp9KbYMP5b0+RD0+Ts423WwMDFUajNKWat1rarO3CXI/dEQ/HmeewUv0Bk/3w6oMU5MEMbjN3o9QOJVc5/BqSw1Z9ULdRa62ot+bQYdDR0hBhCJ+ir7trL2C2MMckBzRORNwQ3Bnw4OcN5Ivkh8lf3wBZAIRgkmFYgsjEY8rEU0KlvTqZcrCkocjH08xsRIiZkItjIZrMKEAnTlQ84VYUAzq9R+DN+Ex+AARvU8urL7F6Luys+jG6HcsluOyksgqyBrIOsgG2EZcm2CbcW2BbcW1DbYd1w6knVR2Ie1BtxfNPnT70RxAdxDNIXSH0RxBdxTNMQInCJwicIbAeSwXsdxB7x56D0h7SNIj/J7g9wy/57NyILEA8jACVhgFrABW2IAMF5DhAzJC6BFBixhleOBEijJ8cCJHGQE4UcCPEl4o+FHBixp+NPCihR8dvOiRRQpZpJFFFiIOEHGCiAtE3CDiAREvpNFCHG3Y8UUUHdjxRxI9hNFHEgOEMUQSI4QxAScKfqLhJQZZgpEmBHFCkSYMccKRJgJxIkFpBKUZlFZQ2kHpBKUblF5Q+kEZBGUYlFFQ3gKSd4DkPSD5AEg+ApJPgOQzIPkCSL4Ckm+A5Dsg+R5IfoQ+P0Of/2HNIlwZgzXLYc3Kwz7hLMojNJlHnQW0WUSTJdRZRpt1FLmPMZsY8gPm3IcpTxHIP9gqelTDU5FC1ZVWl6r2qFUj+xaOqF/1oAYCbjD0hgaCRjQKbvQF0VjYjUMyNtCaDLMpMJoKtyUIJ7pOV0YBobeW0qfm19QKMtJAkKu0PSAHRUZ9ya9qjo6pBcRo33gpMI8QSWXFCEuaPh8vDEEmhwAdWPQZzMUDr/fKwitFbXwTlwDYM2KITmy2MsCz88TvZ7BnlGKlMEJAl57IlwsC3VpToeaiVbtYA0I3mz+QiyMvFBO8bRp6uggfG+tCIR5IFZuO8b7A7oBu3N55BPSKQdQrLa0RcS4N3QNS1o9bkVNcRNkx/mLqNCm83Ea/q8xm5E8UE2j/R89MjHpm9IwjsLYarUlxGct+oyijvHAB7A+OwPdIeNEoXmIt3b/4CiiqQRq2H3HkrAGUP8jgsVOYOPESpUjvnOLZcmj/4sVKmEdsvw0aRiGsIsXjtublwbVp16FTl2539ek3YNCQCZNWDuJ+OhtstMlmW2y1zXY77LTLHnvts98BBx1y2Hh/Zs9zLxx66bW3ozvrly46c3Wx6Tfk1eXT5df/sGkMFocnEElkCpVGZzCHfLK2bH39vcFoMrewsvMw+pPUMvLaEv3T2cuTD61QkRJlqtXAwatFUKdeA6JbSBo1adaiVbvOseGaR/XP2TeUhhy+0FgcnkAkkSlUGp3BBCzI5kikMrlCOXY80dhobmnjzv0I8tcNTV09fUMjz158ygPhIehr/N5PivDhR4eBzbce63xz/XtDuUgYWRDoYz3d7JuPIXGMCebTROen+Vl+nl/kl/mVdWEPuCLxHBidCCKCn6evhkRHhoPkvzPtGtz8Pw4EOdFxwdEADZRQBQESFLoGvXHXQmLB0DWM78cTEtQ1wGxC0tUEVwK06ff2zvM6tVEYsEWHGiUq5FhBoZgbkXwudp7+TwasL0OBMi+qUo+sS59Rs7bY44gzrrjjTxgQF0kjGukoRztGQSQlOTGnJi3pyUhmUhZ8SGlDByRlCCA1ogPLBz24TrSzH+aPLnlZXqEJcKn0v8PiPifnFVbEcm99+YrdZ+I/AATIO29CQN69GCEg721wkW/r+zfbB7vJH/XDR/SjY+zjGXlFPzndPl1FPtbPrrXPt5Kf6hf32pcHyL/tqwVuNbeWW2+6Ubr9frXZ9jGIPMzPlfNrrfPbYX739/lLzvt//3iHr3cApHIHzY83vXDvDKKGx0Q3r4G91ODaNLQuzW3tyyrFu0ra254G1L7+tatfbRtS5wbVqeF1b2QLGtH8RrWw0S1qTIsbW1NL68t4WrPbD/EglFbrs8reP+W0m2gVuZPMhYp7j32KU5+GdKcnoxlLdnJSmrJUpqqaZpXzMzvTle5Qcy/DGct4Tk6oUpVrQPsgZhxqRg7c+AgSIU6KLAVwdjcINjiVsO6pgvVMNZw9Dft9Qv/ehvv3NcK/v5H+A43yHex/sWbVbN2JUhrg0Ay7f3K15MSLve/jIjW9nqd1uLgpgtq2tEGkadzvKHYHcyKlAFaiQWMrDEusFNbSmTmrUydYtx4hBg0KM2KMqQl4Ft43xNt/VvTZZr8FT5z0ppduqPfVN+1+RM/3Lbzkmk3WbiQgZR4mOHWejG11BaPejISLJlMS3pSnIpLBhRSpNKcjyrmdoWi3ZpfJP+HpmGV3toLIvuzGOofzPPY5mYM45lzexCk3TzCupXohabWubHIqX43kF154yhrUmrzWiDbm7Txajnekox2Qvy8mghhMbiV1patdQ5eh+FyYEcQoZSeanvS0Z+gZewzqc/FCTBCjmjlDpQIQjGCIfi9wQYx6bmKSRkiyomqIfy8KQYyGZmZ2U4jiJM0yJL8XpiBGSy+zyMCAaV7WbX9C6ntxCWJ0NcOyyQFiUfPI323+uwAAAK87G7uzo23qB/yndOZjhyEABCMohhMkxeN6W10IAIxISk78Kfx5h4QkK6qmG6Zl+/juXhcDACuIcboZbyVEcZJmeVFWdZPBBC66IAC4CGKc78YVWAAgGEExnCApmmEx3HRRADALYpxwxxeSkGRF1XTDtGzH9TQ8dGEA0AUxzvjrEEmI4iTN8qKs6qbt+hleujgAGIIYQ471iG1M87Ju+3Fe9/N+/+kNH10gAGDkghhjnnWxAIQJZVxIpY11vm4wOl0kAIQgxqBrfZwi5VJbH3Ptc9+/H70x6EIBYBG0GPUN4jxjZi7jOptG72fSaH8geHsoAIi6wkdOFVWFkNM/tWvcd4ReEQRJfW8lgJKicOmDYNXCVcbT7pcBDpHVoh46pMQQZoxMHnt6THtguUcMDw6jsLPboG492ZPtPMpOHmcXhuaIqkcS7LoPEpvnU4xGqtlFsXWRqNG9KYcuktkYHd+YQ3QMIvv+MlYICDWTFF778zBbsQFbsb+Zt2yei6pmQytAkW0pY839FDOGAW5ujnhGbrAMJJAk6dVdLjml4O9i4cuXHoJF+kiiVJE0PB5qnDa1opWtanVrWtu61rehjTBMSAiiuyMIOf6QMoxgsvW4Bjy4ff1+pGZq3F/yIWD/L4DBNR74bgzRCrz/HJPpfyb05ejeL9cAdBcg83f9BKxBZg+Luwpkln99KKT/1JE5AJwvAo0XnhF/RDe2GcnraUxPRarbhe4NDASb4BKqATbID1VD+zA6TC4yXe2nfQgBChiA4EEBExz0bfp+/Xf6H/T/GiQWWhmSUoulliGPChoY48VYZqy23fT3rzzuGbCQ3qcGop+LeT2k3K5gdTvfxwMgZsLtL7fTU/upXgISaAAiMuKumb3i91dcml6F5I/IzOkZ991z1606I1ae4vRi8//sf/H/nP45/rv0z/SZ3jP40+W/A3/Jfxu/wk4dHS4d9Bx0H3QddB60Hdw6wB2UHAQfXDnQOFA/kH6x8mLsRe/+/v7D/Qf79/dX95f2x/Yb9wv3C57BlBw2pTkn7zPkfu5M2YD+2CsGVem4cwZIDTFOO0gzMJcIzsRve5GYhJSMnBUFJYqKmoaWjp6BkTUbtuym9sOd7HHhOrufz5PXPMyR/npxYcJFiBQlWozYmf7wBNdNkixlxOVLlzHfH5Gr2y5QqEgx06R/bZcqU64CLDsLA6sSHlGzJmQULVq169ShS7fbqHrcka1fHz7kx8OoEWPGs6JTtRoN2arPZ+I15bhejblkDiGvdeVyPqgD+VGOcpjAXNBsKKW+NSxbiNaci3HeAmcbzjaVJqDgvqOz8lGLWZqXb7b+zUcr08mDPNOberIvW9Wf9VnOhilFchUrVKpMuZJ5BavmszeXLavzNTZJ1ZHEJCXZQNKSkgQgU/k+t1eAL/uD8e/A5DCw1z8EJ/4XzRHAhn7CxPOmbcLvK8K1Wxs8EDvmqY/zidSGeAYhzwbqKI43gBEH8RbEQ7YO3kjC3vZuWuwrZDxKlMh3QYYEJHVIl4ZgRlHsgY56KdEeAWLHXYMa0vFoEFwgFVGGzt39/mBC3+OYM8Mk4R9xKBFmSTzOi6wQGsjz2BocwWSPCwvXEcvfnMCgQtTbYSAoKwn+Kz9pEHu1ZC1ecgDDcYLCVohb6ozxWCmoTolEC+5NsrANAmI4vX/nHGqAqQAHvhAs5Q0xfmZc/2WskV59smdv6dA6GlkpgOz1pco0l3xooZ7EzKR5WC2L9fwxj6QsOSML0Nm5doaMg07QiNdOIs66lm8HUH8RMfL1/RbVdNwO3YBfF9Uxr0wpzd2tQElsH6vgntICzGVeP8C4QyYkKAqq6tExztM/EBSqEqhvStkvLfKDrVzPGKY6vkzOBeOUcVqEwvIbnRoJCqKIkpUmf0z1O0I0kqLqRusOAlU8GQ7GEDYipsmzmZEzBgZBM2Mxc9vinZa16frW6RVxYJVDVh58bBQtHbR25XJ/iHVkjJPc9/FJhBL7nnLQTovzZPwE6OuoB+6OKEik2ZiT7v0ziaTMYhQq/eR7zvGBDFejkCyYMAykWWQm/qC2g5dXougZPBUgGskLf8Rb+ShvX/7D1UkpR+clRo6BrUHrqDqA/djbd6KyW5GsWpAxsXQ6nrbxdv+ItyBw1ESMSUmPeilIXJNU9RuSxt2n6c2ybiVDtxF1ZFKVrM/IHUifN8XYsePAQRVmP7H8QiYi5NhR4CAGk3H6+XR6kI3YkxBCDsixo8BBDCZ5uHCI3hkGm/UZeQxCWyPGAzsOHFRhziKehm2HBnIUKIhBJA/axnxUccP98dHxm9/jFvcb70RBLswcxXOUyEAzazRqLoFgtI96qSmhd7vPLe2sc3tMAKbpSvx4nlXzs1+ZCeRzv+4+/iaX6u3SIAZKaYVDvdcqyqF7MSdPVlxB1UoUqKJQ9sfotaD5cUMNN9RQY9HooxCWtJm9Sq+qvSrbKO7631TIyVJFtYpWFiluG24yRImwHdk8in0ySUozsRSMZRIvmiqH8LV2EmAxdejZafDGQmaGiBgUgShqL1FZhSsh0Dh5KCSkK9PI8F6Q92/UxTCcrn1NMjaQTK6Xcj0lFfJUQILUoIFumKsCDDhn+e7F7OlLil3thwOKUHDr/AxHNln/wWy1pNFbpEkGYaEayxjHKJyFyidRnCKQsSOXL48ql4oaKDou1qSxuDL8qDO4skIQrAPosFao1Gyy1rIugGwDKlUUmfJUQFT/NpvtcWEbP8gbMcRcRUfPNlyncCXuR6hgZ8g0TDeC7tBpATlVzJ453eWeltLRgyoIvD9taO8UnHgMus7315euq6jYBKFTn4u19jxJ8XFwOPGPEhwfhsdH0YSlgaYUjkmGk+C4pq+/hR4IBQG1uCjLM+2z4CkaH1R1Nen4msYWcNVCN6UCVbcuwofiWDPs3H7W7mndc//A+SO4CjlU4IJ9UimasshgW9HQnyrCpFfrRyWtOkg00Bww5Uog9qQyB1j01IVOfQ9cI9LM4oSnRqhzuBIrmmfk1gABVZeUOfJAXKxN/7B30RqLtsmUzDfRPlum7ebeqck5rrpMjJWvaq8TnCn24QoehUt/o8WGsJvZOspQCEq7wsKD/Co5F9evCX3b93F05UcVwioNM4nUhOEGnRbqlI+rwKbjSe0h1lXNEGKPT8iknCoTZFF19lDlp6D+qFxUekm44u/tJCH7d+w4cmNkXaglsdNc+UVQSMPh1UCptFYSn3NqGyfnDDpsfHc/zwW0xKpJetvcj8ByyznPh05zhD1wLXVq+v2h+J8wjvt7ko00wpRCDe2BhUyWZ5MmJj2pzWzxh3gbtmmrVB2T/bIFPaYbmmEAMiWLLeSaxm393XmbuHTVR6hTxt/ewBU1Se9PPB3g01yYWrhKlJ2ZATQYLcWh/C+kUxy1z9koL5Q8is1ERRe4rC90u63sdiN0WvDMPNMtr+kPWNJko+xqpG3F8KBPvdIjTYDX7U4y4bOczAvSnLNHgm1uz5Fv0WJFc3Ytt9AuulbY4YEY5gk7ILUDuhm/KoXDJ7nUV0raEENgStATKm/l+399r7AtDbLMQG04cHjZRiNgpxpUOA+I3GL5kHoLm7S1NBPYUuk5WMOWbintnytlD7cri6OKYHTNOm/8KFRxC3h6oMFo20SNLLRPw6pf1i1xqPUH9g78z6J96p2HhHJMgbr9zDce6xmlC5LTMgP7BJhCDB8C/VMUehpq7tD6TEWriM8xXPooM6DgE6VGuzvhQx4ZNRyEri25LPFQNtiOExhPTAvWiH6HXzbki+E+GQ5Iq0eKbJcsB74AGVQmtlg5y/knQYM3S3E1o+lVE012VtIAA3aFl1+FmmxWhouNXS5mCQHWyNB1Wu5IaIFMiaAGm5aQyiLgGQr6NQMNYA7wAC+UwzJWOSyHo45ojynhlgKKzrw9To/T/31hR5CJghSrM4ID18j8MOpw5XzpvwEOGIZ6Mk0PW6hFYzlMjD46yZCudUmaae6A9J0V9kmL/E1XAEaXFcYWuud1vDXaKqqnDSo2+UHbgTtP5O62+r88nWxKoDL5vcyxBiYaVAq8acztQ+lu9QGi9jsijCetqA3v7A7TtK2ZZZRO6f07ypfjcHzBeAn2Yt8WT0twhKbRoRcywArc/yvjBWEueR7HzdzIPHCzzcCZsZNj6ktX7BGjq1+hcMZVSSnKMpNOYHJWJyljajJRtn5l6aZvZQvUwx6KyKe1ruj74rjHNZ9lpIDJ05djNqPplXe1KjF3B6kGBBTuiuaUhinvhwDc7Ksz9sARilcuw6u4SMEY7DilQwA3T/rDlPitXsJgmdcjILm8VDoa+jgONe+m1gbqGwjFShE/7zamtdoFS4/xUvqvGjFo41rcE7/Fg1Dlm7zuopOOZnmzq/zEwp5r3n55d0ddyjhe99Cnq4dOhHMckHrOReo5BlLrKVMFvirpiGXg7OULqF+tv/GrmZA9awfw4yIHbLXn+7tT5kaquYvKO1LW93B1n6i8I5dKAd7+RY9NvSuHbJ+hiMr9DNdGT1rPMvwVzGbh3sFjM3bgd3rScMyZhct+m9pNMpryUQ+zExzuV5ZYdJ5EbsmReSXd+yQ5xyamelsLbs9SPI1A7i4JfGfpz9Iwm0XTLEgZbPYZ9zHqQsK/JRHF62jJuIOzjFPxfE2aVHbw9yvWR/jqh4Tfcot7rb00l4cAlMA2BwAwQ9G9k8HraIyK9IH4c7FJlRUZ/aEm8LgP3Z0VrEe3nHCAsDsw1KuNTBdt55+8SHP+Qu2O+8h70V2ZH/xRYnfu01sSTa1aHKBZ/Ea1VJcTx7XahOX2LCvp1Ormfzcrah8TbUTHJeLMqSM7UFB3NPdtRMta53RNEneRJs4j5ZG36hCT2LZJ+UxU0aV8og0J/y7rjFH8GIiGReSvPU+WCrjS6OcpO7ivpweeTw54pA27wGg3XVEj1Ql/4Zta4UF63k7sW2a0cJKKlZhn2+lS2aRzu6ss/MgXpzTHrm/z7pG3lmMcLk5Ce6+5seJdHxiUTHdS5ytnfgOavC+oDZO41FCY54efO37bUiDdfVfLXk68PW4kfF/M1WMWLikul5In3XYvlqWsvjvXMpVyQmpx/caxlY49Oxu9KPJiwMXUIRqJfOMxjiiINlrsRyWBgfx88o2M4xUw9Qpq23YZNPF3f1AQEODWSJlERdDvmXy4rRoqBkJhrhMeWQ4JsNibdGpVulB3/NyqXoeu4JqP4Az2hdbuX//Uiyvq2ZExnidx/3dsWN9CB2cUYJRZfIZzIbJYcRT8wPNIAmIYJwnguyenGPk0Di7lXbrG1Zs6We+AZCth5vZceYjAk/BphWcOMiOHXyw3qgeOODB5D8yDkdQsTIKWsU967qsFm5BOAdydfg+qSI+63HlXYlgBBcnfo5Ke/gFykkoCQ3seHCtFgj3LkwCPzjA/aCOrDS4Chp9wgWIMDsE5s9M8kAjf8MDOZJIPFEp/Cxd8gLJpAxsxJ45Y801u+GCOTEtvzPZFZJN1DIcW+xb+qaImxDKGOQH3Jh5JXyTSVcuiSZaacw/U6zc5iuULLTeknHg53IBDRDD2kZM+mpxihBTENRVaVBjlamjlfn/nLOfQNp5lCk6ySzUwZzGlZbfzVi0e9Dp/8bZmtU0vll1rvFJQ7q3g+YLBKi6rVET7yYlZy9KjNLWLYF1ZaA4GFNUwdnCIUQGjx43TuYeHWIm1dnMRDCSVr1H9Ncrhjm/IN5phO9jtigJGoz5ML0IjQdgiFeWwqDRnKc5Hl7KQyd8jQAttFGRPyuR0GZRKSK0ymWXzpWre1xbzJWiSg2DMnBkClhHUG/436bntSVZ5g4PPgQmh3sAJtOXmwbsJUfPWWih9ROnSlr1eePtIaK8+wmaBSewrG5f60dhuvWiymqyp218a5NCXfnZCZy4G1g7yetum/a1r8TAa9mUw8hlIJ2VabH9qySq7X3qX4I01sM9T3wG5vrxkuvQ4QXBC12vN6ykL21vJK9jTIHtldohN+atkLq+0eufAhngTRY14jNtiYmLR+yGzSZWgXs72mJGfDCjPMhINvO5UNCfLV9d1tr9KBHIyQaFa+I9k/qOZwB8+v3jzkIOmGzlmZJRcquB2SutZKAUUUgwz06azx2r/1OpSiXeF9241L7p1NU65dndR8ELFVdaRda3g0w4/UReRVygpnJs6/+40HznPFpQuBQekuQlw5UMtQ+9jU2Qdu66HQjbnWhqe7Pawj4IBi+6dAa3CexVHGAO3esP5LJi37EvMsjuzwwspzT9byg8JGDdXQ0tuiJeaV/5bqmW0EhNOsgbBCiKhzjf10b8FkWZskUNeRIIXLfJHRuXJG8taGH9Hnova0OvGQrK8QjhWLFyAEBiO96PdC1p0mrkkenpA7xNtCFxkRBBePBdewpWLE2XVdlNYCxeSK6ZgO6JxrSPOfM/FcHEBwv9DKdPNoZeGYvymDGEVWuTESjkEhGiZN4ZBAAgkWW5I22K0KLahiOo9IeMEGJM/lUKyvEowJljKdCIWvL1ROoBcLl6SdJaGO9ZiqcqFNzA/siQuF4K5/lFlm0aHFMFPO+BpJFW1GMGkmpOQSF880q0/wmtIlW/srm9TWw9XxnjK4SLxCERrC11fWFreNUpx+dCBxpYQ7S3q8XCej4QLGOU0XoNfyXlz/p4eLaWo0TgsED5AxPBi35N/UVxba/VgLh62NGRRTwcjfvvwkPm8U+5YeueeL58SyPOdsLZxMr5uOPFSoTtjClgviyOz9LW1vUOguRDFtto6RvuH3pHtM9ZyidACuCRaaesijGFDFTLtrqFwZwU9vRDx1R0IDw4YCqY46DR7AuP4kxaMfyNNzjyVyuL4hSF89ElgBYDtoMQyOMP3OKND0kIbgaej8fR/fj5Iy8ng4GH2F45AcvZJMyAKSxIA1cO5Y9nwEFj5T6BAaHdf5qBDFSHvQBMR+j+QicN/ehsbqL7+uLqEzr0fF78g7KfbCqSxWSyegxmln3Jn83PFub8fzAr9jFLn38+KH2ugpm7vw+X7kPvX5y3G7COo7kl61Ii/XlUI73kJGlGiDvZUyAX2+3f3XbftbZ+uUCQnToiTz9ErEWq5JnYQe1cIAJKEOOMcBVXFyq5fkzb5SMP8ZLuPVPnuU3v3opJF5ho2Pz7E5VuAIata4Yql4NmkGIJcMwJslRwjVpoZNv8mGEcMl/glDRZfS2tjcX12lqGB9jSz0CyEMg47vIPFVZ21Y2VBk/l5ZrstoCNV6tOh7DLeQ0ZJvEZ6MDCmj3/ZROvn21TEQ4080AHfEkMY3Mw92Okd0BIWXyykcBZM/OyY8WyE2OlradxXmkR2pW64fnDlxck3J1Wn2rvn7p66efVhs9ntmnDi5evXb5+5f6a+XI05fe/0rWuPTG9hhn2TbDWFG960qPlPSAbXSLUSxQJrRHjEoVhDERpxhQbkgm/cYj1LpxrBCbWxROXr0FpTtFluFt78A0BeN6m62CdMOifv/pW5+8o9KUg76DqziIXqSShWRRjyRN0hJivm4RGW9QigU0gJXeoAAVXFG9iNyfZzJKhr4FwY4h/re0aZ80xD3TKuRbCleth3e8jU528lfyKN8h5mKLSQnTyNx+dotPGgkzv2y84ytbBPRkZ9BRJUJU9lUis1XuePchAOSbqfxjJ06E/zceg7yx43+YzBhytwL54YtFNa+8SVTk/HXxR8v3WK6TVVcdSvnKEicVCJWByZc9HUG+NR8XjyQhE5chUx1eOTC723z5lboWiRTJc75gFa9kPHOKYbmV6FW0cHMbiu0jOyFfBKv4rafZ4K3E0rYveTsKHcVGo295+HAcVLI4J3kxT0k/lA5M9aUbsmzaoNbUZylDYeS7qfRjPEhiIkbR5yFBqFEKQpyAltAPsoAM6kSS5HUI2GetEKry6ozKwhhS+wVZWKCO2vrhJ6sMF2CFAhw2Qo1TgHe3/X34Z8t8hVrX52f+sG35lf2GJF5LdF21d+KhBLD1y9KaE7vh3DLAzBgd52mkTvGBNGH2I+ib47OdMlzseXz70vG+0G93FdmSXDLICM+lZPniGkFmbbhQKWcTaj6D4g/lh00TU2T8O2zGklvBuzNH2ysfI0s7mC0wRBaGPcZE6Eu5OcdjftM03/cg+LQEMUBhA4eNXSClvpVVHNbtrAbtuApyKjQACzXEF6/SeSzh7DaYazwwPi5UKav5T9TpaSuSmJx0VjESEQUwSPY8YF7BNGAmgFTANsRQApJCrF+ke8pldHAYcfoArcILKyrnYfc4VQ4NX1P/SZ8oINTq1/E66jToGPVcTf6KYAI9/31MmU2gS8enCfGX9zYT0ljtmgdTJmKQU5O0xd/we5g47Yo5gM119APXh4Nrr2fwWPI9vPK3bBhSO4rV1xUVGRDWLFhagoVmT7r3AhCF/NFfmt+58uJHg3GmESZWUO1zEziwZMW0KvSa+LXxNfg5CMav6MavLN6p+1MkXj/DjLxDRKYhpfUholIe0rTrJ4nKfW4mY1hyo/dpwPmF/o6Freo1xgppx+ZOwvebqx+n9+b0aKs9t/kVrChdnG6T3olq0Hrfz/KH+62LMDVjrrNm80p8Vf9Ij1V9KozjC+3g5EKTjl8X1Sw+NVCnlntYG0c5/tK/xbR0/QdpEUH56fFxKenx8eWlAQFlKQh2C8Zb+zZvR4ndyyu25U3hCGQq3n5y/no9ZRKLA52N8/x7Yj/Hn1y/sG+9RqaserFWr78/VWMiQo98Z89vVQ/4BaT2TDLTec1CZFWSJ1UlPTdnMg714TdgJd3dKI0NQKb4pgwyMCStLaHdSr6N/P4rQoT32etSurPG1/5k3Bab2fqYI4aIBbaR2yUAW50BDxEX9BRTlMOFB2j2er6B3UgSAENVKWTJN2OfJ58jl2OUwTUhY1khaMEw43CjL9qBingRlkNCa2ITaGEBPXEBcDmjVv4KSQIkhdW3MdfSubWHkrEMpGCCeAVxy6FiZwHUszHbj5w/8hTUCnL0UvZbcNXOJhyFJ85bOQWz7iGl+8l4F+aiXQmKH00ncut2zU5XDYJbfMd07xpQ4tnBDudVdxNzNd8RHyDiEsLLwuDHlH6VF6puKu1936cJAOGMVcGql/fwEUBix68Hh29UFtA+seibcGs3BX4axuYu7cYt/MdNlO3nZ4xny2tTTKIc8qUBeRsQFMn6lRXp010TMGsQ9nUyaW6/arFxowl8PzSQaBdDqRTNW1ghi+ptzkGMLNpH1Kc19ryavRX9t3939fq1VpXwH2gdfnrlOvC8rMFgxJwt5C16nrc+ALR2IgcrgNvdf8aKiudmW4vrbBpELN5YIloX4xSTH1CR/3bk3VwWkisMp+XY05PrmBewFjfjyW0nN/cqrS30Y+6KkwO5cqYWa8tmbmHr7G3z8wDFc5PgQsB4DGMhhVZgxiJgIPjuhRw9JY187I0vZNtEKoXFZPQv+/h1Ppyz5p/anxOXfC5DEKbZulRaXrb0OYpTHxdfkndfnxifWYT/UYq4vo+XrZ+Xp00Wx9ddVcAzBOjt8fm67wtZO/UnqUkrNXcqAi8LriTWL+XtkYPaidnaytnh3GdV5JcfBFV04Og98vdS1N4ToICx24+Y9+U+1vGps0iXg+40sdC5Noi9LrY+YVvIGT8hJB6tqYww2s5WORYfMhRT0QRaTtyTHqgLmygJBC0I2nYntgvN+rno2ixCnHqZOLJx6MvM/XYPlQet5j3CAehiqJSGoszMT2NGS3zXN+3l6i2x0pJN/nb1aHW5pEWZrDdSwo+MfGrWdpzHv/XfzKetzb3nS1vU14chj82ou1TKXeAFmSYzbKHmkba0losVa6TImNH39LP7f4mnnyP1KIklcHLt3cytRwyXNzGuFK3SJyRU4Px50jbvRZWfWv749dub7D2zSQl1s3UIip78vJAz9rvb7Uek2pUGAqnjCzLye1GrdBB4CClamfe8P/hTQglXIUCQsl+XkLe8GF9C1BnD8l+ooxiQm1+dpVnmqeheQKSFMt0G5wPvdfmAo97EiAraxeSGxTmCRuBoTTR1R3sTaXidzprRblaqQaTQzMbFTg/s1k/xA1uuS/vOAfMfoO9AfFzcYJWtkKCVrbgQ4ABQXEXYZcUq7kCRF0ACiIIA4bhhBDMMD3CvX8mNvB5cXp0KOOJKn1VVhCu9Gj7tXgGO5o4m1eEk6kl8slkP3HnTTCLg4FNp6mPKUCKKAWpxRTARQ8se2UiM0y2nGqVrEZoOF1za/nF6TG3UZuHR2BMPXfz74yAy+WWVmL+aldjvzddGDRQyRmQ1kZgxpzXZD9Kh4ebhymqXWqMXmqZ0HVAt5ZMARD/fWsUpbfylW+DcJ5IB0JsLV1WGJnByxxdT0R5p4otUbr5hyGzi+GGME8gviaakTvcrheZuvhJdWI9N6tFqVtlSt/qKs/f9HU/Dw4Pp8U9Hr/dfvSUitlaQHfU/uwy40Qbhn06n/+aZ12kpPkef/wbrUobxNmR/xYobwXpt9v7XtfodLsu4E2YLnAsqbPIRNEw9CI9zrVB7qAtJhwk3Iz4aJXjL+yOi7DMK09GYtaOgwqF2yv2Q0M+xh5DT2Ymezq9l8UXKgwxziDmp+ZOXrfL+eQELcy0AAu9QexAsYgFv30sRKnAS61gIrZo7G+XPqfPcBQC2DIUEER52DgOw9U/DAVftiK5Fa95Mt6UGYNFDiYWB9JnJek4AmbF+PNFA9pEvvWJPotEyzeenxrE/ZVC61uNttU2Gz+fixtKbcJ3B4BWL7vIlVX2nJpSfQrp8aNE1w8weOpetthPoRsPY8IMOgLmKgPCXAAvQGvBXoVP72UXYoebhcI3z6szTmxCA+BbvKpNloLXSfwVeYTQR4ZYBgHGMACpz5cFsaBpVH9yxP/pTwXkzo4FlN8njIRqx840UaT/D0MP7dBaphbw9ctrDWQFjaAw8Gf4Hmye6mT5BSFzzlrq/3USOqemAyLa2SRdRJxHy+uEUmL64DpF2ljvXEmPboD6z/7Vlrq9SsF2OuJ3NB7aVnjTavLYGlc/8p4dGqd1tTx0QreaANQ8Hia3uT4pCny8g2X0uEOk8gzYX0JnoIFSvVyw1VSXaSeYxxrXmNbDorSClQpZCWSQm4aW2oqC7emhDjl+0RH+wxXAhtO5lN+3r/D3qwh14s7jlG9w3c771/zjPbEYS+OxRX3kieviglOtbX+Ji1s1D1WBU6/Tq/zy3tF98rdmGvDy5+nXdvgKlBM5xrgYOhV/qSs+llZ7nuqR6qbHrSvl9ZGy9oMoTBcrb2imYOnr/MYZbCu5naJH3ANftNAssXa1vH6o/m84vFgxUUvHPXl0Fgbp+XfFfVfAjFBNkIzdCQ5pXf687QrBa7yOb1hvpJ5rX6SXr+Wxhhr2b6J5XitJPfyUFnm1ZG0zOGxtGwqy63Z1dr6xdVbpMX1+trZdTDNIcYZMdIoU/pBU3Epz8TVgC/F5a6xRK3V4efWgQ0PjSHVNsowaBC2r37DcDo8otAoh3oJ45nXRwm827PAn6mhbNQ3zh7hFa7w8fIV+YDkgNyJuvrB675dCEOihYNbqLWJijDl8+URp6bijdbWzbxg8Fk7BIFr72mf3W4xbyI0QUOjLvtkR9kBnbkua4rOo8/fV9dPvu/ToVgX4yqzs6orgTmMJknySSL4ZuwGEAMgLJcm8iVf6MfYj6KJfBPCrd5LXgtCLQBhWKJeMl7IkXawIRDEHjQdeVR/DpjN0FT20nosG0XcnOfsKk0qge4Aj/eU5kHyE2Rgbj7gzPeSil5cZXmAX6oXI9qVPjDctQY31FgXQQjqHw2K8a735vXm866PDRrpDwIGPy2AxbYF2PjWXhkYCYrzqvPmQ/Ii62KDRgeuECII9xpxNa5Xwl3p0UhGn5TL5RX9+AogMCZqREu4ysZIaBZExHZdvlxljNEs1DRNvpHYFh4FuE954ZaWrnPPWVhCQt4PnRf6mCv8GRh+OiY6VbFsU3amRN4Lra9+FJgQ2aZsVrFHuQ/q2k9OI2ltvXExLRpYk/B4cXzt61pC7fY3AdfDnnKPnsoIcuPoKnWfi8D1Gnh1FhVFRGLQDqElKERITlZEZE5OtENpYZhVxs2IyLQ0u+CicqeorJtRkXl5V8zR2MLaq+WVL8vK46+Vl78srwQuXwZOB7oGfhJe5zwOIbB6Ga2IPuQU4+Gc9TISICTkPP4BDMotH3hTbDqI5udObqes3G8+SCMnxRa1OA9vRcND2s9FMsdiyqKE3K6kZhUMP/FBf+xNXtlufJZGSYy284m3h41s/RdTmC2SxVoeeaD8rwdeqi8Ivq3N07x6b1PzCsRNw1HC3iTvkszUloNksbyYlaStGRrwhgYC7qmoDQcUqqm46AfU7imE/yQCOkbODljC6mqilHsibHUdlthxHLGwGPqyIwm2sSKT0OG7pEft1q/oMtTvWao5C395IJiueqlLX5f69nDjL+uLZQh0FV3oUJviVVnY019U0X0PW5XqgsPYANOn+vKFZYYq+or11crryZfaudq50y4C30KBBoHCHqFCoYYlwQbBwh7hQuEGwPfXcytqqwHH+JiFMYaeHa//iVDln9/TmB0UWuwpthXUO+JAnjEZtvJzd7DzdrcGbKgIe6w9kK3BLz7aaGx4tDp3vNrQWE4KQeWFLoh+AlD5wIw+O0alQSUGH6PUoBSje20Jl4ID6t9TN75cbw+IDdI3sgpHXiyozSjNjrxd0FmRYo1AWTrTy4FIHUyRXWm6f0NQjquHa5arP8TOmi0xR3D6QoaJn4kNLuca9rp/W3pz2lUHz1hb8cvC1zL9bYziIi1RF4DMEnWbUZgAFCUwKJ5qc+D909s9P56v8vEDAAW+AArA80MVMzNl1TPV87OqsokZaDZ3K/ALM3GUDLCSNVc3U1VQbFIWp0IC316/1AezY/b2BL8teZ8F5oY37vTFqialXWznbudKvnS9cn2VvoKhamEZpBZS9wi1TEXDt10CcA8BiXj9JC3bHKCAwvUdPr5RuKHScoL3T7qkVaiVXZymvAze6twbX9Lat3x0bSa/ivDmgpwoakHXo8tDuNDLg1qdQqu91d3NFZxq9nJUbos+XIcGiweCSSHbHLUwM5BdZIBbmcO1rRBh0sJyaNgysZCoxXMn24vg6TC2eaMEnqfK+rH0nMeY4VVYXrEoz/wl6ibmAGEZ+3BZCC8dFj81nlxtB3YbKlQr96Ogsr4+vvN19Lt+CS39FuKgftR0nAS1posi8n8UOhnCgjI81XqcBOX35OOZgiMyePIJwB8hGawp4J6y2khAobqKi14AWkW9MKBOTeU8/9OKC9IcsNKfC5mXXx1l+f2cc3WVsnxfvjrP0E0iaMaF9447R0f9O2mfN/8OL1D5CPg/cs68BmCJTxlQJJQkjWgAgRz9fwg0XDRTqUmzfKWpSFAPnaZx7CDz7koI3y0P/0MwhRFmNsSqWLB4eli75fsBgRPswyUhnOijeM9+0hRl7DajEIEnOa+MBuRgyk+Yl05JG2JqfUCbilpn98OcWaGilr8NAiD/9yAOadDp8/+adjsBRohDUJADYOxRMJGGqYLFCq8b8VxZB1s07Tjb5wZmv9qPQuKEEpqzsyN3/XzcV8ZKXl1u0c4Isq0LtFbI9cxy8L6zfdTYYq54csH4Bcj5kHtKX6QNJ0rjvPOcb+4kzUxXrzXvDjSQWe68CEJTg7iyvpr7Dgi+PB0j1Lz+ngggPO6TXRzvokaX/Y9fLfhFjL7nGZh0fCEYL2BtKyRoY8cff/4FMLogqDVLhyU44/YgwjMEasYWGQfUiwv7PrRmo/Bm0Vyqjhc8pD0syKExI6xRt4ekmx7m0BgUdYXsoZ0MR0/nFNZsvAtlbs5MbSqOS6WUJCeSNTX2a82k3fLV2tzMpZaq6mVylldwboM50NP5vKe8l79/ATapHQqmqAV71IXbNRFRBV16SQg6iJdVcJCtD4FH9fjtY83ztEdASwUXgo56Likly9OlJQvTJddudKzYXOUPa8ZA32Wj3xVFuoxgUKOXIos/5mLfFNU4ZYg3Q4CxagRmw5rxi6ck5Wy9kVTBq6jV/TJb3PIhphU0Hi49MkuGoGCxFCDEYqnkUK6qpsUdC/WjBdKReDz8Hcor7fjatd9/f3yo3pEotboKS+hQWe+sq1s9w8898PyicDy5Rac5uqHgmM31skMjx0F8rc7dyIa8ozu8TdWiQCIqnzpkg38ulKYt2wu5jvquySUrHC1n6LQ/yGI8ITNEBbI9DfLnkg79Pj9QoL6ip+rqWfGLrqqWXB+4F8yn+L+Tm06iVSWu80fOtF4aeWaE2DAzDOwpCYMHx4PNOz01Xnrx6uHKSFlYf3/1FUslxwz7hicDlOFk39GUwnt+qQEeSH/jlvBCrzg5HtsV9cua4Qjv1LgrEVkFUUDQtyDrN3ie2co9UJmOmDKJuFd3azOVVgcRNkkYf4MabXVmVK3pkhz3m0yo+ygJsYQwDUMwtsIAgjx5J/CfcqTPf3bEhrm7xYZ5eMaGursEyroneSKUFEIVlPn663F89UdJetaGbohjZ2ZmfjQ/JVWhp/GVSQDVQsrpuhVLrg2czF69ph2jF7mSfHOHmZ/uCTuDDTdnyUxL6Wr9Nd6r0FYSFyqWpQAxbfWwtFnAitn+usMVR2u37ItAs2LhhvYLN/JKnpQKZbFPh07Tazz/xPbNhUs0zpTfJWR44BmNi2H2zD4egPuI+nBJGMcY0jz3BYqiFMjBMgtaRn3xUPiX8KIcEl6ENkSEgYB2FbWOvvL3oE3gtAKogJ5PuduG9FXSKDTAZ6MXQHjPhMIMNYB6eSkNzWuKEtQ+KTnglr36ranQEwL5ETf3kx1ezsfhXb6GTtzVaR8DHTtbZmkfUKb15U8GgoMvz93pJmS04Bhv4wZGCGX37laUDQxXltPoA7XFUbXmS2OQnsxfU3NrwEv3izGIdvMc26VsmglC+6qV07B2HVlKUIaoHKfqmSkaO8ewiiotdmiCxriTANy6Sr+xK40oKA8qKaCVFOpeOhFSCPcylO5dHPZaYNf451hG9mgSHRngvTw3Fpw9eqgg82ocFenrtTI9egWlc78/TtPl11tXi9S6+dVJYqyG0+kbT8sUwuw64C5KSByqrxb5QKHLzk4pKhKqWW1bp0RWEIggKhXmfN066BIQoEDe1xzEiRQk8F9BuR/MgLIhLahlNWzmL7nJEzVY2xXZaXkOT3qnHf5phB3WToa8Z9/eaqrZHwhfT7OSlDYSqqDlVmqJubeHjPUPshUUUU5WUV5mxSmtjdMOKbXY3MeTf46zkefhpkHzvO573kl8bBKD88C90lM7iaItMd+VbTLDnsjrVGjfDgemvzSPtGqDl5xYLe6LZ/Df1DWhhuJtZTmnhDKrN4/YuhwN9Pm5iUlMP7LD8VNDgaZuMQrXTuPDkhFmXoVc8jDsgYNp53xVx7siOEZQ/qisamKmLAdN8Uhxk4PUdNTjllnsW2Ek5b9DGtD7715DM3Jgwv4WWvwl9ENn92ASm01dI7UMwtTfwp9ShQ1IwPqSPIjW/Es/davJYe+AcAwAP4nnqjBx5slUHVeCfDVOB3Of6WJ/P69wEqvFPTDjuF864xwBGXsf55ObyYXlmmubq8RW9rR+D/BOCp/D2r7InpUyvKgiuY/0zAS+2Y+jGiF3QA3HEaFRLzwEKT/IxZLRLxOYGCWJtyFrJyjvKasaywu6rtwLAXEoAXctWL1P+XnQva8sH3g2gW52Fu8TNyZoHqk+nM7Co/fQb8kd+m8e9pqxY+lzqjJOYU+ApovmlebL7iTW0VN2rEYnIXiES/7ysgT/lF5wn99Ygrtwvhm3Un+NsmjZLd5UIFBWfKyivc9X+qVGHGsBiZiLbiEB47JjkEMVeV0s/0IDVtZMYPo+/iU0y++wpgkZZ5xnQm1h310YiXVuAgktqGRNU5q35UNCkW0b3UVyTrA05bS54YWQbS39Tk4a9YGXKG8DTPcQThzlg0+H5nsQpeDRrk7pFKDaxaemSHVIbaUXKTTs6alU6bLxjlKvkhRDGqJTIQM5wdaT5WJtLYWEJf2j/ks5zaYJ25Ri4ZaQwpDigHkqejqwHXOUuVPs6Y105QSgmSOiY4mWezXK4fZna22AQH0eyhqnVCa3Rme7JMRLTVnZfzjpSUiSNpc6x7tHkOBcVj9WOn4nnQTHsWRR4DtnqkV6PXqi63ndh9NZbGwOCxj/0D7Ja2PXROtijpWlMy1aPvp88tjd3rs2WkdntEDVNK0GOGRbXHnofO3wjmYw63S0x48IFTlkzCfykTIjZd0tbHDZM/Y0hRZMuMaazvy5du/ArcUoGB81+7kosuBgGR/N1azuLulkix1QzZJQwMcbDHz6cw/d5/Zn3mixh+5Rgksv0L4OxsUTZbv7iE4WgcRmOXPfx5olU5/Q8TA1kYEBiVDVhJcyM7U191VV9ukqvOpUeYapaMhzbekrZX8o63MXWqH6GE8MzNgVyAYDHuU8bYlbvUkVFY5aUk400Dupg4qqbJXhDSiDZW8cd/AbIWZQAK0Yll0XTo5Jmv0uH4m0W5gpFPkl9KOKcCu1QMTYbxTQI/a1L2cSlusNZlvmDpm9SF50cjfGvfVxrSMB7/Uqs+G534oTy9IdEJ0g+s6T4Viy8FdlRQyPaRXq9RAqogqNiyb25IvK/jMP0yrc6yGM7RYe54WPFzc/p79d0aKLS7Kxdx0156sWGNnRqHGBYW52TtTciZffzA5EcxxnsiglmeOyw1yjeP34+7klzxmXAkWLcWNnm/DLu682dI3yPss43uDafmaGYxwbprk5L7+l5YJh3dR94q3JVb25VZO5DaDQlz7D3DXxOA4gQcskTPq2qzl4FAjFmnTUAlkc1TTrjNBRoSE/R7HKygVbGqHGkryqcsFWuALygbp1s9K/+BMSVqxyP67l0sI61IVq0hKp65XwIJQvDKRyu97lRHT2RTdmaRqbD5wm/7IcKCo46nSpV+/em5ejfEalEg5M/p42bmg/UGHulu8UdFh3XP8ep6EHjpODzGk+feWcQVp9Qy6vUWU13fs3JTDANzbdrFVAcLnaa6r8Sz/Nhc1SIiYYElCGDrecIBMg1etTaGyQZ2G/fFoaSGlHF22GuZWPSoCuOoixekRWv7cFbzOpme8K3vmBrxxnqJSZ3ZfnDSFhSJlTC5lRVqRAC6AfsexYgi7XowNOvqB5j1PFO/fRAfnKaZIhxWaqXwdvojk7kls3N9IBe6iRUkLdrtJ1SCWms6kkHea0jBSZl8yddPA9DGH6MaF00tERF0aJC/fwjAlzdwl0Vgr1tFJSCFFQdpOcbcw8PgmdOVsHr+VJES8LaSe+sFXorodQUbfQhGGo/oNQsDDo66DXhrBZiGGTFpgeRx/ERMhLOYKjRJHZf2jmW1UrHbfS2Qesjey0ZTPDzIXB+hevVO/zLiK9TWg+kadVKLam6OT6znnox9rH93D43jhWNf0ogduP2bhOzyvxkDihiVcXKrmThOQRwu2qDB501WJTXklIrnoq/JnZTvoC5hiCh26xIFQXRT3VKqF2kXcAdvSZdKHyN04IIguXvj0JwAYgKVRE033gMJG2aNLiJjOilB+ShGS/JmtOa0o9FV76TDp/zP/1pfdLVl3eTyY6XBIjusnb3b6wyEpvz+Wpm+sVnqPj7mstQbSSdh6QfSB5x5kQD3Q0nEuGtWwt04NYCVg6IN0dA1v8oYdScZHXpakzDClf4lzCH1/2Fox2kfwiloz0cERQzD4OaxSX7UVMSMnK5Q6WJpXrm8gJMH6UUQew6yUIdfDycrSkmJagqrKZ+t9DCd8c17n7v3V1Sifj0QD/lgLlXelKKO6sNITy6dFTCVq+eYMWEAPrNIjoZC2+VkAw/LMjLtzNNTa8KybU3TXQRSlkqFgtd6BsY7WTzw4ISrV3EOFxenZDnLSOI8K2eDqBjOA02GdAPZwtn/CzRj7zMiwhRSXlowUra2hj93WtiNblgi7vg1y4spuSm04ufhQD7QRWhnv22Rgk9ipCwGzniAOwuH8+hgGDVUShrS3CV1J2UBrGDot3jQ339IgOcXNtFKZGngu3D+LlKpxtJWguuz0rgUep680g8UXBiPnPJVUJpjIA83kB/uJ6xfrEAfUY79Ay6LhluC7kc4Wbw8+f//6uybBTy0X8K+wdg/sCww/+Z36y9P85NbjMc9sAOJw1YaRRHFF51SklTYuV5yg0yox20GDczVyEL3AGnJGq0kLH88gu5AeCWxYgfLhoYWttptNU4cEDmiCsFFZnAAXOzBTW22zPn9xGuvvErIKez77BUfV0LQI6/9gHy0I4O07lDCRRG42mDmgcloGj7nAZr2NPamAQlhppvZ5I07RXjwbSqc25zUxC8c29ghRK/f2bOXtIgLhGqOXxBI5WgSbup2pD6yIOY2tr6dM2U6SsMRGjFxPq5sw7f5Rrb5UEP4wk9xsXlpD79pcJ2aGh42/+FiGmUEVa7FfWBU3I4seF5W//Yq2me6s5KO9KERNi0f02dY8OK9459kqy8yOKcV4iVroYyo05NIb43QdhzSSHsbW39JaU2Za+8Feq0y023MMzNtjVRdux0Ku6OCMzRhjGzt7CW0LmUdqZ56SuFQlxdS7eVY57Byfavk86jlLFcisB6QLpcAYfZNxFhXobPlgHLAiK9IkXsmhsSQ70UFvDRlUsQ7xKXK7lPhuLce1EKQyWXS+dUTbFtS0r4AwqvinEN1QxKswM+wMipbMatwF1y8q5Fzh75ep/mYz1xMQScx9PqyVyB4kNxAxGZY9/cD2yDPo53GNL9yETH8q9SAkpMU53n0y4a57n59A33EpCvB1MB7hWeysdGlF8y/8UFNzqwbJdJgGZ3VZp5lQwNjYIP0nZAWkYu9RV15hwT4+YEDcXvoJGLoqGn2QyEogJFg/E8zJXa4hpzErfTyag2l0rtLOz9O7blggkVGJQzeF6Lcm8X3A5QbnaWkhmSTaCIcA3yUm5yZZfBi0TAfW9nMiLS2iiO4HcIl3+hoZ6+BOD1ILkhKWvKyS0duYIbJ1yV/xn/i0m/cmib7iV2DhoZCHGA//TTjUUWM7rde1YJTOFHEgrk8eVeDl1GcVLgIkKN4NJCd3KapRUYJfUGakpUJ5jQEVWT/nxozLO8vJJsT0Ctd6NzfEV0ktlKPoZ8tKnUg9ZepnARk48eCwFwRiBKidHpOJdY5oLbQ5lIIdNqXcTpCHurB8e4vVpcpiuSLzrypJpMHewC++EKt0K2pYK077a1JHLPgK4wiILPHtbqeJj7V6YxxhopUAeXf5cmnbKTzNkDBFXDDhyp4zCOOmwTK+UYIGwZaVvzOuRQkWHTZSOTCeEWUx9xiVVyFIEgTaGfPS1LNuZedMIV/fVvBbIKtwImOOnR8Bnd23zAHZ1DoRGXm7+eZeQDl4G2S2SuBJX7UVRYuflXMKvxMGpzyEIURR39mQQbDAVJOIBZ9VNsjEYZR84m+vXzhd49g33OhQ77uOPIbaQx3xVBy6P2ZeEmMSYTcHsSwDMZTv6OYipLkQWXNEeTv7HUhGTJrOpZuudl45xNxOsEyb20nDncfSC9+aUeSJhU4i9Z/U9s5UzSG7aMxFlCu0cLJFzTFuCWxwSo3TRvgQhSmzWh7+mjGc1iuWIns44O7ReFcYGKrOpI2ceadUuahhhnHsWZkL6hluU8pZJuyotfvgJ7Fa29IGMdXQThWYBycyQnByRf7Qr3YwydZS6VMykT0bptNiFNE1mb0OFaxlmk3VblOwKZZHZnUFYHQc0b7gGXConLzbyGnIBc5EI6xVkdz7Hf1gin6JgsZlFYJj66ZfObIj5MqqZcth5TIZj987ksBaePjWkEtNr4rmtZl5DqS1lb/H8mk7Fbg8mI06e55DwF1M4t2BZiDKuLElaxz2LWL/RRVuDobOQPgDy2hBqbWiwcn5Vge5lur48IdhbPTClrKvpggmGr2uDKZH3gtASQ1KW3zKkOLs13bNzHSId2r2IJb0hza3gPHQoaCv1OAYZg30LVRpgFKllWOAb0kGo5KxPpR4fapSY/Ow+SAO92PmzzASvsYdx4IzWxIk/UIx+ew1xXqMMw0tZaljvhKAirlu8zGTx4laDtlDOx6F6oRzhLzb5SJYJOas6THsHM9rkTKl1nLLNukK6esad5ExpxQ4mbix2xQejr2HLeVv5DQKVAOTZtBeAcLrlgGMepGBYPCRctC1NtPUQFjpG0YB1Vibpee3pLAqaVsZwHQtzHbisOeiU+pF2k1lBy8o0jtDRIomIksKyeIm7kohRS0u47kvtw++UwueKlUnUYzAr98nv5Dh0S2RrzOGd6F0/ieTF3QstraNcX3qfQroCPB0uB7SITLnM9EyFGwqsG/p9rXLpcqxyIPm2X16O3+XcHP/Tp7jsn5t9b6JCi66E0NZitPnPA8Yt95Jh/wi62dOARdDKDg4VCynb2zwZHs7vXzCzeLunDw9BWr/502j8Mjr/A1kKYaG0ITwscHsEnBWGCiuNwNxHFuhOSpbVbwcU1joFZg9i3Z+iCzweD+ZnBeIvBuQjCzwTY9SbQuxFM/TDgw1zHJnJvoN9qFpjYgzQos6H9O5t+YLzT/7rThghEqa60SVPeqi3rjtgliu1ra9hY32RWdHxqAx16MWkOaglP2iVb1yjFia7JZjfJbKG+msTF7sx5Q8HKIlheSm+yOyY8JAf7/2Q6fHgiRVO7KsDR9whmFcm3yfmuYVlIyU/Ovxnce0OtqSopyje3D76r7dEaI5b3jqxycYpxBlhFuTi4hTuaooIc+a9v5we4HIpMyA4NCvgkjMosWpg8h1Xb1igYsoe9FGa1rsKk9wSxLmumdsIuCAzY0PCsxN8kdlXwT9CgdeWWu2nrV/zq7/Y34k+EWVe/jX56NdMLcRv6zKB+FryiSTDM8mXknMZ6slXMmJeemyVHWwVTMmnh1sHmcV/32veDDPNSr8BYJRwHNe/MhGX8lxM+lDz83uN0w8y5iriQrWhKosqYyXvhuDn1jRA/2NYk07sxQ/igctVlXqj2b+RIoiPK7huFqgTPy+jPXM3YQXx6Zo43TbFXweP8xrtpZvXa92F166yKXBxKjBZpevWCBu2MM32TVQ5AN1KkYOGnEVDKLY3lztpANPLe607rzCUaIANzvbi6t3ArHFhOiaz5EFstO0tuP3kMJrUg8bcasfWP3/lP+4e4BkT5RGZbtMUhqi71beEl6k9HxyVkmCOohHbzM09DY3MvIBdiNznw9wkbIhzsDM2AeWujoqLijtlXcsKrkASOlhZIoTOvI57G56L/Z7oHRYVkqyB7qnhCp/tSfx2fs332TtcETVLrndm1fvPiUYLSiGRx8GZ2W/DvXy4REJYWStZACInItfmCNW1GZy9CmXdeiIi8uIKxUXXjru9lO1HQ1150Wf/3vaMN6aCrKl1Y2sNBX2tGNzwLK6Qehe02wAmW+wpRQVQqtotAMHdCsEi1T8IJYS75T8UrEXubnMAeoSQQugGf2o+Swnn3pAjNGi0SyGG+oHbpr1lqmKEi5vvc7/sterMu8/eDo/s0wbgIeJO6q6XTOws1t38w12vK1r2Pz8ZGXr+cbxfzD9LsI1dUNs+cnK8suVs61F/sfgcXFJyXm1bfB4hJSm3+qrwm34pTEGBoJJZWoOqpf/i0x/l/qCbw99RttlB2dnaM+gSYMyu6Rwp8/3Pbq857SNAYOJ8s419c6OjyYGBFd20CrVMk24mNZeLW269UUOHx1COw98GbiQnRI8wMKPb/ZNDT8ihPyAolfOMERhS3+CT3+wSLlTw9AEj92iLhovLHQ0XT0oaY61kGfMh3RIfYOyJ0DB3abkOvc5I0TD3TCGBvE4A1rRd4b9D5oXfIXzNEO9fvi4Yy3JNH1TWId2trH+kbeJhYFSd8ZsZn0aauCVwphApkyst0V/I5vK+l+OuBfS4E9z9vafjW0GP6G2jtQFFC9IdSSGTRxaaql7Vm0DvqFifIXe2GRoe9SdkZkmjvfNdjPn5nSzHh5Pan5R7I+TmwdG2n4B1Bkn4QbvUMEyuqB5tazQ5umHiFIS85BDo5mzydAvP//ksfP4joejVu8QKjhnkJKR+ZKSJQpV6oMP4V4z0WfT8+7qi1+8TK08JkLrR4WbK6EgdBCxpZfb82ZqKv4OIKQsNi6igICLUPxZhP0Vp+l9zcXZHu4Ul3EoFR/o0Q1bVxsBdbmhlxYSc3Ah9xXGAbxmcn6W1ICWQFCzxRH9OQKMgT84J5GekijpdBRf/gFva5JtKt0Hw6LHLLCh0+jyHJJzrA5nc32ag/kO4h4NQaBQOK3nQQZN5PxMJVEXqXLSdQ5KoNmh3PAhaothakgk4a0f7L60l5FxfUySrPpmMixvFvplLkHMbg4n0rXvwtnNr6WMLRdpK306TWEwlgEdvp+jdueNm5jtPdANNhofRR+QFOFqwXgSG07tFKu/PGrJEbcmFT7bJZNAe16t4Rb/WA7G2Fkasw23ew8W3eMJV11rIcAtxFGyA3HFSm/Lnk7SpFLoObYYGf2wBAwDiNh0GaR1O9mq06Z9HLGtWvPE+T+zeGFbnQzoDz6rSi0Rz+ED7D7dgTKySSMTaycnqGgShkL+1rzdlNztQNdBEthQvrOLPLHcR9zhlvEr/LaR+7LHw2Eg9kAeIVuOSIZWqIULNY0cG9C2BtOgiiMQ4A+IkqYsnMB8RDD5uLGlfC+OijJzpAgOgDLNvUxMwB34Z58/rO5DcQDKMK8zuUQrgJj+xmBkHp79YPv9jFemXmWmBfKYja0u5Vw7uQrXQRY2D2IohLRIaQrWhISdxAc/5RYtDOI+RhLTNyoiIs38JDeiLon2+nxoDAktfBG3BkL4DyQVCD7SVQ/YI9XWGtNwb3TEMdSDw2KJzvyvbOflkPOwrUI3pOR0fFzFPpB6AUiRGryuURY+bXOwmOoGa1Rc+R9GfPbq6FMZCL3di5X+Ehl1cokc2lHoKm45dj8NbXJJ4fcH6z8m1qkaR+juVpUtQz3M0YAqmJRDFafNJhN3M2pVTslBjiqGmRZOoJ5wjttOnhhaxYvxoDq2EiL+eKtUBzK+23Rnk2uKmezhzwnhLLN8NS4iUrWwJmlOIIqqu1v0/qzwxo2z3Hc84OV5deo9a+hBI4PWGWG1ZBmYTGC/O7VcMnaeQtF6qW6rHd3mXfVXl59gN9vid+5NcR4cjSMvta0Fllc3MrGx/GfyKuVsIyx/4MrWYNPMRyOkJMv+xySkbq+1JeIajRnZ8ucdTYeXMlfNMmsknAI8QZORS3FJQs5jJB5PxTxyIc5kgK1B0XmbZwLugigNTRRNq1wVkqaMG/D+IB3t4Cql5mX3PxTzcU8ILGYFLGKTGT+z/mVNWXZyKWErxZVADcmrLEEuFwaBVpIU+hl3A3Vc5pLCQZGjVQZGhQUQlMyH2Rc0TUjCZsW8/f2YxyMDHO3JDpENp4uD/Ns0ky3T6+Oyc7LsF+DhDvbQVzMxUiDZhnp0c+IcEqPAwwOSCH6wNZNZERBAlax26iRBvODLH6tXmfMuV1rNIaI4oe4o5LxeBwIk2itfQwkYTH2NNqCwbJVwk+Xax/DpHIb4PyiNnLAc1v7Ypsc0DcXGzOYklcdcueNuBmB7HlsXEr8Z4TJEtiLhXRsT8sz4WKhwhuXMf4tvlZdeslE/2/kLO6H90w6IVUDnQSFewKHBwb9zcbiZvPmx0P+zXVrNvbKaGXS0uO3TgauyvM978OxI+AsQg5zfbGxT6tLTT2vVku731yXpn0rXS0mtJZSUJieU1iQklNf608OHwuxr+sO/xx0+IwPf/HnvctGXfwxsH8n/DukFM/05Pe///MIz0Qsli6h4Ey9IMCNsjxt+A6bBACr1M8B0AmX+sJH4Qh0VhR7l4gM8OiGUJvKCgO2BRL+GxdbwJpkcMytU2+NC0SGuzXSrakshMKxNDKNq1FwAg+vp3tMNFIkSs3pmZNy9sg6gSCHq93n5coP13F936pPZBUfjLHEbfmQkz+J+4W8Zp21+XvVL4bU4PYA7skfUXyi71+b2w/jsLQfdTNtUrxg7vvyLYz/wQ9I1fux7sh5k3fN6gVh95dxri/CQs70lfd6+smuDtE9B5mKxyXC012aK5wegTT2Wzh3M96WoltPNUDdPQ11g0ln272Pc1+vkuO9+ZFmMIg8a9WRqGwm+yzrOLuEcsp5Tz48DSjAvplx+pfWzApMWCHdMdcine4r00b8enZfSXTZ2W9z2ttwk9rPDuuU/6IUp56kicS4QHAoZ54J94qa49ofOSCmB4Q+URZoqypRA39ZXanGR5n7iBJf9DqVvDdWbJr9i1AlO5Wz74PM6ziWUzmFfu/VbCVhJ/ZoC48pQVxh/+orA2Xsl9b69N6ByG9uusIFM/cLGzgs4btOz36UiL2EXUZ10O+PdToS0xnY8f4Ej340OLZY8xZY0p11LWghqjNxkfixUqTwdy3LfjWa95ezCeW1k5dPvDVFaoeJEgzgHQ75G3acDzzbLCTzVmX3O+TxADdCyVfavUdJqpYnlA89XLyx7ozjTeYAVV7MC5u+dLuoPU8Zsqr/R7IJmHbY/BOH39fngWQEhfCXRUjzBdDjwSQORY8VOFcL4bpN0qABeLpxYr25VR826WSuAxqNak5cAnSprYU6jn0+NXKzx10EM7vfQK6LAD1/EwdjKq+x2qNMgz2fDxL1WpDOQrlSxObNml8qxJZcE3L9lLbKLoHvOQvgA5BBp9Zew+jt2HUGrAdyGjru9Kc9Ol7QiU5ieuoPcB8QM3ID+nREJZQ2kBAOjlDSXmux3Z4+mvFISvbyxA26FdhFpRT1dCyL5/PFKZ5la7iMvKt26Xt4SHMnuAKQb4/ydKy51WSeD/mzuJKUHwv87JPuU5Ntt5lrMjnCo9ft+tNV6eflg6X5FtW9NvtkUDsE/u0xe+JpTNj2CICl/ZJm++Til4eBEIhRGQr3ihtLPPN3SfseyQFPE/p1bY9cx1b59sMZ93IcYsJmftV1O54XV1W4qmO1xiWpPA+Ui6WK7vtQ9RQHe9S3gf6LauYv9gIJ5Qoe3ifo6zHAdVdQpwJk32GK78yaARPooV93aeGa30dzS2w2W8VsdgMZVPU5X1t4V7U5Hermd2kvKV3XTzjOWCZf53b13Zf+EtBQonGiNcy1LEszSITwJWo0zU5pFPXnZcZzrHT8ExKZUdjfW46+QbMbn2tjBv6+I9RHIAdndgWz4Zq9GSeN0AXnukETulmodsbbp9LPfZBrY2dWsx9Aae9mO0G9H26YmJzdnYLip4msg262mlUFv0Fgo5hpYKbfNKsyoO/O9ngP8/tuJn8HP4A/ytzG8ApohdDMwS61MeOttd9A8d6BUyMAAKBAL2cHVXS+wBG9pJz7sWAju1YripDfQx1EZWKdImeFmhzZDlVJvlOtHaHJKZxnOj/7T5DOupLaDcLm2ha5O8dxH75+hOBCy/WghoZAG4EAgN0fpVw/hOaoQIDzWSW/w0Gipkjc4p6xpD0Qg1JrshYFb0kcYRtWKNy2tTNV6ODPN7+dKeNx4HBLDeZYN/55lQciQmltCw3w6dOVnvL9bGUQzBYR6nBLAGwZhTknM0cCcfYYyj1E5CYpCzLulRCF1O56Pz+xB8p6BYE0BkMoDYvdJJijJl5JQakF8fQlMPsBFJUPGQEmoaN6l+5V6Fk3sQqgSJp4QrhCZAzMgREpJ3iOkInTpykkJ5kU33NAxdBOx1DGfFw0CmnF5734/YDEMX04fowLIP/V9SPFfAvvnHO48N9fRRSmFEGBs2ImiUxeSMiXvryVUsaZKQ1Go6QYHiE5k9XSG6+dFKQNOArDWrE2sTenuBmD+w4s8ECnI19Obps6DJUsgS6pyQK2Vn73+EBWdrZ6UoezK8fkABocJULHipjRVZAOHyjKOoEFtFcj1JvlhygAIco384UjZnGLg1VZKEC8LnEIUDcW4qClCuUh/jEOICB8wimqCIRYnXVXOONPusFtYXYKCyFUO9JgqOKo4RdEITimEpHuQDI45v8LNVYZJsXmNUYIVYIHJPYECMU8zfWx14HRcsXl5A4Qolv4MTW7vSYMGM27EDPyjeSDwiyCzEKWMQ6RPrRcoRFDYqOYEYXl1FEw1snAy5qk7LuhejZjOzwW2DbtFqTuyRAhsxJZfQKSwebHsNOpprCgcOLzuHzCruZg8qD/nHRlh5ZXO5cCIPy2HgXSckBFahLHIBzHeK2MM9ltdXqDFKfRKKGTGYbexjVXgh/mkxQlP6IxxCEHbNGHKAcwsBdC4Djfhkp9f+xVMDlW3fqgqAoKYPNAVW+F27VwCBg4EQgqNqCPgCetNFx9R4Y0bJxjZoRw4DLHhiUiWar4qhzTjmJiK2/rtvfmjSbcl6PwlS6VUhNqu2wSbbh3UvqrFbb/xn4W4ox+btsVedy66aF6Veo2ZNWnwqTjv74J3ZsenSo9clfQb0GzRsyD8aZRoxJtsH1/w3aYnRarM7nMk/QE7VM5CcOolwq/fHL1ROuAXcBu4C94GHwGM8tWn/7KQqVygBOi2zlKOMLK2sbdwJdjMHDc1+cSdbcTsq6+nj8zY0Mu6xP146ztWUx/fk2YtXb959+PTl2w8igPIE+t/d2lTWOa9RilbghFJFUnQHHKCEWv8Xdu2XZMaac2oLSytrUXY2N7c2t+DUlQclXwE0jEJYRYqViLqDCpZnpFIV5CecDJwCvA0lO0TiWZ3betzR664+/QYMGhKTJwsDFD4OfBLRp922V6xas25DvJGkBx6Kk/MPfE889cye5/a9cODQkZf1umvAoFl9+s3JMa1Ap3njJox27JXX3njrnfc++OiTz04q6kt4BLU+R6tFhXqtSlWpdq+vPTBpqm8eSuVrY8kxLkGIkqyomm6Ylu24HhoDMuqJuzy+QCgSY40asFJr4EbhE/AFfCtryFHFH936LW0d2FHEwJ3d2MSUx/eEPuqlffXm3YdPX779IMLn7F25AieUKpKiGTPWnFNbWHpn6WFCDV8JEcWmekvvCpmCveI1SvbJXSAbjUNCLB1oCZirmY010vxBBmhqstYX8PAwWz3QQxlNlL6lG1on5DEc+efounrR5nxU6K/QBPBfDILqly+LoPkUBw5a2sAcrEPejBGMQXMxHtdN9ZihIxiHvBUESKZRKxidUTJeJG292k5nhLkj2s6EYLwdsXwTbc7+fGh3HljKO8GDNFV3EwSzLdIj2WmZkXydqnuvyLktDpZPox49FJSPMRl8yrk0kDgfMD6iw2wJwYdMTDTD5LpfcP657raja2nESUwmUXEpTSTJJ0zGZPoBUyGfFhBQWGP3pYXNniLem5HObsuroqzmPjfCF4b7zAywjwh2gM0q3fhZksyI+lXZNmwAn317gK/AxeQtc6wOqrdmuVhfwMPkcN5jsWJ+1mBW90H60TIVxEUaUFGogf1eM/XJOppNDrsxCyMzyj5RUqiynLi/qOsNyx35JhGHDULY+xfFkI9kqqkohMLePdEHZ5x4FJBlIc9x6RHbrz2nPrG/7JmuZrL+NGB2knlzLLsohiSgaIbleEGUZK0u9DEJElA0w3K8IEqyVhf6mAUJKJphOV4QJVmrC31sBQkommE5XhAlWasLfewECSiaYTleECVZqwt97MVQktdaW3X9/I26NhmW4zuhho1bQMFbqUm8vTtKsdtswhX7a1UbeLlFN4sjt/hGmrP9zqMVe0Sps0CSJpCJrAeiqW1BSsWw52YvnKVtaHirO4/J0WhbyGoHcGAPMdUdXGUQk8TgRcRfZCWrmGRyWBGGNsPgmfzujDluCGubkY4yxYj6gJH21l7BdsnusUU2eptzI3ZgW1yr16N5C17sNDzZAXB7CJVtr9UH5lAfBFDb5ogG+KblXzB+jvIwuPcgzSqQQYDRTVSk1330nv50MHs+ZBsCBOVMAQLMAIDHI3wDnu1fUEPqIbQY72OjVC3/xOxoeiicF6f906DDrbC8178NGm1W8iW91/tvvZytkEvfoFSePZafPyXcHhw0pFAhxN3RfhpS5OfMmRCy+fE6K9te9qQyZi68Fw73zr31bHN368mrvnzg5ZtfiWimW39bZPop3jUkXdkLMt58+R197llFcunYGlwmP5oNvfvQZ22iCFQTx+vL3UwJR90mvaVaZChuMs+GTrTfv37+8EEk4rfp9WSam3KQW1nJRpbCqP53WazGgyiZs0JO57PdqvXGhl296vL8MrluB61BJ2G2MRXGLtXWcozsYbxvug67jdnt8YZif7G7wB12FfhELRzHaj9+PcQBVskXByihEsG3r0ILLbQtF03ijSuk7N9bhcitDuaFa8WzxBOfPRhKAA==') format('woff2');
            font-weight: 400;
            font-style: normal;
            font-display: swap;
        }
        
        @font-face {
            font-family: 'SC Prosper';
            src: url('data:font/woff2;charset=utf-8;base64,d09GMgABAAAAAGl8AA8AAAACIBQAAGkcAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGlob1kwcg7UwBmAAh34RCAqD0QSC3wYLiXgAATYCJAOTbAQgBZERB6dCWxbhcQfVa/+BJNB5G2j9JS02TkqYZ30OvVkEZu/dxasM6HYEiuOKlf3////nLRsxJne8O4BXNVe1WiASmUkyKzFSmS3LUiXMLFW1ulpdmCb3Klqiq2iISrRFQ3zbY8eoJIeVAk+IG7uiqBw9Mpw3b5n8v3fv9gMcc1UJ1uXt9iB7TZkgHYdfw7ZJT9DTtxeVxr8gsDHGRA6/HX9solAoX/fwfr29E+Xr7tHPzw4BgSG4KzAsMwVp8S+J6CP4wmX1lWuS1XVZMJmYTD5ZDnjR68qG97Q5fnINKP6g0vI2x7mwFcYtvFStc2LixYQ+WpO+Xs/scnKARPLcV+w8smZIDw92+3eHIw5nzDPOmGeMec7eh7PmOWOurKSMCkm6kFB2lFFGSZKQhiQdjd/vUKWFTvdDlJ6I4tee96vPmd37Xoh8FKFQ5GIJLAAJDagIHYFk8omwgP/v0P/DEb8z768tG1AZhZhHlkGiCYZ1D93ypjFbp9ex5rwYUPFAjpD/kKORUvFt67Ashcib1tQohCqUX/9NgGo755qqjWL0YPdl9cGrjy59y2XKRmTcKlIK1NxetAk1mool4Sg3clPHgVrng+e/7tm/582bWdjfVi1EASaACQeUYGZToQrvIAErsJEc0oX4IRXNvbnfvjx/2EVEZAzMwVAfc4zzuGAExDdVeuA4JFXdPFjpQiAEQdx2+rVkMZQ8xpJR0bEgJY90WguSYXdGiuKifaCSKy6B1pYVdiJTHMA7raax/1nKtY9cc4lQnS0/Q0fwY39Z0i6TmYLnhXQW308K6s9b497e9iYhKKDj4uFms2VgXBv3/3SWrcde8IUdQvtddFRxn+tCWDRpKunPjGZHs1rzO1taL4PsPUDL8t5pIcDeAEK3cAgVQZ+iB+xSlGnaFH2bug/Pfyzf2X+SblyexLHC0aVOOpdeLW9QDGrpVRicWZlBIZE454CKv1f+PxmCDwLpFIylY8CqN4EIBujjA0prYnFqm1IPMAIa/3FaSVeX3nBgCNuO0xG++fK3zuv1OK0Wfb+nWY09c7WhVFZxrRAHw8y/TXX9py+9KGG1vDHvgDhmLJAly2eOpW+3yslAITIUUNKdZE7PX3f26d/9CyDaLjkpAMCWtTCnW9eRaOywTd1aH7p3+p41FoYfw5/b3f3dGIvK1qAAQ1zYxjTB4PmaptS+/c9OE0oDNATuyugg0+3fPcWtNVQa0gVJlw5gADM3wmEgExCnW9JXryI9ZIiUMt8f038Tgvc4O6Kliz4pRN5fY7f3K2Oh7t3Nc1+d2d0ySBEJEkREQigi3vPvnO+3tMdK725pwlfrK8AoOsiYkcvfflaZaCblTsEECJJtrR539z5+vKqnHmtWDU7alHt2swpmVFRURG1SYfeF1x4RIMAHz1U6AHx2pA70ZB4raGwN1WD9v7WpyEkQp0SCOi0VxE1poG5JB3FbFqh7KGBBwWL6MUh+8j1ofrmUICIwIFA6LwvVWd9HCbBfHocrQF3j5w3IoAY4BQyf007kJJ2hhykKqBgbOr15HQKWhh4Ba1urgIOttXDaCDg5WDK/9SHhgXFRtIAOq+tEFjSB1eG/+GHfEGnoT2n28IJL0qHIRQUTlK+VWqONGouJxob+LqPBPcRbYyjMP+dgnljPrrwIFEQObofpRsSbRkMePemB20rSKOlqDVwCxF2JFb54cHvFsQuFa+ef9QFrbP4BwHMEEpCAP7w5e2o/2S/eYmEnLHfUyavk+virsIMM6mkb1dx/gpi+/Y3K9Ean0+WpUw2Pl5t4HM9TA+uTGHQo1n/S6pG0xzpNTrfb0uP26V/lhOSyPPkKFKbI4qqpzNBsbmJKG5nK2qbWRD1ujf2aZqBFm06MF5BPoBOcUEo4iRQtFgFRomSp0mXWQ0pbxj2aTR4w1Ch/hjqNmMYwt70pv+LVqrKLzQLELSypsI7TYpRYcpR8phQyM/cSlnlbUP6wJI5wHrtSjnKn7Obz11GUf3JOkqs8+QoUdhFFluvo0JkudLvhlh69+txGct+QYSP1kLLbmHETPUWJNU1myqw581nAU0tW8hxrNry0ZduOXXv2Ha5dUPLDcDGMiRlL8VCOIPETLAnKLilosuQpntLYvg3oRP+kDCm7jDuUEpuwPeElQqQo0WLEikMQjyhBoiTJUqRKky5DpqzkhDwFipQoU6FKg0bNWrVpd12nbjf16Kt+yq4Bg0iGjIA0WtP7tZnp5VVudf92uj/7vnIW/WPTO7cuNru/JymuHgABRYUaDRjaovPpu4QeAzhGTJghwiLWZtvssYMDJy7cePBCltpiT51GzICNOSxiSawrtrJjz5Ub9/LY7nmW9/6c7+2IVYrA6SOhWBq93LOiMHaTHTAIEJRorLHO37iQoxBoUbbTphymQ+mkS5nOlHKSGbDMhxYUMkvKSY6ct9nChQsXLly4PErvKmW665N0qFOXbjfc0qNXn9tI7hsybKSnKC6myUyZNWc+C3hqyUqeY82Gl7Zs27Frz77DtQsKIQwXMSZmLEMlyiEVyjS16O8CEojgDqW4JOyb8BIhUpRoMWLFIYhHlCBRkmQpUqVJlyFTVnJIHgoUKVGmQpUGjZq1atPuuk7dburR1w8p08bTI5N3lynRhY6MjBRPnDix7cTJOiCgqFCjAUOLziX0GMAxYsIMgQXrOrZt27Zt27Zt27a5cFlnaLrpM9vJYZmziGUf64qt7Nhz5cb9cd+RL2LRu4B//pw64/TVjTz9aUohGlq7loo1uncTEoyh2LZColtDt1xzpUxUGar3Xlq9n/ZQt88ybXRmsMzboieypO3bKwfi+HKKs1z+jWtb5dbk3Nslzy7Nu8vzaVxRDe9W95WzrchVnnwFCodFW7Libq1OvQaXNU43d2ZX+6zrja5j6dSl2w239OjV53bfa69I5D6GDBuph+3SmHET9ajLm+ypbcV0lxnNmjNfT7q1BYueembJspU815oNL23ZtpO3vd2805739h04PPhHe3XRXKO5OFpdOknvyhguDi5GTJjDYtjEES7G3Nsbz6zGG5D48BMg2EIjTwRiJTGXSUGTJU9xf6XtT3mlU9nZVFc+NVpjuInTgk7rU9AynOxvRNljTLGKKYUcDMUrASfwCQxBgoUMQ/+tQMIoaIWLEClKtBix4hDEI0qQKEmyFKnSpMuQKSs5IU+BIiXKVKjSoFGzVm3aXdep2009+qqf4pIBg0iGjCDA6Pjhzja28o1jwiOPTZrq6Ulthprd2Z7svzzo3h5876xvp5vY9zU+G3o/prxzxhdj3c957Tf++C9///K/+UdTKOgDAQKKCjUaMLRF58p3CT0GcIyYMEMUy9DHWmxjPXYcOHHhxoMXsvjmdfwECEIRIkyEKElSpKHJkCVHngLFUvu/MtRplOZaT3dourMzG/qwzFm05VjPahpr2bJjH1e5cS+PuZzn771Wft7Dne8mLmLQgihNFW3lmruw21julujK0FKmWqY9mxksc7q25Mj5z9woa7lTBnhSQnhTckVRihXPU4d6DS5rzHV0pBNdut1wS49efW4juW/IsJF6SBkwZtxEPaLkmsw0Zs3XE0qlhSyWp55Zsmwlz7Vmw0tbtu3krXa9s+e9/Rw4O1xBvxoGcIyYMIfFEqKsESFWEpSBSEGTJU9xrEwJiSolN/qWIWUgpsF/E6SQCqPMihAlRpx4CZKkSJMhS448BYqUKFOhSoNGzVq1aXddp2439eirfspABgwiGTICb6M1ttxNeGyqple4mZrd9p4MV1e8s83u3N8ZZfUACCgq1GjA0GLBWpqrPN2YAcv8tEU9atasWbNmzZo1sO59r+WWr/ZxbGxg9mJgjGhiLFixVgvQJ8h0VC+VLiTTsWZmjWeLzFzJeYKFB8sjbrX19St7fmVEtLmXuw99f3gzu7SibuwZRHfGqkOxLkyuyam/pZ49fDeu+bh93G4Ib5LLqUuuypOvQOGtovaqpj9qbfu2htDQ4uP/bLXukXeKuyncULyQ+PATIBghIkLsHZtFM5v/MaIYu5g+VCqh1MwAAADA3VGdN4009bJ3yr5v186Ld6ICOPQkSZIEX1M3H3OvNormxg9GbhDdFqtus2XqJI2eTqtT046ndTox3Q5Kr0lZ0K+69R9mPMR0tYMKebOINwt4djEx1KYntD8TDkSInhbrJykUJOgmaZpKOyY5pgISSIKFChcpWiwCokTJUqXLrIcL2rhHJp9eXttOd7LvGbz9aRctvE/rmv2iItN0c5xEVrLZHU6X+7VsPM1hTBd0mJHOMrlOHm8L4mnrtuJk5zeAtbtgqi0J/E8sQJAYcZKkocmRp0CZClVq1GnQpEWbDl0WoqTLkStPvgKFatSp1+CyRs1atLqizVXtpsyYs+qFt9557wDZhV/++OtfoCpVq6n22HHixouPABRhosRJkiZDjgIlKtQYMREgULBQ4SJFi0VAlChZqnSZbrvjoXGPTJo2Y9aceU8sWLRsVQaeU6VGnQZdxkxFcAUFPeQXoEb+94dniRNwecL/IAd84X4h4IqlVFFrgOxXx77RQMIntQW2A919Oj09ZKrfynFdHzuB1ncN1+s/hWMVcCdse0D934J2iancGvFnVUBDsM/xX06coPidJvwQTUlWHo924jeiP+yTvVCHVrTbcj8Nb1/stMo3YnjXUE2T7xBNvuiEf5GCKfryiP1Pzl4sjdonCg4aLMywTRaJOPR5iU/+0IAUy9sKK6Z0wW5aIVY05iahzS/C6R11Occ8BquKRqZdE8IIceLZn88n3hlWdDYv3opaiFP8lZtvs3ERzwwpiNu3cxocuEmp0nbp13zg/jLdYfsWJ3+qX8/zTO7hv7QyoyantToz4UxhHtz7x8hKA+7uR8WruYUZ5KlnJ6HO8w23onCrT88Ia3cnBg7uZ/pSVAic39VzHfespd6nBKCHHPdmVmi/7gQFrMRV9WUydDzycG+n2wPuhYuqRmds7AnRwH2xw7k6KE0qU/gIpGxigWCKQHM7LYT/YdKFSykXOkr1PCQ0H7WWkmhyvPxThvi2YMPEALR+2c4KKjsWLuAh0W2Zy7Pxf+xGrATcba3QRdu2CSbQjWovpF6KRHjNeUd3kUwPA9Lc2vCk3pylzTmP8kX+nHE7c+FQGmq6D/hBn/1074vHKJMlkvR/L8YxuIjH7GcyxytpkvBu9CVDJ076YrScWt2IA6RtGOkV+ECfBbyBZLeBESsHpdLkl218+es+D/i8bJ0Ul70e8Jd2HYZ2sHMxcYTQcW1CXmhQd8geNBNqcY74I/8hYvqKu0QsQ4sDHhlILH8+ij2oSwdIQmoWcGpcARq1S3EPhHji7hKg/6UeO9Ktn+ythPumMpL+OWQdWlMbcAJ3Ec4EqDXkmMzNAgPz18EkIrdGUXY5JLR/abQ+1WpCLckLYdRfu9ml3kzYJkYt5qGT9KO18Q0QG4nfgV5ONpKc0bJMekPhSXijHcPLHufpoaYtH4zUUEnHkVBnN/d0N0gt4sIH+kpwfAImSkEbAMEgnAAQdWd3TDolAtDxTUsdTP6aSMBXoH568bkIVBq6wAx/B+0gTHd7gHB/7dYPKWVSBCPOAFEeRpbgI1NLoJKHLiDamWsgeKCpA1HPR4dU8sA2eHlQhNEDGIMI5YOCwQcsdj+9iDVMyPruGF4e2NQIdMIlwAKnowIgmXasVTu6ogPERQBzlBhbcxL0MN14EKwH62mnBQSaiBZd9WifF8BP8Ki88+V7mvAW68Nz2erEu2LwqHt6dV6Xz5ZyStdTGE7hkkCHG+ShNmiCFOQ0JF3N6hTmN93kLON5iAvFcVCR9vExxsWWpa+XIIhcufYFj/tKQk5FxFmHMlNo9HJvpU0qXPNECg29+h55d9LhqkcAZ0THaUlvKYdmZelbSxDMQj4eDPSyXFwV0I3n4kmAXnwFoWM4sla9XNEe83Un0qu2w6RUXNEWo+haWyXGoTAXQQ/nGy/Q2jiNdROXiEsSqYG6k5zfx4n7qOA6XtED78Sh7sAklz8vGTMCfuq+Lp87LZ8tb6cwm1k3E3aFeVFUHrVtZ8E+unA4RQVr6kZk5A4nIRmSPv05RmK1Uuwc1n7wdenBMGPOii17Dhw5ceHKjSdvPn27x1OkWIlSZcp7eJ7zxbvplh69+tx2D8l9Q4aNeOSxye7etffEgkVPPbNk2YpVz72wbsOml17Z8tq2N3Z6gClHPvUBY38bBwpunETZckNJRU1DS5cefRZWNnYOTi5uHl4kH7+AIEqoV1icmIlSRpQqPvrUNTS1tHX0jA4Oj3KBhSw7iTfPb15BUUlZRVV9w+XGpuaW1ittV9uvXe/ounGrt/9Y6jFzK+/i53//x8bfDRt2HDhx4caDFxIffgIEoQgRJkKUDFly5ClQ7F/WpEmbLgOGjDqZZw3DjCUr1mzZceXGW8Sf0W4/cTCwW2cUn7/lj0iNp/n5dvbPbKEVDIJZsBmS4LLhozQIFMdqW22VTs1as7Xmay3WWq61WmtdZw7Dwp+WR8SDkIC34cfgI0KDQcL/n+sAaffD+4GciOiACFAEsALWwWbYDrth32EGo+PwUWAkDuOxTxAICopghkCMIdQusPhn0nG6xwycYD84CPaBPWE32AN2hl1gd9g1rj8SU8PBoO+vpDCEHTc4Zeq06tSHZMyMZ9a9ceAY2d9Qq1ZHfETJUKHDhBUnPoJESZChQJVG7W4GAcreqIBG/2Cgwyh6cHgSeDl+N/a5gtOfX0MMIftZ44nJTfsS3yiTfG5Wil9jJQEgoE9+FwjQpz8ABEiFBcmj8XWDxbKGT/WMpw2eXW+w5NRwGWYcabAS1nCVz7jc4HlWwxdKxoMGaw0N17HGPw034CYBk7BJ3CINYLmhG3IbToD6IS4G4rI246ogru4QN+Cc9GcTL2tTA1BPJos4f9ulaABQEAQUNkJzoTmmfUJ3zpn43YgwvCVKoDGgHlE7pTOjNaWfMOTGgCsj7ox5MOHJlBdfeanZhqPkYgQxFoKN4FvlPed7+747k2WrJNsk98JY8BQqDFGCTFmy5ahUpVadmFqF87rt1ee2fg+MGjfh9HhO+CTO55KC2I1BT8IkyVGhxQCGFQduWN9a9szfF2B58SvOwGPrhWVDWjZLy0tlebVssrXKOgc+u7qFcB3xDzxYxRp9vZwG0Z5V6fWAkazj63tch4ubpaL6s4kJomMc9xvV/kANx44boDt+NAbRc8kiVkTY8oEWIoQ2ogQ6UqXSkyGLvhyNjDQb4W7UU0mWvVTitT11Dpxq9QPZLRfRqHcXz3WCdkyn8YHrN3Yb0t+EiwfVFRngeqACu2o1UC5rJ6xDDxl3jFDZmz29f8JTDKxZZ2LTFoxtb1nYs8fGBx/ZiuC7ZxzwEkoKEeLJIUkxBVSppoq/oFQLEZ6GPKYQHFu9o7O9L1QJo5DbmwgEB9g/F0wJg8thg0wkpyQ4PhddCUPMwkdVKC4pLXB+LwglDDl3TQCAIVAYwPW9KJUwdjT3jASZQqXRCex7YSlh7On5hXBALJHK5ApN+PfiVsKoakZd/WBR88j6Y/PfBQCA6DlT2aQrO9nGfsD/pLPYAsAIiuEESdEcr7a1CwGAVRmtiX/CX/RQyIqq6YZp2Y7Hr+7tYgDgKmE0N5NdhThJs7woq7ppAzJl7IIAoCthtHeTMisJcZJmeVFWddN2A3J2UQAwK2E0uJMjAEwo40IqbazrAQp2YQCwKGG0+Jtg8ZiXdduP87qf9/v7D5Ts4gBAxFDC6HJspg1gQhkXUmljXc+3AJFdIAC4EkafZ1MdI5fa+phrn/t+/+UIErtIAAgljE7X5rqVsLrUXd1D3WPdU91z3Uvda92burd17+re132o+1j3qe5zHUsdax1bHZhqFwoAnZQsen3DQO0mMxxG0+j/SBqddwRvDwUApKtNcaioWhBx+KcOralH7NPRLghZ1U4FTEe8pOr6XgK96rVvzTUNHE7pfdrYEq5sDyI/M6Y1T2NzqKulENfJQXVHn/dKRZSQdRs2vfTKVlAaI6pTloOicyJqJQV5CctoyrtxL7N0EJlrjRNm6TAUKtV016E8KwNhQzaWSveRpNCA95lBTAMWs33/CRxxLpqckvYCEDUoy01B/EROIV3n5zGwNqeQgYAszx6PSq1zSsHfhJozf/RNUPN8eMgKwzScj54Yxsnzv4DDX+AFXfCFXOiFXXhQpi0EQG5zzgpErE/PLRokpz0uBXhlGb59VdAI6rLqV4ElBwEQnOiyc46n0I7xv6Pd+c9L57XC6/wGIA8FWPHfdxKgL464MLt7gtijfo9iZH7tqPNxgPMM0BiP0W2kqMPKUOOagUOe+s3fzgN1tKnoqeBUyBIpyaqrWzVWjy/6r3yB3yxQvCgBlDBKHKWA0kKZWIwl2y1UH+qBEJuQsJCcMFR4Cd+FOYR5hQWE0cJYx3ngvUhBXUz/TfnvKBQQDX21G4omKzXa3TnuU7+5e/UAwhputRI1ZQm0o9hQ3Cg+FEpBTSZ+9b2r/2LCg/0bGeXCgWlTJk3o1aaaNOb3c4vdbDebzXrT3zQ21f8v/n/o/53/v/abyK/7P+3ets9eb3rVy1YYsPew19tT2BN99/TFG2SXw2YySIJrlFB4RRjQr6fP34K4cOkoAWj1sk4mK0sAqJg49KA7k89FqoHfrkas2LDjwIkLNx68kPjwEyAIRYgwEaLEiA/vFyWNFBmyI/xpUaQ0avOF06PPgCEjxkyYwjCDZc6CJaseV5otuzH/4pxNbncePHmN+3d4Xzh+/IE5qpgvj1qN2nS4rlO3Ljfc0qtHn9vu6Dfgbmu5jxQ1Qg+GMQ+Nm8jTCAIFCctSSa6JFZHdEoXnc0Wac1R8vjguBNAv9r3n52OR0uLbTaOy4UXnA12fApyWnuUC5Mh3+cBNmxmSzzouX409yNcmo+aFN+aCnvruWcmZt2ilPGVylStRqUq1iqEFs/KtunlW0+JHzFgXF3MWLEuJDSvYAGoKOIDdHYD4ZyA5OzDvCAAOvA8AAGuLgR00cc2Twvvssw2uxYuzJqyQp15XKd2yeAGSPB3DonEERByLV4erXzwcGZl3+AxGtltZTwm5fOsY0iCpQzy7AK0ygat11GOutQVD3a6cXCSuTovMxKJa0bE7729s1vc0w4URNCg/4JALMw/XleJAMCZ5zJazFEx0XS8bVpEfPchSIZOEwikLBR8ldzgE0buJVumCB2M5LUCYS6WlzpaO5YLfDIh2o3t9ioGwTuYImsH6vfP+clY2wKTAgz+IwvJnhXHQUBCR3h/tw2LpqWUxlmoCyJH/p0xd9aSyPMTMVHRozas2/aEjFWZVqACdnVuny7jpBBvxwY2nWvyx5Pql6jd8DabnesoO/NXIMW9MKY25KSqJ7TuIcqSnAto5efuGVg/IBEEUSD8ZZZ7+LWpSOH8I1EvzNTP0Yc3HG0NJ3jlUMV4ZTzvIzP+hs4cgCiSdq7Xzp9S/4UKQIjlrAAQ7eBkOI0EQRdK3wJWggJmklEhKeYt1mmvrrX36SJzY5JSNJ/GuUDvYbd87AxejfR2Fpu/vIhRfEh+5aY/F+DD2AOrkOHAFSL155lOhU8H7M4kmszRSZaRnE2kF2liE0wCigqmhMJqHpbAj/YXIn6SiKfhZgDiI+2OklH79CsUWFtkP5jWGI2ilWlEAGH75IoV0WZTMUJKify7deN8/oCiMm4ixIu7Rl5EErM73a5XGw6fpW2ybKkpcIlFJJl9x/QIvQWx+8EinMxiSyQYR72BWCKcj/EHxnqbIiU5PdwmGixTnB05HMISkedSCwwWUE3m2V1zgPsgRBNHpDIYkcoW4FFsChyMQQsAix8nnI4SbzvDdPIUMzVR69uJyDmu1rTXH2w2WokQp4euUMJZ2z0x7ZbcXwE78/ry16IdlpeUadFv3IyIEHh2racwOZLXM02QuVQrLe1FTwpXOI0sp1EpelBjPjVNx9aTc5Qj4akXk3cLihjcTXp4XnYvMhZyLsIgkU34sqCJVyCosLCLRWrcMKUR0G1W6UGQkSU6cs2aMmGzrmWpP4VvzQ0C/SsevtYs3MxXF5d+L3UDugIdOVuH2d8ULTkOceG+is5lG6eQeF/XqjBhEL2DFKO3I4L7k462ps7wGgbjEhiAszI3tzST3iU5BcpRPnjWNkyf01A/JdNWSRPF3mwdfnt44kLqECxpBf1411YUcL9dNfSGDc76u5xUNFQiQhZBf8dzSkRGrhaEjKyWKiSMKlinChtOa6Nzs3Ew814T1OEX6bwz53W4Yazj4IEsuz0Nd1j0ZHe30b2FTk16Qm14/1a3nCHwp8UNop3ktsnPnbNF1kQ/mk6NfUsW41u/GOkd8/T/vY5Kcvp6F10J+hboZ1ldaphGpedNYWw3rBEJJ4Ci1QDARLE7z3GctPXDud7OeDoQ0rFWKZcaIs2aDtWc3dF1Z3sXpKBQKyzgsb3VF7lsSs8cv25rpmjstV69CanQZyOnANsI6NGkBMoaQE33hCxN5OM1R5eT+KioBcoYYE5QodCvr4Mc3lAPhCVusixBSvpgi2+2mIznA3ot8o6soFwhkxQTIk5tigypRgUUHTvB3RKENNArEPfHUKqthDwbPsc3uDvUoXo9LT8mT1NttybTkGjgzIkmXDSRSrvNtEA9Y0vSpKbe3pD1ujJoL1QdJjDgTUA//8wWwC1qSxyxrr9c170gm64jSjDurOZdwUm5zHa6d4U9uBn99+4DWWsJWG8flEklSp+lDXZgMkE1xTpPPgErdyFIl3smmpjgQuAy7zCY54YjCk3USDg+GFOMywD71SrXOa0MJ857DHziZQPifbNvi0JceAiQJGpZ1HjquXErgfs31HCB0fBetJrStzGyTE6uuXcXKsDU0zEmkDTyOB5bEDKav0LESkCULZZuuRdkN9ValQDK9rvtTfnT4w5mDQwyp6A25Bx4lSDmuohg/CG1ojO/NfzmHWCavH1yHPnR00kMYr9gfJBywIyEnVzY0Q2UU2PVmydoyLZb0y+l1qhs7PUfdmKRoacVYxlk63gNax3YXexYoccBNsT8gMUtMspa4k8/AorC21XY9iQTcx956irQVvMZSI1IB92ytx9ImVlLeqGTKZGSCqQuuBNXnIRG5fhoWxUhbZKPzABdtVX4qfvioORkopkm5ZrYehg3bglCC6qjOghG2KOjGTk9zxAiTozop5dhzuWSuI9RsTRa4OjaPH1zn7PR+VRUr+2HuBd2KZcFBuKvUxbjvJ5aBA1VkDBgxRdQlTbGxEfm1pC2EO5EnIz8TGDFwFVsjeT1acDXtXlkkMgX1HlEoFXtce03LpUPBqiUUjHFN5wga6Yw0Zkf+tCiQgbBEE7noWCvWTVdQHvzEH81H13thzUF/PvBwg0HnNYVxnyMwkJkWl4kh3uA8SJK73gFUjozgiFNp3xZhGs1URkA7TfwGma37inTEN+Tam2ThbzJ6rrrWtaF22Po6MQUSo3w/G7vZmEzI3QfUDn7SqrPpXZDLepHGwOC8kJk2yZFZMzKN7xWzUkvF9c6KEc3S2jWNsKAjo6r8ScCwgvqTV5C/jMyteWtCEGB3DqkBXK9jf4A9zcDgQJW11fChsh8qVgs5tVLo1O6znVsTGCtQYH/W13rHLrm3uWn1XbVwYAOn4Pb+YVoNS3/XoVeqVSjMGw5vGlPXh6lr7mJTtLL1lMyIotcZ2vE4tdPFuK2/fYMUUCvpUWyWqoydrwMRzCnJ9PRXIZ95fxmZ22X/2SwythRtQsiXRpJO5AvBDDLBjae9UTVqBsaKm4nJbujgls7EPsGFx/6HEgqp7weX5bCW6nkymCf4hs51DV8rUSY6XUocDlnQ7WB75xtp0RaVU4diinvhc3taaqHrhjXY4i4OFMV/mBobr+ZKjdZuvuVjm47MWCpBPYatbZOj5eKGhoH5XP7FmhmWPQH0m6lUvu85hGGiLsXxDavAhaA2xKN3SXjV2n12m47qz7wisFEZ8s3hG1O3Z5f2LV3fd/vb1WYwz/PJwzTcCTa82e7pm60qari2dpGSNNCGClxYVm6IB+8au7s7XWAssNeF+2+K97roxyQQrn1+kok5Lhuijr+j1Y6NqlLich2CLM9VAYj/OAvOTKbWm/lh+AJ95q2/22e+RPwffGlBkDgn5gNOs7I0stzRJ9rIrngSJlrahHCi7/v9GuY9Dw8GwrkQDDtp6J80nbjR7YTtbj0miI2jTRoXG/2OEONJ1dA57ge9yx2JgwnPe752+w27eWnq90tTmNTCUW16aw8wqNEiKBGN0v+4Z1sxEziS7emxz1m6xwtVBSibURm6d3JrXfqCpb9nJBqafRyO0Yse653sP8ZNOh2ygtvGg+KSB/eNHu4efWCc/E3Zz4gdsNh0sWTqCXoH6VbgXonxnXZ0yisYdlTdbntGbGavq23vdd2sp26squiCM/Nwz1TOH5Mb26I3rqJYREJ7BSLOmnQqP5S8VBQhqRclEZhYFTseCgvGb/eGaKLHwOlwiweyHDpdEMKpkxvZoDeqgp3TgHi66cCfKeIBw99r7OrZ4hH929NVw0XBi/xs/mgxfmFeR4tU33eUmuXjMM2phYof8nAc0WbT+VRfeRmHJ9Yko4mPE9tWuaOF8L/YKQxjdWZT6Ec0hn3Fom64XtqmRNmhrHc5D3xNvWYGWE9p4j8dWNkVrXnYHpQ5cwGwNAwvxFRhZzFY2jZ4UNl4iMK2ADNkkfgGmzCH9fCkbTwiCvG74sXPkZrHZMOCBxBfbqWjwqD5QOGLkWmmKh3uEX4wjorck0rN8oFBsS85XLuA5mbqyFvBQ7mH49/lUry+53V2NFOLuNszu33oSYRljsvyMUmbz2oTK2XzBOJyyyyapAWaBGHDSvpmYCZyY0l9SxJsKtJNIKMCGyekykeQtPBpq80q/zY+Dz+f+twb1PinKZGWgMZEXHBYJ2ZyI+X6Uc7/GMWW6YJkHwT63vaY7bnRYWxUmeVu3zIqag2P2qZRTaV7mIUzMH2B+ZrpKEdTsqsLObzKBaTJ7clKmfxOtRF7zetzfv6XzNffVVFaRlithOJJNJAUci6K9oegVuqaX9L4o/QfukaGLjqhMIKMA/LZlT11jUa8UgeORtkkwxwYFFX8lgptIKIyDCrRaWT0IC2c12K3nMW3INRZmFVFytLQVs6P2UiEbmt6692z2XtT7+qyMjMS2GnE0uEK18xjvk3l6rIjinJrboeTLKy854spNyJXKxtjEnNZ1powJLUhrqSX+aOcrx9peupPuX/+mKQCTqDqOwwgGHo561UCinraT5PyCbh8l1q455Vt8y/MRwEnUJS5dNnI7qRpFq9n04fxLkhn8e8kawKEZsoBV3EtN5sqpk19DyLdi6JkBIFcZJFZgCc1U4dwQIQRghVdgIkjVEQCwyBaKuEAO9R2wxcOzkim/BHuGtbCWD0SPbYCrBNb7ywMvP95qwLLJGfd5e3m0Yg+tK38dyg0RaG3ph5OkOGGwnqlrkcr/o/mzo05C23mWWF0l2lz+Ftb7iCMReduuTw9aq74TWCQgVWlteN11JiUFyXbdOvV8uOIW523mhaG3Yo1Yuu9Ov8NcN86OKtSuVv61Cc2Ml0YRa4mcGxRtUxp0ji9aNd1jZRVlpPNAhO8eVd6YY93yrqLskAPhe8hTN408TsWpN75/v7t07tHFK+AeZRrIj32iFJMBciy3joOiC5yaQe22DeLj69uQjXIGIWQPhNz0Jm/mGYifGel8uKSSrjDt1+w6Zq/7nsceb65CLFeAYyReXIwpXaXD+eDpN1VAe5veX3TZwp+QkIJykqSUCv2yGa2znykvgCj1iRcC5v4KFsQ+MMnWIJwFnfhfU+M6xfH1HsES7W2+fjRMXVuWcZ+/JlXgaAtinIIqIFPWh7VKHN0EL+YOUG71rrabNOCLtD4evFUcHt6CnWZB71RZxKAJ6sk8KqRyV28deGDm7qQy0JGx3CoszPqWSDhVo7EaqL0lWAoIqg53DrgV4UpIVjeWrKnGUKp2U0iBstvlfn0Rx7XzZqfPuEl1eRDYBNHE6p5Qwi3caWRcUMgekXieSEHRTjTBSvWCUyZC08Vn0DJgfAloDG0I/5bxA/7RPtKsxZTTcyuLIWt54Jd0zf3P0aSTAxHGQ6b6iDeXSSxGIAlopxGF7of+YK8TW628+C7oHiOLykEvkwiCA0Xyw/2a6Lv7yHS/H8xUMl01hrBvZdGFiKk9QLVa2IJMRJLfmGwQGNaeBPBp/kMHfv5rWStAIJrCIAP32ZN4kA59GNjwQPACHPVERocSwhCknTxVuOSTcHAko2cwQpibCTPC1GUUmgjWa2hwYXTEmpECi+MI9Oh8GAyRQ0Oug0coYng3O48D5hvsZTSzXfOTROSYMj4rip6hN+9VwkEux+x/5M9wWjtxM5/7CVwlAtZY/A1+rOHPRm7e708x/Kw96v3vCI2CGI/Jor+BgCJ385y2lnecnaYD///Spz0xJqzWq9WpAkIxNzoa3VaDlv3GrgbiZCzcioR/AOAXZbrM2Av0pYluxjfxZHeHmVZ+wzClX7oSX8Bma/g+Z3rg4l5hLuTbgq6z93URvU7rea7Xwqv9neOnGEOI1xexHlsOkg2MlhYOg8OdahauuEnhIq26swUZd+yYxghEHCRSz96UIRS0x5vqTDQrxl84z1MsviZDWzLjq4GXweOuZUe9wvDgNcYfOJopsYK5qtq8xU0r5vFARALZofKeR3F1FLajxwbQrntrqNkyn2mHOXSbAmADsMtRPKIF99WYw6/dG3vvnM0e7Mi/GlDE2fJU83JzG0k1c44F4CLHHY01ZLh5Nn68WOyJmYO4wPo7DIkYN29rc0UOEaElAmgvG7BOaA/GZCQ3Rm5+fiUG1a/cXHy4QJz9CBGNdx/2DvNm0Y2TFVPXZroHlJx2eDPtQ/lQLv89rGinWoT6HmQZIfA/VCb7tsWiVSS2IgtSzkI0CBYMu5y12I7cVvzZsk+vbrQMQ2+awCaaDuBX1+5kY1OYLCvuExBFX1NKb5sEVvPEhVgX3V9ZORo4kHFS5ZCLjY6fxCecyRRrG8yLHX4XdmLH8DJWBcLZbcOZmhG0EeYHEHF/D1GuqMnFHEpEH9Ax/ZoKSfhV6AMJSBdpa/wUZ58QcxXNlZSILu7yYKrWjDR7mMcY0ONNdxVn0Hpnmt6N+ukK7VeE0apm3odLJnde1t/YFSVnTjoFcjcnl2D5Ef3mVejxlp3dQzcgRUTb5tS4WPHqtmZ5coVRZAtMlxEKEwZikOpthnKIsPsYcqyrYQz8owimlzbt2MIq7yC2M3nNs3fGq5+YVvN4wFnP0iq8sdSiLa9CFm7c0NfmU1GUgwniYXpZIxlEYmjCmk20swiHIG0NxmjsJiOly3TZecp9XFx5yyhbAN/pNiFiLbvRZla9oAoZQv4o2EHiBE2gBBtfniZMwCaprlNsdkwOIxorduNWbJTf4FXyzp7ChvD96IR+jaI16buUtHsCk/FGS/+qKcquchpd589yA+FuK1W3opVUKA1m7TS+PsGuR4AeH8aix9GRTDXGd8QoGZO+/jYtkb4UncCJXIcUaTtxo9fUE5vWDfFpDfxVrHJkPKOTTbPwtstb/6eqIYwmOkE7J4YEYJdLoiB+yiLE+2DqPYJZtbwO6t1nYwGGrTiTkgIWTMSrj4vmgMBFkYmhoBrmlgZ6Yl60hib1bAztZiEU1wnRUk/uyYsCkHPbBSAkNGKNtPoZAxO44MJgU7HxCBlAcbRPTjFeuiGIK2HtvUmhSDpKWfk7h7trNpo/es6ypYtOEXcOL1p2+Ujl3GfeSv9n44CpVnmt9CDp3s3NGkfIt635rC2Cv21Y714rGtntc2kwlsOTeSTOa3bigml+xREJpkWzfCapXjYmeFmwxTo485ucy+BsYu19q+dbyM05rZJ+5Ow5ifOlJWZwVxeAo7MZdgr4BTo+LF+zOz6N8aeck17+vL96a2H01r3E9jJzxPOFeVzb6K9SWCRa5PpX2Qs/3uuZTLKrWN+/eq+9v/7z7/kHwy/+ftDQRExP4/KF77n2L7N3fmMnP/64tOhS2hWaufzoLuJhn85lJhee+VF2ljr0wXLiwzveFrds9l9XRjmiCdDsu0u+6i/XOhd8CY62KjomhsIKV0uNc0dAB9/PDjbv9Pz4/3I6Nle752z/YAf/1kGgb+WBoOD8TEu7vHEQSLR3UUT/330x/u+2z/2Rq1N9m733fvZ1QYIce4e8XED8XEe7mCirWn8Nk3Np5DSldLsvKU4E+3wmnZvTHNKUJeGz8SfgwfMEDOcrznG19NChtdWx/7RwyJlGWnlaP5brHK8cY98PM33ZgPykoKqw/xNNFwBb5KFVk4TSKBfjeLGeCNmrZaJcIYl4pw1S5QO5JS3twBPVSzz1ktEzuWEOSuE/BPOeQF21GW+zkRMCIQKhEQ8+jyrIrejIvNlOnJcMEwwNHzi6xww9a/F4c5wuFOc/5k/DnywHOvSTJBPsQv2tXMODLKzV3IEgW9+lf0CLGwOAb6teD97O7xfK94XUIWyaw7/5AJ209TXbfjqtj5nVBNn7ctrAuYUPmdfs+Gt2/yYJvwprW7Tlte32ybexqgSNRRTr7FTUBJsE29tXC44GO3Oelkm18gzQAVEJ5tVi8ShAAwNTP1gMAvOx26KBpOJQyvlrzEcQRVpoffH76rOlX3eQv7/LJt4ltT+XQ4YfZ+Ow93vjHuhnbjzjCDytOY9sSU6OKwljGgbhjgeFliXuG4X5+n6cqCN82HVf3O078bmHiSnaedMAFshqz4rESsOYRJJlnd6NPSyyOU+cM725n4gsjt3OaunKDGhszgjs0SOzRkXS+2gZ8xu94YPsZXgMXkl84UJMM/+1NzwiZL05KkO68FEytDjG9apaqGaW9RIJtW52KrimMjqwqgwUx17s/iIqmKATQByF8BIfP2imR6EssU+0W2Mcx+MyixZTFBxUfXvwmfmP3zlCd/yzH+YGYDrclFLUClazKxuefk7hIo9xTE2oD8mwNE5NsjFNTZIST+girBZHocPLCdsVhGAYc3NxzdskpQ0tV7R8DK+PDLk/nHlv8Tao6ZJmdtxlSWxETUF0RkWrtG+kVUlQPSeQyDO1joQ52AT4Gdl64+zmXe47qz7XbYG+IK0e+1vI62Gy8POFo+ztmWK9xvv0iTKpdqF+No7BAfb2qi4AENhOFTpefY/PX9AiwIC45DjwWNtobmvg1+BYVypMiQbqv2/NgVcfxjBu+VwYcTwHp/rjoYrV3Soo1sq3jusICWQ65U49Zdtzv3JhoHXbB2s7UE4a5sgv/YAv1ZgDybvO+98jn26HP3pXobC21UV4r1vaY/ehHwJlLrpVFBp6XvZKljtr5q0dYWr76OPtPPPPjBNdnhkRZ6karxSUcOqCQcyBJsujqubdT1bxvQ/MFxe7NfWurP4atT9vm1YUineP6Y8JDi2wA+fVAAGQ79W9Qtg5AvQCndqPfutkTdHoBbAgNRTmv3H422RBNW8xzmFBQsHQZU0puBN9DuPUPzNSD/OYMFGwUBi2BghBqi8Y9/3X5wM3O+NF11aFonvRTwps5ucYXt5if/NOw7+t2xDV7Wep1O8MBr7gY+e+OzdJAg8mxeKuQVmzhgOGHYuMc9cYk6r4Sn9dZzNJZvcB/S7N9h1eHKrCFzECngatIne1d3HP5kOOjhcCo6aOxJ9WYPB+VMC73+LFJjiFNi5lmUo73OUDTJbp1ulROd8pn2WNhq2xwunx2Z5WToAaSBTLaceEhERoogWOof8D7SnL4+uzmefUbdlV6RqjrhjOjD1g8OnDw9FBjqx9PRmDrku0cod2Ur3sl01Uljg8RitTzXZcCpBb7+/ctEg+B51H1F8dVmC2Pch9MlCyIf9xaDQ2cNeCcLqswRRfaOeQQRqFME3yMw3ys8ZPv4fI3/+y0wOPCIxxP8dNhnObr6WndXcTuTJW2y3qAzFBqesn+AEcynlszNQHGVG3dvCa4bqQpb709VrJwVaSSo4c0onOPvfyT+TaeUFn8uLgIQzuzfR0b6N/5Nvknsnc0MFciY4W+WUGgONjfRLtbPR0jSzkUKVFhkWP6wuLFk6Dqsn94Ub7d4GtjPkLTKavA3fBQVR1ejyvqG5Ky2j873lUtUifr6CKC9fgBMHCuJoeQzajTfgJu/0TVBVAGQ20bz7Y8jcMZkEtAvXWi5SpJ93uodrLRN8V0pTChBek79YDXP+YPbB5/dbETahMOA5B0Rqn6pKIcVEDt2K7hTfAXaTMNh3Jepfe3Qbivg/oCMC0D7C/lMBNJMqAGjcDdMc/smuefQTJERggCKgmVT8hwHqZ0MQR4gjmYtg8Y+r1gLEbuluAXpTks8U8hcgEolFD/dQMkdfBBXfPySWJgrQCdeyx9a0JBFrGmLjG+oTkhpagPUg3WeU4t5wahERCWAAGZlWPPROSFbyT1xtczKxrugKvdxATL7cDAJp0m8259wiOjOUWg2T1aROvmlJnZGKnAWJcbczO5oAkZhUNMLqSfuMUtobSSqNFgAwgO8/OWx/MAJvRZW/7PLyv9PxeI70bYuIu3fd+2u3737yGL1PNNHLm0AAive4iFzIsIndLxMN0UZ/A4wTbXzdLCOJwFyBHsjxw/YmYnncTVfM8OUtFXmJyQXDeyi5o6bs8y+ldcPJxUQBftqxcDzjLNBFSyfdlxkhtXJ8YPnrSKKgYqh7rFdQWj1AULcZebobGnn6GmldtCQ0JoozsLfR8dOdvBB8m4XfjIWNjZxsTaqR9aQnL3pCgYlAR0aeIOHqC+MrLLMaSDGgFMDAkY3l/qiSSCi+Ox14Lf3a+uAqquBX3urxiqqNoue7pnhG1+coIZWvqyuejawnf/JJX+rHV3Xpj1cqfv4uCuRJqL0cR6y/nJBU30SMq20Cr9hsNxcdktjUo88oRQgyMt7SphmYq9DlkQBBVeFWsj5h6X8Y6B/1rqlpJB1yNGd5X8uL7ZpaUA2w9ey5Oq5vpiDN/zH2sY2FoI+pVoxV7frNwUdFjtQWhjcszLSMZCVR4o+fOEfLh6T7XP06NLZc6wcUgXIYpqO0pY8PTfhOyHbysrdO8tACitXTpnzGry6BrVf04JUxn2lARLiHZ3g4wODpRNjlRVTkLX5SLhps1+kEZuSNXK1dBQ/ksW9/iHILc7w+BVLnxp+N9Qr4CJ9dXqNWUbqRP6rYAGadTu4DnZTzDG+Hsc1Pmt80QBt1dlYvyMY19j1RIJcTqExGNjuUoiOcdUs80P5uGR40O8403iFOaJxebZR7lYxLBdmBNHQBG9IY0qK9wLk6ejmAjI5/4BL2H1CIIDt4uTriLmhJWiQN2MUQyYFcSrxnFdWfiXbyCnGh2fGkcU0PQHvolkQ4l6IdAFJk1oLG38KsVBP8Oy5VMrek8bM0KjWM/8dSpgXUxm3xAdY2Ab52DnhfG+vAABqnerNuLZPnWiZA652mn2oW4ilse1B6nXVm+jUHSeYl9RKByV9XkBjXm9nRlJre3ZzTS3QG5tnU1N7UndGde52NP+UVvt1vd2dvDWjOb7laXL6wtxANChIaL1+7VlFlFFpSoONXVNDVVVYepZufFaZZXnq9Iy/HMCK3xCy6IK+rq6o2UDU1M+ObV0LSWEKCl09SwlhSEnCeDFoIQgetPp/w7fJZ2fNz9Ci6lXfLyt3xy0qId9ccyBj+d6ybsPXRZ878eyRa5ytp1SXOwdIvSq331WY4zQuQnHUzUlLfKb6g9MkxvuHnaIz217trznH2Fn7R6r2bG1HQF9CkzK5wKR3X2MLS+S949o6/rcsasex5DWjf1o5l91BOwmU0DnCKthnZWesb2NkYGdrZGOjbWXvvM7bV2loDVRz7QeD8fODBTfk2vyJK7OkTj19ZIYq5EEVWl8TjeyJrfuP7B/z/E/X7r3/wN752Wv52t8q0VFyK+dwGFWJ99RLTWkkFdjvetY5Y15SYVnM1sTbZYbvGCBgYtDcsrlI3UtWvvWggZNne477Hw9MB3knCd4WvCglf9TkaUXdRV1H30xKg73Tp9j+NG+Llr+rM5k5/VNV4XxnOu8pWbNUb9Oq6kH4lq5vrpmD1NQDTYXXhRiHo+hF/tn+n92xv9MHpXu+dnX4XQoybOzHGxZ1IdHcjEIFpQCyO9owW9wUHO4PhtEX0vwx+Aao5x+MWhQ8s3RRdlLScMAbFLSnbNcHzTRNtmZZGlebut9dBFXdHvclalWenTYiWgZ6/jqUVDjFwjbeSy1veXEa7ujz0Wb7no7IHxSnFWZYOQv7pzv6JJaP6QPychJNG/gLKDQDAAF9mBLhrlJRg0Imbofv7nqcAABiIBzAAzjvK/Dwxpn7uZb7uphhA0dnbEZRs7I4qtpXUl3Q24RSXzMTGMfQ5DxMu2cBxnoBGZuGD++LC0KkJrIpvwnOPe0aEhrUXVPXUjYurQAmRLIT3XxKubqG14F3Bq6juANBb5D2QkfkPqwb+4zzXT57en9bkJrB+EfU8hu3DktMtKJm/r+Ff7kOjMYuCB1buis5KWs4YgyLF1Deu2vwUd2dUg6xB+/oelzIJqI2bdC7ODf3k6QP24NjyBXZQk3Adf3swztoqGG/HUhtcgRIdn1+LQI9fc7yfbOjfapMLEWYe3ud1faXhwRMd4uCahvcJLUoNBFzD5fZdDfUh1pnlFF+Wb0JQsYKGF1NjKLYsqyILkJFKZCQ0ofnDpt6QrNirxSVch7pClZXUHKb4QI9FeAjVQpOe0QIfSobmhC+SBdFgmGhnK5iMfV17W4NtUHoMTq01zCU7CZVrVgI973K9Ly0NRzdQ1XMr5I2DXNylZSM2zmq24w81zOzVzB++Ah7A1UuxOX0ITNFfw1lfss4doddT/KSSpgwUrlPzznxWkgbSZnGxyRriuogWjrmj7Z2fmdEoMlwpjkCLYXTztMBdDwJsXItJ4EuIdcojpVJmP+kNYpsTK3xYQpz6UAsNsiBRUxEUMIngiOZG52aqObv7/h+ivsQu+8atLECTinWx0dNxsQEK73MJwV/1kjmLjW+0RYYfmrnZO6V5+3u/cfKyUZ/K+Vq8jc9fLMrMe4/63Y9kqTGxsI2zsAVC1CfmZnZ2Wup2tmZBHAWsF72REOm5spmC+1XZhV9qn2cuj49rJXEUO7zdrJIY+3IzxWuhPXfTDEAdk8cKNfbxjxbil8PplY65ENLhb641vIEnE4B2QaJiD6esrg20DiSzhTvoeszwsxzHFjOv10TwIEXHRw/jtavjR0pKnr32z/Pv1yyMsO0JGSuJ8dOKGEqovbL1K/RSQJdncpiLV3qIq3t6iJdzerhbc1RTdKBvY/LbpmTfgJZYoM5+SkAQjLC26ppmtqombWLtOZtlbRlxxJ6wGnUIRDKprSVH245Jhvxl34Tj31ugjQHCtTgFS6/wxproyOaa8OzZqiyOjv8fs8KEZqvrTinFjzdRih86rXZVbzTwG74PdDcT5aCkvJnpI0JFCICkSantBvt9BaFqKU3XxHDr2jVhYXHRjg7RxSJ67VoT0Y6uNBDaEZSdCPxJSVyCLOXS8yvSPQmisv/hSuxlf1KRkCJLw3z1mZ2h0HWLhN6ZJOv6LWY+XdROk0n8rcl48+otZhTgnd+HGkQPoNFPcfDlM82tBdpMzQ+x5WLiOkcqnqUYxhOUJZIgLho0yHRoSEFC2ZHUV2PjqayCn09/xbl37qPnv3RFXhsKI6j4ZnlnU2rrkhNr68B1ftUNyKWt4eO7LU4qEXLh4laSKAPDHMeu6MYbn6ZG7hGseHQNms1stDDqKjpGki3eTR55ztJeCmHSHnqGznamDu7hjoBDLNSiZ+5svDrRYiZSh5/cTqD5lMiNZVmVy9Y1GOgrFE26xZFJZkbgcJ+3gvVu/GQ+cpv6ZllfnPc9PVVdG5WqpcXR+CyCHy4r6Ukm8VJFAtNdi2Mx8R1xEakA5vqh3JGDFbDdnlPUNTUzNbvRg2bRl0P9Q8q6DYO5oL7ZYYFXb4Sed+Ee/05tKWvZ2kHw7Wp7z/L4NYWFjl7x7aL43BrLgntE7x8TrQSNKY9yH4Ob/9XAailp4zSASrau7wFNoMETIHYH6/xsgf8n/3p0G58a+84sQb+MTiUe/sMOHuABGO+vPT0tuS+k5cS7SKakAhhJoA7ZdQcqDOQK4OhEEHGzu8kC1o2ecX2QykxhYiSfSeRPqplGOiQdYCOOG0Hwd2LeGa5EwuzPsqgPdgzHK9oG9JUAk2OTbfW2rOOFd9aeMNPbDQ7mzarkaL7nrZkZafxv30SjQo+2SfY29vwPHral3yoRsgnLywkLyc8NDc7LDwnOywXyJt3+ieUGqlVL68MrcTRiPtwmWuqDvngaSc36srIvzQAWkWeEbO54cLfcTPvovQU0Zqjo0xYmJxI2lld0oYvz0p60CNIgjelKrLPqOVjr6Nlb6evq9PS0HGzZM04HT19dTyzBSkfXwVrPZa2rTVnAapAe/QpuvV/iamIs8WrVO4/0SVfqx+1CR0M9qRfLrvnKCrdNEuJC7mDi6y8zE006Y8N2zclPDqZ6ku8k8hdsPeBH4vlcVZq4JrEsWQJKMwuA53YKDn0tjASL11hIgmOTMROVmQM2o7KT6QAyUhYXieNxrPVkJw1ZGFa4Xijf3eAQOzkCYzt6IfKYUnzTyR8JqZrogW1o7lifzIM+SO5LIWNdgUIhoipoGiwYPXM9to/H5VAD868IRngip7oz6J4fNze0bzbCPrBcQmT7qrmAeP7866MRoKcEC6g0Dlxw9n52dNV5sJ2kayajjb2euFji/d8dsKm6RKBqzKkZLvLT7EjclHNkaFcnJxW6F7EcJJ+Hk6xCjr3Rwy9LCnGlSlByonBME5uSxKk4y3toI+LUZuSxC3hw2hfNGUYZdJe7eVnbuJb/h1T8D0lbkVWWdYnr2tmtx0GCrwurpOBy7KduMgOwISnPkp0vP8rgz/w+gQgSYUCnDK7z4piTDgMhJE8Uqu8HhhVv+HdzPgGP3+uWTrjEptPv0DO/32NAvKFPjqX3xDCeTJ20C7SXTJW08VMyu5kNgF1Cmgj0Fw0RlZN5VpDoueNXbV0wycSCwEcrRC+YaJcM6QDb8DL+uM3EHYITUosCk4RJCWd2L1QA5MBWJ+m9F9AeJzpz3hMMLzmit5V+g6saqE5R+1eFMnnw3C7JYuOkV+M//iaifnzAwbuv6f2cx78tNH7wmu+PAzXfSI50fCt6rsIzYWP0flER3r6ESGCUyBlmySPvyot1N7hMBxrTJ3QXdtlN6wE/X7N+iZVV5EI3gFFX2AVKVBGgekh151YgmPQsN3QDoft6FUlT3kycC8KHhy4iG1tUFDUxVoAm/ZH4ujcBskC+C5D7sYZ44TwI5Oq37ic4IyRmkgtTaM3FrqCI0M1Yu6ZCNiE6TpsIe7Apx2YRPVR09Uz1ktTStIbd0qP1pq/7MzUN7tDS8bddnbrazt++NbXFklQ5ka6NgOL2ML6VyCuu9krl2kzWyoTw5HVv27w3ns25SN2eA5CXosjMALOTO6H1QohjMBmLKZF1lmFgdsxgLPcHE0czi03XruKDuYDuGM8p+KgvF9D8I37yDC7Zoh1Tma0D08XFtk1WZ51avNO/KgThIThLyoby05mxYaWsExnNA8tnAzHiw3Br0kxsTGVwSaxIVOk3ZI3KkU8ENq6uhq+04uA86JTHW9MQw0fLWR3n7sOAklqXq8th8m3WYt7O1fWbWnyoL95b+puhsK2BlY3+ZWR736MVq/aoqrQnIp473zPOcYMJLPyK2G9sMlJ1zgOt38fB5lrph0b+hBQQrHeepnGkmDPII+x6MdzpPeM4to7gxS78pXXxM8wUZnxZbntK881iOWzjtpqX+HnIaSkDFpNw+GOhrUqWrbLnkkz/dzGcp78NZNY0n+WR+MmTGXSNi5of++QGij/pJqjCWhVsSNJZvSCBr3IP5NuSj2TVGCTM/ogsjxsstnop7gkCriMFJhnWI6ZCC+d0X7lOoeExoQ+GqkbP5WR1njK0HNSrZzHBVOfHlD6qKvwFxYov6+ANGJ9vpBeSN8RGulTnXueKryQfWpdakLxxyJVrSDHuOlJ51mHtmUhu/ZNyjm76//txL7+pj1Fq8Cs4s180emE+hk/Rz6zhoOEdNefOWyoWEMfW/q+o+ueV5pozSv4TmS88ME6ld37uImT8CpZ4/JrDYkavXFW3PBcEKm9jHFfd7yaP0vvHxHr7xsYZrBEqmk/KG+IT6hoSk+qagIRFgY41IRZ8gfju76ZwV9YNyH46bnBwGsJ44rE9I8YO/jMbDrMcRifJVV6NfGr5pD9IpVUykWH6OzWxEtOnkka83EUQSqyh+jP90LGO+7AiHFONlRBL1InHylCqrUqWABXG2ZCSJBmoCBvCuf/ZrqWUXew41a/p2MXvRV71BFple/oAT2vctSAwpaNoizD0jY2Oc7cZMhyZKH1uuV29Jbwaaaw3jZjtXIGBWflqs5KKktqviMamVX+ReDfk6UDEyXcn8qwQAAR6eC2iiNE+K+lNY7JMIN1ZuHCoUZnuodoAZJ0M34Vvne1t70mgJdYPzxm4xFba1M+Pjvse1x3TFwMxpLJ0x2BT3DQugjFAcy5xswK7tbRoqOjUtcmxt5t1JKi+UaQ4+dRndw1sMxLZxSDOxSTAfyUMpmAmujWI1g3mE1T0UJch5Ud+vtMNXsFnE/xw2UlPMoiXopkqaC1iddv5S/0gpbiWwLZXTl5RTOtSMxI5n2sw5DDPN5ub3PiMALRrgHd8z6d2HVbq2LpcQICWJkaiUV7eIt7Yw9z6TEx2iNXYDEVDr3CqmiqJIq9aCYB3VP4VIQhP5EBZMtsqzd9/6/cnHmDKZ5wX8MRT51W5UI/zFQmRYmAtduA0zkj8EOPIJtZ1Ei5Bb1SCcsTqavngsDHGGLEse+JiW5RtNEINicpM3ExCZrEyEilEQSzccQ4J0WiDQsSNu11/8FJq51TlzmOTYAVUdDAhPI59qcWmEpM0hA9WmFCs2bX6CWEhT6X5vAU6CnZvPR4IsRU7tRW3akLdqnjH6mfQEERs0POLshUjW4qbXxG6wREj+90LqAH29cLJL121YjcytzYl8CVCZ02HVzW3FKI8rvWDp4PYS4LgJ3qKsTZx4ff4OWTuXzrwyhesMWPQ0NXUnO9KTU8xywBn2sBZbWsNze0xoYOovV3CkjIwCw5myXGcl859BQIqQ7QzK9ZAitkgemxnDdFoxT2s6J+MBDqqfagGRFTFCxEIHpxhpwDhi1mCd245c6DJEG4vXx4WWmrlzMMb5Y72y2axP++anFYCWgGVwQBtImRvCaB4Liv+Y0UeY8nnzRi+JKjMYjg7facnkMECfu7IbfWx95KOOlfxpIUKRg1hzWxtpqZiAf9kHXK86ye8JLtrkZBaiyDxk8OOZMHXde4fAwB2HrlkjzVxFEQpCPLnCbThshIC8Fmxvq4M89UN1XOa/EpykWZ89NTACGvNq53dHe4DtJsj4xHvc87qnzORf/3wP1OhAK0QhMYB0Pu72/kA9NH/4o1rce0XfTh8XUCw5T5JsLETOfzwvvQV9xjkL7pPuSqX92qvPVxpbBp+3lVTtZOjDJootGB0/HY+nsEOocS6SHZ+Ov7qqKvz0DglYL3K3vpgsHUhhlqIeoHaCQDq+UFNI2MNVcMtOyFwTMtKzWoDYMCOiRrxgOHL7pBDeiryHDzM47EdHB0M9rHa6DRaoWLFNkLOml9UNbOq5mxkUShCpToopI5Vt5EE1zlFsnQSZm6NagqJGcuSqDOgBBOtL5IfzJ9IUzYg7BMzjPyHQbehJm8ZedQAD5N2sroLkWsZoUXzBa7gMtUYOd8W2r1cPPEZLjvI+9wFyr5rYRmfFTdMlnL+U86s/FSDzFmU4jaFCWHFzi2lgK/P+Rio8fnvPjTxVP7Wz5dxt9c0KBmyiQxsyIbomVSIaKJtEsWeOVgY27eCrHGTRqVjibJL+4CJGWXIEJnMPNkxvq4TJnskazO3Ppza4T1W56qULldm45fny6UOC8pxl2xWZeJX5M2mCQnN0TZxgiuRsxqdKYqRpMuUKhm5ucIDsw2G84TlaFkhGRv/IJrTLHBpeHhX0UO6XYatQgWfm4CakT23lFCa9RfWg3ZJHED5F4QtScQV7Hfa5Tj+lsJ6eiAZL4WM9UJM9Fi2oZn9PRU08il7NSZFvlAQJ833K++eDKBnOrepLceJLRU3acKu0QU2KaO5vZrM3aT395bAFkAU8vtMbUjM3U0AQdSgVmg1ApMZXw5VYUHZ+ydlsNVkrCq1+2bBJbn7p9UpcRwuOWBNnARRBtKKnfLdyO0Njfn0vVJXz5dtUuEUtOWvpIqPKPGT7dZACDryV9DExpUzDue3T3lYL13dZ/T3lCGFgumfLJhIc5fmHHj+ckT/BJ+t2pC/EuK4H/PQbLDoplRQ3emFZC2Y3nurmE4Yd6pJB2J7amOrYknUojtZ+ToUhfvxwA4WCO8RItypIlMN8gX4Dg2V5VwqrzeADNmfSAeGvN2DK+dC3F+xR5tLuB7VRp2V3BKm+EAffEWQ2/QvqY2sE16xt3AN8kHLkGe0wqmT3iab3DiTBR5igqAxp1qGy2iTKV+ULC/ouchBWbtoCvcJXBTuRxvQrYvozmWKKPb2nErPKeoT5DNTV16yN18derFaPG5c2AZ8cONMxXSlBHAo1iCFZ+M2/nqCS14il4ESlGOyV6PCmNryGhiZT/1Ct+cQsTERI9gwPJAx6C84LEfLtOryuZza2Q+n4kS+KwPaPhHCSKGAd6opPbdKyLRoQCIafAxEDTwf7FY5qVwJD2xACm4V3ISIj5fKIDaE02nRPIQbnqmgsKNVuFubNATMq5DEz3Y6uf33lCKy/HCtmgYDcXyt9EFNL6rwNcjWBWVAych+QFE2cGik3vR5rLT04VozKZlozAmf1rQ87PgyiXSuJyu8CuJmQy5ajk971+BCLtkNpTnf0By5Xm3lvcbTh0vZgwoaDI1iZpFKHS1PXRhd9LqJDeNZH25lq7cDyNXXSpdtQqOb8uPZRtLyOPlTpzAUd5uPdOGsdapCisC9k/0NO/AViiZB2dDykFMmD5Zgm0Gs1t5RX9qhfL0VJ93VvMbUk+6gWn/VWkii23dyl75Qlyvlccxd7RtMPWlEL6Mcug1uSw7mA8zXzkRfpqBNCqTIxmekK5y8SRP2Ilubw2419GXarK+WNjmn0q2LjowHV98GXJ1JEiAc81dgFZwkhLGjbBDkz00S/yEig4QdTSUyGYvQlKYK6+xC72VTXdmprajeANIHYcuEOhBhKfHpBpRdCX5ovp8C00c62ykpudHqJ833y/qh5pbjuJE9BugEp89z3Efhzq0+k3w/pTm1IJ9zr+KdNH1UKjPuZViVlAJ2bpQQKv1i3ZrdxZtoUG+iYiE5dBrsvCVzcvHRY4gd8l5KUXnavWX7q1Inia/Jao39V7IT4bUifGz3/8MqZnm8IHi9w35xKZYVnssNkHglnmfI5z9dfuObOWRUkziAirjXUt+S3BhnqFBIz3jwuIFoTMQ5PixBmzqnR6dh37gbkBLXM49j8c10OKGEXKuUfPOr/xeQXE95B36N9XIBiG4wUMeG0bVXt/D3bPTDWVop2gPGH2MD9ezxilHmfu6Nvh9bK9iAt5bSmtNJz1aDDB6MxaEQQWCwgc1Fb2drP09rS5zvgFF0xTITc1niPFzYsKUGit4ONsQ4d5xCtCpGwYm+g411SImTja79IMrEcD5U8Vys4QvhbItsgguCrEDVL4Q1ZCGEbYGtR0+v14IX6wJrDyu4X5E2OJCWPjiYljF4N+Ph89o9rg8OQVN80GVf4lQvwMQE+L4CUg5TZbhlArgKkhtzHXv1I0SMuRZSZhPZKOYiSNzZXtyddhewf02kQxq1x/cnENzcic/7n8u5ux2WTgPBScd0naz/+cbOeoDuOn+Z/95qaVVkv11kidb9kFBNUlRxv01k1UpxwO70E3N/L/EiF33OCHl3R6UYRyUFd66IDK5IBQ9HZaBxdpJ0rPZvYRLgi2/tezpY2fjt/szNArOnr5qUzHzi7LCYMHuf5ApJ1crBnvFFsMkwfDzcQPDMMrsLZ/b7LtIJ3bhXevn7KM1Ia6CbiVGgs43lRai5CVBR+Ie8h9wmaYMmxrBPN8ocQ7I8BIyFLMKMUp7Wtl1Zqk3Rt4gwFvYSDMp0LNteTrLUVVaw0NbVsdKRVy76beON1dHywVpb+WG1dHBY8FqOjtZZmeXa8/tlDcdDUR/v1ae6J5g6urMH6RgFONhY452MjfAO4NNCqXWv7sL++iuXJ6+Sj6m+UBHnX1ltvnq0wGPdG7ww/Z3thC37nO0b2+ETedveha7ep9a98vd60ea900DdPjIeOs3IpivuPUgcajgZP4kTiCsZL4lSwpibk5nLf/ovE5MbmkVNsg9/HwKHVeUBzEMK8SDLo6fznZoqip1PFiw/p7NTvR4Kdv1Z6diVt5CjEZNpPJ+syC3namA2N6QTtZqeP1JrC/xxrpwO34NCSxy4rQiPo7mxRXbBQf/cJrnN/Njixx6PcqbU3Y2SA36Buh/VDbeUb69vD/S8eN7jt43wWLKj8o7y9Q9MN7gg2E0OHWzR39TgIMju+uiEjaeFaChhFZWUscBa+dNqn0YfKQ2bhiX16zi/m2uvbSdD+6AAB43tob8UwkNxveRTcG7pebx7UBg+QbFooIEleGYgnswUfz5zlyWkYcHh7ozCfUa+CG5hN7fDgMzsT8GuHixIPD197SVgVpP+IF+C/s69V9yMe5so+G4hwU/gKeTX2I8h6eIn5Ah7PpvwgoKwoILs4JC8wrDA3GxQ4wxoXS50QTEAc+g/x0DGXumOUgt1J7WmdIviHQPqTtBRczp4Orx/aN+K804rivx7f/KfgAhZFjgJCZ33n9vFbuZmTZ5AFwtCN56k5X4b+N3z+2L2G/3y4gl0t4tnsXTOT+pqyhUFTNQ+xlHAxS/R08svKdjdP9nbwy/BjWexZS5Wsj/M1WNNwcjg/2ZwlS3WV+wfVsTVwMbJ5OLB+u5QpLfEPzMxD317NyygAYOr6wCJzzWD+lmYVmgK/jiuVDXHUuGxxhWG8WSWKk3suBnU3wJToQW52GZUluiHNakwCLy4vLSAqV8nPIV2I4X2+Vf9oM3uE/aYrxtRX+dP1PGbrcDw7B9UJduGntsA01UId4g6pwxgpGzRuaCmLzaigES3oirOgYXwmWguj2jHOYcEokOIIe0uEVS4U86CxEU/TUj9A3++AAMBKUN2F6Ah63wRw+01qRwDupFhE3tfJtz3/p7p2uLcbUK5v3MrFGgIjw1G3cZPxw/Q+1zcV5BJGPO2Olh1xzuCdTj3JTwdgAF+AAPAuI6Obu8vD+PFN1H271OUB/ell5yllWQ+AJcCxPbN6FS7x/uaWqZv9zM0RL7X/Kuq8lnrPSgNfoZ+Lf3iYSG3lX/5mtgAX6Ojm4nPLkpOyS6NB4qbgA/AwNFPbsR5W9mX48SGp2CakFWSmJJVSpgG//KTx9iOtjPmzVNaIlq/3yGdVoeHXTd72R2nE6hj5RLvDphy6ap4uw9nZp62hwSbrS0Y2Jlr2wDeIPDrJh0/fSk9EsAAKKXzRwA6fno8PT99CD0opZsOzwCEJZA7kO4jZeU4le/qGtcUevrQ/Ij/R1VE1c4iUO3A3yvZQtIhn1O+VUqX/s+fHqD9FSUYVLaSWJnkH1MaCIYsAfYrd0hIqk+FOGat2KW5l6lGNEYK0COhpyWBREVq27eE0csv+BXcUub0KxxNYz+X8PHei1zG1UfmArpHo1ohH3Vnx+fco3NH+2YzH6PqT2yb5cCOGIkeWl0lkeOGo0KG1GhT06RsTyCRxUX2C5U0n5QOMXf1QunKKiBVtBsmJa08g25p6+1we0mdKSn4Hb+k5QpX3AZokBTc8MKt6g+Dxls7wzMyCm1lO8TmA5N97837vRS8o9ypFeauJ17/OdWHY+XUXtL+KX6GS42nU6dtfG0lXe7T8dnFSWMyfvpIMJ0YvnFuEMuL9rNMMIMti5f6iCgdHXVbDog5sOtl8pMLK1HMO4qOPx+bSKGfT4JW0SFmSdjFi/q6yORmr4eTZWMg0Mmxj70QqccNCT7MZifAEdvhKAz7ZQbYXPDVJfCNolws5yQyJUDrMGRxryN1etG2VPaJKkGAlGkwMbHuURekwWLm1Zsl/YdU+gPBUWetJ2HgReoc50omVcsO/1RXEB17kawRB/NsUT68mR95xH03Gb8sVnvn9DGYKnSoiN1Bgty21SAVbX49AKkEMhfHhMSSUVJT4IXetCmYtF/nI1Uuvl262j2VU1lIjb+JDUwBwykSqqQwdkFGtgmwMyRATCRSUV5exWrn4CbRd9s/ei3C7m+dbWkRv6oESKZzalyUvRO6+TdIIXaJHUtT3B2CB0+4q1sGB2KBW6QEZwQwRMUO5p3to2FvHr6hGUQnGa+RT1+/sRvjYqGTfNwFeaaFWTdjaA6nK6yJCq/Mi6kEPPPXdT7qIgecaqzAmIyrg9SXaYk3JbUkXGhzB52hhwcQgj9B2QcJXOoJya/LaExqJF7o0rvDhg7hCje8YamulJEpuZmoebs/WbSMPAf0dBeZSyT3Zcl2vX6gZS2UmHwH3YHqhwoRMvX0w7JepHMyfija+yqgzraZdijUTHHBGA7SUMYn2TCewDNQpjq3QO1pRZkEe8pA64RJKKrjughS6CokCSItw/iU1UM1lyXpKKvZOSwzeVRmRO4bz2uBR2M6sGggqHh4ojNtWuKNiVWmdwckf96Cc6wgQTt3qAw8kGgAapMX2hyDntodENMQqfBbvEISN2ljrUyOPFmNFetMURouiYfE8Cz2JCqL4iF6xMaeL2gy6SCmTkkQcKM6iUmFyG+BAKoQGdcreokk49QmJiqBe+YQr8DmDcDqFKnN0TuZ7owzkWZ8QcS46s2m8RFJph3yM+XDxqOCLqcaaIukm7kjkNMYop0uv10BSIgOV4EeWCMTiWnaseOEmY6I8Hsi48Fv1T+JgU0kdz4tPW72Wz+SgZDoRCu6f5SBhDCJhAgiBpO+59Wv4PwK+gxB49G37yTXJOyc/bPbl1513ljaas9x8nN4ul1w2zEkpCcksjso0tkxOOy32kbFBuAfQvS9Xb3V+/Z138D7V7d73q9EpTmHRzq7hEe4uIVH9oVFiktXrFVcEvC7fIG8gDvmz9YXrBOsOZu9rr4XyOvADYyZaiLj+780QJQW14WPtASobidXmAhQRHbdr2DP/3HFZd0nvBG7ZesVgcMJ7sNzxvqeRRBwvEeJWD4TdV7dqsbmyVaQNziA6rGvfqDXJwnQPvpZtkmVU9DAgTPo5jx213rEjRQPwDKXBqifRRrjAa7wQr9vJHh2NHyzrBL43vAz/n6Bd7F6/oSeOvHocWPW+UvHkPMXpjuFPzX/99q3/3UniJylCP/fPSfs+yVj/rcBEyTLXHb3Y1zNX+NeKQR8/ICz2yqc+uEXUmJVmd0e9XRXwMYshp8eJU6PZOdoFvW7ziEceroVNITzquqd/t2ymbJJVG7wOp3qwh5TXQ9fT1Kt/KTqZbr1JMVhWuQwTbd+d5hHmJ6fo4oIvVPOYUVEt4yqdskIswpXW0MN8HesvDHQNQ/bLuZQYktXCuQ6dqXpKH3X4XGYBZyA7BVSV3JbeONf4TxZmaj3do5p+TPWZS66ZU3IyVcnvWFUu2L9rrB0A/GCOhe+jJy7tJhQE6OqzJoClX7vfL3SIZ8/Z/YLLfJrqXQo+3f6EBavbVJM4p/cZ21ezm5ql1hdRVdY0PVe0HoRfZ0OOn+Mf6ZFHIB7AcrWe9i++9yiZ1bNpV3bWS37ccUf1qKdbFm2sg5mAvzzYGWkTe4H4PdFyq2TuZ7+wp2zOKb5JLdD1Pe4nMnEoQv/w1xagoAuqevG7lVu9mPauGLS9NldMFhrGZzNHt3o+gCznwWADmPd51JDecRX+OTXuMRu/HUYrJRwpaneQrBW/Y60g1MiJaUpnuAW31pLXi7c5bPLMWjaMTEreJqqRNcO5bX5I85aZd/odyN19hdG1t91Lvr7c2tDgKCv4ARNhbIKBrjZ42RCwJvRlZoMfFykmDWPsTIAPobbogLgcWiKwia0vviLwnVOnvKGCO2jl2gDLaAPnnV/sY2VLr9rjIT8p4YcX7fI/5V5Wyqt3AqjERyq9fLw+WtjhDTX34p1rCe06pdZEEEfAhsLBv497P7dDEw14HcalIt06VdLblOgKART841Tt0RkGJfJG9A/myWAaQ1TCxAgdXrDFCt4ai/dqJtA0xakBdjW+LnVrqi5Y2/+hAvzsHqUVT5fa/UpHtE5vQgJWuMnvOge4FaB1lMaKzmkvw74/ystbAoC2u0zX0zLu8XW12qXrWRZpdJf8MT40Rk9q+3HDR8Nn1/9u/msFhtEh62m5ZNwKCjsw1Zn9KxXGTd8RPtrsyIbXziizoJhe/S6HKXtlb9u1qftk79iopBdRVW4lua175d0x1zazfnBzr5xfco5zRv78yvOa5JSnuZxzcUw81bKezkDouTQClOt/dwKzqB1NZNVN93aYitftfUzWTEF+Qz674fYqdcZ/lsR8VQ+8pe6k+0aDDG/Qz78F301vtI1pzKqkExq7oHmQjElV3bPVqU79ZMaPmR6VDoVyYv+qC/mNxwUWSaIlVd0QOkZHrpsa8dYrmr+J1tw4fRAGE2CfoUQZnr0dOyw3OQ+/cinr+0yzC67yBbiumGblOCST/Qjk0lUbABf2wJGu8Yke2Kh42g88D5HKxIUTKIYtgY2+cPkDZH7ikUL6rO15nLY2R9WztpkKRYtVIZCH4NMBbl5uEM4B+D/y4DWB0DreqB1M9D6Gb2C3ljzLcCpf39CajXPNuW4Q5db/0Bgd2eBFoABEZgbIMzeiXpEZKZL+C5JG+9IJvpWCnpFRoo6Jl5KNPKWlGqfLSkzamClXIfRhory11Kl31SSat1mkdTww5I1u2nI+ghe7KvDjplAVQAXASRJb3clk/tGCqY7laKhsZAS3VMspQbmnpTZnmMpN3gkoKJ8UKrMHydSbfx0khr5/OH6rU2r1+jzIBi8HmXsZURqLyxFKnnMn5a+7sfjZSKGoHAGk3hRQ8wxEsJD1ot2eo8e3Swf4X7iGBDyJ3+1XJhcME6Nsb8WoJMUOnwA2BIDY520LxMgWTHUuPktvieA2AFmxiKOD24hYt7OmwPxmWxmydVoWcyNA9hHNAH2r9cCoKetKxffaLMTx6Y2CNoXbOFqFbb0Tux2+xv/Z4HMRnzAABLRojocrsKMRkH+qlkkzjKHHIXcjEsd4AXFzB8H4LRI4YQShHNNezaEBFSta60wpDj7apXQ7iBP/hxYzYOLnsKi72jVxwNojgUFt1wC/qiA10iv65x8TWmboqf7xWiFfDyPJ1QA3kqh6HMv1UUCwFE+7kCxWEpGorQXkQ6ogEcpN1SIxmYISWqoZpGJ8u9agVVEPVGIEK5F7s0oB7EgB1I+bxo8RdB6TO0j+WXGyrsOQ+OyN2MuY8gppIiAAx4JRUuYSkoKL/5Gr8gMU0gKMoksFUQBwW0VA8XLBFW4tFgr1UsaplmBDkep/dtZsvE7DClIkXT0AuWg0fpkPbFWCAiBarKQqN1OG4x/JoxmrjqvEBnUmRgmVHUs0e3QX+Y1NjjPIEJt0rxpz7oiPDMj1HEXNqLkeAyVmx3LXiBRJ8Co0otVa4NtxIoZq7BDZCozsXmyzMbY32WBS6UzHM6h8W2m5mF0aHfFDoNciSEbonOz0Tvzt2UdZSRAzJdCOdDQXxsGn+CKSgY3jhG3TPdduSbzimI69jIIrD7q/7UG1eLtP227O4BYjDDYiOZQ8QbESIuOa/BRgYqjveKWzlDz3Gu5ap35oVyRaW9914ajOUd24brbFszr5y9AFbynAimzaGXR/UmQtWjwHcFOVeP41m0I8cVXxcKEChcpQpR20WKbDye0P068BIk+S5IiWap0aUZckylDlmzHToyGRqky5SpU8r9/cCS14pAgSRoXBL++X34Dk6SLYC4BLgWOxi8r2x8vI0eeAkWokg7Ye/vRoUuPPgOGsCUZGGZDs0gEO6yJRlas8U+zZce+//x14DAOHDlx5sKVG3cePHnx5sMXjh9/8JPiPcQnGya8D450J0KkKNFixIpDEN8re8Atdb+zZXeIMAdKlCRZilRp0mUMGeZ4c7vpqstakidfgUJFipUoVaZcxZBiYABvr6RWHZhKvBO8G/wmwj1DjzmSOwbcNegekvuGDBsZjgyBW4lPgD/G6FN43aeeWbJsZRgZE15YG7bL//C9tu2NHW/temfPe/sOGnTPkGEzSO6blWNKoV5zJjwylkMfHPnok8++OPbViW9OK8v3GjVr8i1ndanR6oZKdeo9yI9eeGwyZOcu/PTLb3/856//fasPAAyBwuAIJAqNweLi4bOwAsb008XEJSSlpNHwMb1fSVkFRCauBa6Dej19MJn0Q9x7Gg1AZRIT/ON7br6Ik/QMYqb/e3l1fXN7d//AB/nyd3VlqH60zoen5vnl9e3dsx0seDB7rQd6uTnme9U0eH3D+SLby6bz4jjjSZb5hLbXizuGqAoH01amOT34SpBvzwYH4uptMVNZhvNkjR3mlly/+GlEmWxaz4+YgXJksBQcEenGzB55EMwoUOvHnzKccGRL66RbTsmTOR0Td2xZhlMaVnmanGb2QcrlKov8/rR2TOFJHkmBkmhAqY1I1JNv0eBNLWFA31pW5FAgezXDRrxd947pn4oc5XF10IfRp8lIXD3RywSblBXjTBwjE2Mm+VQuSKaG/klNy/KytY/yfLKlV7Q3wRZViXUWjpWFsRMsLmFcGWINWU4ddtEkuFwIWVJwwMvbl9io5iWVQEqQ1IQxmsLaOkbDd1WlMjlhkqe2HAzNwD4vNlv70nqZYFfSmddScOWX3a9X6LS8Pi6Uvk1aCyrrIpps82dyBnvDmiA/nq3PHoS0tnLF9fwtWPhnzfA5RL9QxP2jwWhJQnouUyVdj7C33s/JQEbnzFAK8qPgei/DJKbRlYxkfOfZOS8TrHkYOK+9af4U52LvpqfTlGhefcFNKbgJTyDEgxEUwwmSohlWLikAIR6MoBhOkBTNsHJJAwjxYATFcIKkaIaVSwZAiAcjKIYTJEUzrFyyAEI8GEExnCApmmHlkoMF/CKn7bcP8cwgxwiK4WNBMAmQbRO+3D458rT3dj6oym2BU79JvwLcNscKoW1e4KNRlxPvDV2I0DNbchQe18omUPvaMRoTCqhu9Sjz5Rha3fOUt+3Js+85pBkapyKsoWELyMpQqgGT09Tm0VhjxwPeoP1TqcG7Ox9PKd60/XNW5PWo4Zjg7W04oe1S2GiL7MNB6I2Ex9DihjCvph02URXrqISAxjFA8VR81G3+WEKJ/E581IKh/6L89Ys+jG4KWOc0dBH0YazKhznBQv2XjspXRLlttDHVpSDoHy0sQIVtsIF+Q4m1t7FP9H1ClWm7J6lqr68ejD7DL424vceqpfVrI+h02ObK7vlDu+YjKYMlZtvUR0Go81eLVcoZxaube4wRsDIaSBWzobVRHe940v8PkbBXPxiJLjR7uA8uJaOk50kyzNJm39BckBocxLEjfXieUewUH8ZOVD/VMWrb/Kq+Z1c3TKuDcSSmtes3seiXes4UK0gr+sFdHkpFGm+bsVDatoPrsqPhx23s98+PFQGGsb8d87culenm7tgN3dg1xGn/w4KrqVoh5lmy640771tv9exGfOlsn0V5Qn21m4RfTXCK5rlvkn4xQsF62d86wmpCVelvnfrV24Wu9VahGZps+oXz69UTe4ANLeqtbeyQvDOxtW3skLwvraal3SuM8j9qQ+2tjm18r1UPWur97LG+AQ==') format('woff2');
            font-weight: 700;
            font-style: normal;
            font-display: swap;
        }
        
        * {
            font-family: 'SC Prosper', sans-serif !important;
        }
        
        /* Global border radius override */
        .gr-button,
        .gr-input,
        .gr-box,
        .gr-form,
        .gr-panel,
        button,
        input,
        textarea,
        select {
            border-radius: 1rem !important;
        }
        
        /* Navbar styling - Full width edge-to-edge */
        .app-navbar {
            background: rgb(2, 11, 67);
            padding: 1.25rem 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            width: 100%;
            z-index: 10000;
            border-radius: 0 !important;
            height: 5rem;
        }
        
        /* Force full width layout - no gap below navbar */
        .gradio-container {
            padding-top: 5rem !important;
            background: #f5f7fa !important;
            width: 100vw !important;
            max-width: 100vw !important;
            padding-left: 0 !important;
            padding-right: 0 !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            height: 100vh !important;
            overflow: visible !important;
        }
        
        /* Main content area - sits directly below navbar */
        .gradio-container > .main {
            padding: 0 1.5rem 1.5rem 1.5rem !important;
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            height: calc(100vh - 5rem) !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
        }
        
        /* Ensure all containers use full width and no nested scrolling */
        .gradio-container .main .wrap,
        .gradio-container .main .contain,
        .main > .wrap,
        .contain {
            width: 100% !important;
            max-width: none !important;
            padding: 0 !important;
            margin: 0 !important;
            height: auto !important;
            overflow: visible !important;
        }
        
        /* Make tabs and content use full width */
        .gradio-container .tabitem,
        .gradio-container .tab-nav,
        .tabitem,
        [role="tabpanel"] {
            width: 100% !important;
            max-width: none !important;
            height: auto !important;
            overflow: visible !important;
        }
        
        /* Ensure all form elements use full width and no scrolling */
        .gradio-container .gr-form,
        .gradio-container .gr-box,
        .gradio-container .wrap,
        .gradio-container .block,
        .gr-form,
        .gr-box,
        .wrap,
        .block {
            width: 100% !important;
            max-width: none !important;
            height: auto !important;
            overflow: visible !important;
        }
        
        /* Remove any nested scrolling from Gradio components */
        .gradio-container * {
            overflow-x: visible !important;
        }
        
        /* Only allow scrolling on the main container */
        .gradio-container > .main * {
            overflow-y: visible !important;
        }
        
        /* Main content wrapper - no padding */
        .main > .wrap,
        .contain {
            max-width: 100% !important;
            padding: 0 !important;
            margin: 0 !important;
        }
        
        /* Remove padding from all tab content */
        .tabitem,
        [role="tabpanel"] {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }
        
        /* Ensure sidebar appears below navbar */
        gradio-app .sidebar {
            top: 5rem !important;
            height: calc(100vh - 5rem) !important;
            overflow-y: auto !important;
        }
        
        /* Override Gradio's sidebar default positioning */
        .gr-sidebar,
        [class*="sidebar"] {
            top: 5rem !important;
            height: calc(100vh - 5rem) !important;
            overflow-y: auto !important;
        }
        
        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .navbar-divider {
            width: 2px;
            height: 2.5rem;
            background-color: white;
            opacity: 0.6;
        }
        
        .sc-logo {
            height: 3.5rem;
            width: auto;
            flex-shrink: 0;
        }
        
        .sc-logo .icon-part-green {
            fill: #38D200;
        }
        
        .sc-logo .icon-part-blue {
            fill: #0473EA;
        }
        
        .sc-logo .logo-lettering {
            fill: white;
        }
        
        .navbar-brand h1 {
            color: white;
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.02em;
        }
        
        .navbar-subtitle {
            color: rgba(255, 255, 255, 0.85);
            font-size: 0.875rem;
            font-weight: 400;
            margin: 0.25rem 0 0 0;
        }
        
        .navbar-nav {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }
        
        .nav-item {
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.875rem;
            font-weight: 500;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            transition: background 0.2s;
        }
        
        .nav-item:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white;
        }
        
        .nav-badge {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            font-size: 0.75rem;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-weight: 600;
        }
        
        /* Dashboard metric cards */
        .dashboard-card {
            background: white;
            padding: 1.5rem;
            border-radius: 1.25rem;
            border-left: 6px solid;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .dashboard-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.12);
        }
        
        .dashboard-card.blue {
            border-left-color: #0473EA;
            background: #0473EA;
        }
        
        .dashboard-card.green {
            border-left-color: #38D200;
            background: #38D200;
        }
        
        .dashboard-card.red {
            border-left-color: #da1e28;
            background: #da1e28;
        }
        
        .dashboard-card.purple {
            border-left-color: #8a3ffc;
            background: #8a3ffc;
        }
        
        .metric-label {
            font-size: 0.75rem;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
        }
        
        .metric-value {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 0.25rem;
            color: white;
        }
        
        .metric-value.blue {
            color: white;
        }
        
        .metric-value.green {
            color: white;
        }
        
        .metric-value.red {
            color: white;
        }
        
        .metric-value.purple {
            color: white;
        }
        
        .metric-subtitle {
            font-size: 0.875rem;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 400;
        }
        
        /* Section headers */
        h1, h2, h3, h4 {
            font-weight: 600;
            color: #161616;
            margin-top: 0;
        }
        
        h3 {
            font-size: 1.25rem;
            margin-bottom: 1rem;
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 0.5rem;
        }
        
        h4 {
            font-size: 0.875rem;
            font-weight: 600;
            color: #525252;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin: 1.5rem 0 0.75rem 0;
            padding: 0;
            border: none;
            background: transparent !important;
        }
        
        h4:first-child {
            margin-top: 0;
        }
        
        /* Table styling */
        .dataframe {
            font-size: 0.875rem;
            border-radius: 1rem;
            overflow: hidden;
        }
        
        .dataframe thead th {
            background: #f4f4f4;
            font-weight: 600;
            color: #161616;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.02em;
            padding: 0.75rem;
        }
        
        .dataframe tbody td {
            padding: 0.625rem 0.75rem;
            color: #525252;
        }
        
        /* Control panel */
        .gr-group {
            background: transparent !important;
            border: none;
            border-radius: 0;
            padding: 0;
        }
        
        /* Bento card style */
        .bento-card {
            background: white !important;
            background-color: white !important;
            border: 1px solid #e0e0e0 !important;
            border-radius: 1.25rem !important;
            padding: 1.5rem !important;
            margin-bottom: 1rem !important;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04) !important;
            transition: box-shadow 0.2s ease, border-color 0.2s ease !important;
        }
        
        .bento-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.08) !important;
            border-color: #c6c6c6 !important;
        }
        
        /* Ensure bento-card wrapper/group is white */
        div.bento-card, .bento-card.gr-group, .gr-group.bento-card {
            background: white !important;
            background-color: white !important;
        }
        
        .bento-card-inner {
            background: transparent !important;
            border: none !important;
            padding: 0 !important;
        }
        
        /* Improve spacing in bento cards */
        .bento-card .gr-form {
            gap: 1rem !important;
            background: transparent !important;
        }
        
        .bento-card label {
            font-size: 0.875rem !important;
            font-weight: 500 !important;
            margin-bottom: 0.5rem !important;
        }
        
        /* Markdown content in bento cards */
        .bento-card h3 {
            border-bottom: none !important;
            padding-bottom: 0 !important;
            margin-bottom: 0.75rem !important;
            font-size: 1.125rem !important;
        }
        
        .bento-card ul {
            margin: 0.5rem 0 !important;
            padding-left: 1.25rem !important;
        }
        
        .bento-card li {
            margin: 0.25rem 0 !important;
        }
        
        /* Remove gray backgrounds in bento cards */
        .bento-card .gr-box,
        .bento-card .gr-panel,
        .bento-card .gr-padded,
        .bento-card .gr-input-container,
        .bento-card > div,
        .bento-card .wrap,
        .bento-card .gr-block,
        .bento-card .gr-compact,
        .bento-card .block,
        .bento-card > *,
        .bento-card .svelte-1gfkn6j,
        .bento-card [class*="svelte"],
        .bento-card .contain,
        .bento-card .gap {
            background: transparent !important;
        }
        
        .bento-card input[type="number"],
        .bento-card input[type="text"],
        .bento-card textarea,
        .bento-card select {
            background: white !important;
        }
        
        /* More aggressive targeting for bento card internals */
        .bento-card div[class*="wrap"],
        .bento-card div[class*="container"],
        .bento-card div[class*="block"],
        .bento-card div[data-testid] {
            background: transparent !important;
        }
        
        /* Universal selector for all divs in bento cards */
        .bento-card div,
        .bento-card section,
        .bento-card fieldset,
        .bento-card form,
        .bento-card span[class*="wrap"] {
            background-color: transparent !important;
            background-image: none !important;
        }
        
        /* Target specific Svelte class causing gray background */
        div.svelte-1nguped {
            background: transparent !important;
            background-color: transparent !important;
        }
        
        .bento-card div.svelte-1nguped,
        .bento-card .svelte-1nguped {
            background: transparent !important;
            background-color: transparent !important;
        }
        
        /* Override all Svelte generated backgrounds in bento */
        .bento-card [class*="svelte-"] {
            background: transparent !important;
            background-color: transparent !important;
        }
        
        /* Row gap for bento layout - full width */
        .gradio-container .gr-row,
        .gr-row {
            gap: 1rem !important;
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
        }
        
        /* Ensure columns within rows use equal space */
        .gradio-container .gr-row .gr-column,
        .gr-row .gr-column,
        .gr-column {
            flex: 1 !important;
            min-width: 0 !important;
            width: 100% !important;
            max-width: none !important;
        }
        
        /* Make metric cards responsive and use full width */
        .dashboard-card {
            width: 100% !important;
            max-width: none !important;
            min-width: 200px !important;
        }
        
        /* Add gap between controls - but not at the top */
        .gradio-container > .main > .wrap > .gr-row:not(:first-child) {
            margin-top: 1rem;
        }
        
        .gradio-container > .gr-row {
            margin-bottom: 1rem;
        }
        
        /* Remove any top margin from first content */
        .gradio-container > .main > .wrap > .gr-row:first-child,
        .gradio-container > .main > .wrap > *:first-child {
            margin-top: 0 !important;
            padding-top: 0 !important;
        }
        
        /* Markdown containers */
        .gr-markdown, .markdown {
            background: transparent !important;
            padding: 0;
            margin: 0;
        }
        
        .gr-markdown h4, .markdown h4 {
            background: transparent !important;
        }
        
        .gr-markdown p {
            margin: 0.5rem 0;
        }
        
        /* Connection status styling */
        .connection-status {
            margin: 0.75rem 0 0.75rem 0;
            padding: 0;
            background: transparent !important;
            font-size: 0.875rem;
            font-weight: 500;
            color: #525252;
        }
        
        .connection-status p {
            margin: 0 !important;
            padding: 0 !important;
            background: transparent !important;
        }
        
        /* Timestamp display styling */
        .timestamp-display {
            text-align: right;
            margin: 0.75rem 0 1rem 0;
            padding: 0;
            background: transparent !important;
            font-size: 0.75rem;
            font-weight: 400;
            color: #a8a8a8;
            font-style: normal;
        }
        
        .timestamp-display p {
            margin: 0 !important;
            padding: 0 !important;
            background: transparent !important;
        }
        
        /* Buttons */
        .gr-button-primary {
            background: rgb(2, 11, 67) !important;
            border: none !important;
            font-weight: 500 !important;
            padding: 0.625rem 1.25rem !important;
            border-radius: 1rem !important;
        }
        
        .gr-button-primary:hover {
            background: rgba(2, 11, 67, 0.9) !important;
        }
        
        .gr-button-secondary {
            background: white !important;
            border: 1px solid #8d8d8d !important;
            color: #161616 !important;
            font-weight: 500 !important;
        }
        
        /* Radio buttons */
        .bento-card label[data-testid="radio-label"] span,
        .bento-card .gr-radio label span,
        .bento-card fieldset label span {
            color: #161616 !important;
            font-size: 0.9375rem !important;
            font-weight: 500 !important;
        }
        
        .bento-card input[type="radio"] + label,
        .bento-card .gr-radio label {
            color: #161616 !important;
        }
        
        /* Download buttons */
        #download-csv-btn,
        #download-csv-btn button,
        #download-csv-btn .gr-button,
        #download-csv-btn a {
            background: #0473EA !important;
            background-color: #0473EA !important;
            border: none !important;
            color: white !important;
            font-weight: bold !important;
            padding: 0.625rem 1.25rem !important;
            border-radius: 1rem !important;
        }
        
        #download-csv-btn:hover,
        #download-csv-btn button:hover,
        #download-csv-btn .gr-button:hover,
        #download-csv-btn a:hover {
            background: rgba(4, 115, 234, 0.9) !important;
            background-color: rgba(4, 115, 234, 0.9) !important;
        }
        
        #download-json-btn,
        #download-json-btn button,
        #download-json-btn .gr-button,
        #download-json-btn a {
            background: #38D200 !important;
            background-color: #38D200 !important;
            border: none !important;
            color: white !important;
            font-weight: bold !important;
            padding: 0.625rem 1.25rem !important;
            border-radius: 1rem !important;
        }
        
        #download-json-btn:hover,
        #download-json-btn button:hover,
        #download-json-btn .gr-button:hover,
        #download-json-btn a:hover {
            background: rgba(56, 210, 0, 0.9) !important;
            background-color: rgba(56, 210, 0, 0.9) !important;
        }
        
        /* Radio buttons and checkboxes */
        input[type="radio"],
        input[type="checkbox"] {
            border: 2px solid #8d8d8d !important;
            outline: none !important;
        }
        
        input[type="radio"]:checked,
        input[type="checkbox"]:checked {
            background-color: rgb(2, 11, 67) !important;
            border-color: rgb(2, 11, 67) !important;
        }
        
        input[type="radio"]:focus,
        input[type="checkbox"]:focus {
            border-color: rgb(66, 123, 245) !important;
            box-shadow: 0 0 0 2px rgba(66, 123, 245, 0.2) !important;
        }
        
        /* Radio button labels - make selected look like plot type buttons */
        .bento-card label:has(input[type="radio"]:checked) {
            background: rgb(66, 123, 245) !important;
            background-color: rgb(66, 123, 245) !important;
            color: white !important;
            border-radius: 0.5rem !important;
            padding: 0.75rem 1rem !important;
            font-weight: 500 !important;
        }
        
        .bento-card label:has(input[type="radio"]:checked) span {
            color: white !important;
        }
        
        .bento-card label:has(input[type="radio"]:not(:checked)) {
            background: white !important;
            background-color: white !important;
            border: 1px solid #e0e0e0 !important;
            border-radius: 0.5rem !important;
            padding: 0.75rem 1rem !important;
            transition: all 0.2s ease !important;
        }
        
        .bento-card label:has(input[type="radio"]:not(:checked)):hover {
            background: #f7f7f7 !important;
            border-color: #c6c6c6 !important;
        }
        
        /* Sliders */
        input[type="range"]::-webkit-slider-thumb {
            background: rgb(2, 11, 67) !important;
        }
        
        input[type="range"]::-moz-range-thumb {
            background: rgb(2, 11, 67) !important;
        }
        
        .gr-input:focus,
        .gr-box:focus {
            border-color: rgb(2, 11, 67) !important;
            box-shadow: 0 0 0 2px rgba(2, 11, 67, 0.2) !important;
        }
        
        /* Links and accents */
        a {
            color: #0473EA !important;
        }
        
        a:hover {
            color: rgb(2, 11, 67) !important;
        }
        
        /* Tabs */
        .tab-nav button {
            font-weight: 500;
            font-size: 0.875rem;
            color: #525252;
        }
        
        .tab-nav button.selected {
            color: #0473EA;
            font-weight: 600;
            border-bottom: 2px solid #0473EA;
        }
        
        /* Hide footer */
        footer {
            visibility: hidden;
        }
        
        /* Final aggressive override for Svelte backgrounds */
        .gradio-container .bento-card div.svelte-1nguped,
        .gradio-container div.svelte-1nguped,
        div.svelte-1nguped,
        [class*="svelte-1nguped"] {
            background: transparent !important;
            background-color: transparent !important;
            --block-border-color: transparent !important;
        }
    """,
) as demo:
    # Header with logo and title
    gr.HTML("""
        <div class="app-navbar">
            <div class="navbar-brand">
                <svg class="sc-logo" viewBox="0 0 157 62" role="img" aria-describedby="sc-logo" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <title id="sc-logo">Standard Chartered</title>
                    <path fill-rule="evenodd" clip-rule="evenodd" class="icon-part-green" d="M28.9647 13.5687C29.8849 12.9703 30.8283 12.553 32.1542 12.5527C35.1952 12.5521 37.6604 15.0148 37.6604 18.052C37.6604 21.0891 35.1952 23.5511 32.1542 23.5511C30.8691 23.5511 29.894 23.1327 28.9647 22.5351L22.0721 18.052L28.9647 13.5687ZM4.21638 43.8988L30.0411 60.6903C32.5584 62.3193 36.0669 61.7306 37.7741 59.0631C39.4362 56.4661 38.7301 53.0234 36.1448 51.34L2.62803 29.5401C2.62803 29.5401 -0.805552 33.7103 0.23567 38.5748C0.977282 42.0396 4.21638 43.8988 4.21638 43.8988Z" fill="#38D200"></path>
                    <path fill-rule="evenodd" clip-rule="evenodd" class="icon-part-blue" d="M1.62342 18.0384C1.62342 23.556 5.57937 25.9416 5.57937 25.9416L36.1454 45.8223C36.1454 45.8223 39.5348 41.7708 38.5313 36.8528C37.8121 33.328 34.1628 31.2393 34.1628 31.2393L13.888 18.0521L25.7872 10.3133C28.3749 8.63344 29.109 5.17668 27.4269 2.59245C25.7449 0.00822502 22.2839 -0.725041 19.6961 0.954835L5.57779 10.184C5.57779 10.184 1.62342 12.5393 1.62342 18.0384ZM8.69567 60.5642C7.77544 61.1626 6.8321 61.5799 5.50624 61.5802C2.46521 61.5809 0 59.1182 0 56.081C0 53.0439 2.46521 50.5818 5.50624 50.5818C6.79141 50.5818 7.76651 51.0003 8.69567 51.5978L15.5883 56.0809L8.69567 60.5642Z" fill="#0473EA"></path>
                    <path fill-rule="evenodd" clip-rule="evenodd" class="logo-lettering" d="M154.98 29.7863L157.006 31.0221V45.8017H154.98V43.7137C153.992 45.1694 152.411 46.0576 150.509 46.0576C146.951 46.0576 144.407 43.4176 144.407 39.8154C144.407 36.1391 146.951 33.4497 150.509 33.4497C152.411 33.4497 153.992 34.3628 154.98 35.8431V29.7863ZM103.356 29.7807L105.357 31.0159V41.7592C105.357 43.4615 106.394 44.1277 107.704 44.1277C108.692 44.1277 109.68 43.8563 110.545 43.2395V45.1887C109.705 45.8055 108.544 46.0522 107.531 46.0522C104.937 46.0522 103.356 44.8925 103.356 41.6111V29.7807ZM116.633 33.4168C120.141 33.4168 122.439 36.0074 122.439 39.4863C122.439 39.8317 122.414 40.1771 122.365 40.4979H112.755C113.051 42.6938 114.78 44.1495 117.201 44.1495C118.758 44.1495 120.265 43.7054 121.549 42.7925V44.717C120.24 45.6053 118.758 46.0246 117.201 46.0246C113.372 46.0246 110.63 43.5573 110.63 39.8317C110.63 36.1801 112.952 33.4168 116.633 33.4168ZM137.236 33.4168C140.744 33.4168 143.042 36.0074 143.042 39.4863C143.042 39.8317 143.017 40.1771 142.968 40.4979H133.358C133.654 42.6938 135.384 44.1495 137.805 44.1495C139.361 44.1495 140.868 43.7054 142.153 42.7925V44.717C140.843 45.6053 139.361 46.0246 137.805 46.0246C133.975 46.0246 131.233 43.5573 131.233 39.8317C131.233 36.1801 133.555 33.4168 137.236 33.4168ZM85.8027 33.4167C87.705 33.4167 89.2612 34.305 90.2741 35.7607V33.6388H92.2998V45.8026H90.2741V43.73C89.2612 45.1611 87.705 46.0246 85.8027 46.0246C82.2451 46.0246 79.7007 43.3846 79.7007 39.7824C79.7007 36.1061 82.2451 33.4167 85.8027 33.4167ZM60.6783 33.4167C62.1359 33.4167 63.4946 33.8363 64.5817 34.6504V36.8956C63.6181 35.8594 62.2842 35.3166 60.8017 35.3166C58.2079 35.3166 56.3797 37.1177 56.3797 39.7084C56.3797 42.299 58.2327 44.1248 60.8267 44.1248C62.2842 44.1248 63.643 43.73 64.7052 42.8172V44.865C63.5193 45.6792 62.1112 46.0246 60.629 46.0246C56.8987 46.0246 54.3047 43.434 54.3047 39.7084C54.3047 36.0074 56.9726 33.4167 60.6783 33.4167ZM66.9284 29.783L68.9294 31.0183L68.9295 35.7113C69.8436 34.305 71.3011 33.4167 73.1538 33.4167C76.2172 33.4167 77.8478 35.662 77.8478 38.6474V45.8026H75.822V38.9928C75.822 36.6242 74.7845 35.366 72.6599 35.366C70.4117 35.366 68.9295 37.2904 68.9295 39.7084V45.8026H66.9284V29.783ZM101.86 33.4167V35.7113C99.4393 35.366 97.4135 36.9944 97.4135 40.0044V45.8026H95.4124V33.6388H97.4135V36.2295C98.3769 34.4283 99.9333 33.4167 101.86 33.4167ZM131.085 33.4167V35.7113C128.664 35.366 126.638 36.9944 126.638 40.0044V45.8026H124.637V33.6388H126.638V36.2295C127.602 34.4283 129.158 33.4167 131.085 33.4167ZM150.707 35.3496C148.236 35.3496 146.482 37.2247 146.482 39.7908C146.482 42.3073 148.236 44.1578 150.707 44.1578C153.202 44.1578 154.98 42.3073 154.98 39.7908C154.98 37.2247 153.202 35.3496 150.707 35.3496ZM86.0004 35.3166C83.5299 35.3166 81.7758 37.1917 81.7758 39.7577C81.7758 42.2743 83.5299 44.1248 86.0004 44.1248C88.4955 44.1248 90.2741 42.2743 90.2741 39.7577C90.2741 37.1917 88.4955 35.3166 86.0004 35.3166ZM116.658 35.2673C114.435 35.2673 113.101 36.8217 112.779 38.8695H120.314C120.117 36.7969 118.807 35.2673 116.658 35.2673ZM137.261 35.2673C135.038 35.2673 133.704 36.8217 133.383 38.8695H140.918C140.72 36.7969 139.41 35.2673 137.261 35.2673ZM106.911 33.4655C107.425 33.1394 108.083 33.1451 108.591 33.4801L110.607 34.8197L108.617 36.0944C108.11 36.4192 107.46 36.4201 106.952 36.0966L106.909 36.0695C105.956 35.4621 105.957 34.0712 106.911 33.4655ZM78.6879 15.6293C80.5902 15.6293 82.1466 16.5175 83.1592 17.9733V15.8513H85.185V28.0151H83.1592V25.9426C82.1466 27.3737 80.5902 28.2372 78.6879 28.2372C75.1304 28.2372 72.5859 25.5971 72.5859 21.9949C72.5859 18.3187 75.1304 15.6293 78.6879 15.6293ZM66.7805 11.9542V23.9441C66.7805 25.6465 67.8181 26.3127 69.1274 26.3127C70.1157 26.3127 71.1037 26.0413 71.9684 25.4245V27.3737C71.1286 27.9905 69.9673 28.2372 68.9544 28.2372C66.3605 28.2372 64.7794 27.0775 64.7794 23.796V13.1907L66.7805 11.9542ZM150.726 11.9551V28.0151H148.7V25.8932C147.712 27.3489 146.131 28.2372 144.229 28.2372C140.671 28.2372 138.127 25.5971 138.127 21.9949C138.127 18.3187 140.671 15.6293 144.229 15.6293C146.131 15.6293 147.712 16.5423 148.7 18.0226V13.1901L150.726 11.9551ZM121.945 15.6293C123.847 15.6293 125.404 16.5175 126.416 17.9733V15.8513H128.442V28.0151H126.416V25.9426C125.404 27.3737 123.847 28.2372 121.945 28.2372C118.388 28.2372 115.843 25.5971 115.843 21.9949C115.843 18.3187 118.388 15.6293 121.945 15.6293ZM58.6774 15.6293C60.1101 15.6293 61.4441 16.0241 62.3829 16.7396V18.8368C61.2714 17.8499 59.9124 17.2825 58.702 17.2825C57.4173 17.2825 56.5032 17.8746 56.5032 18.8615C56.5032 19.6017 56.8491 20.0458 57.8127 20.4158L60.7032 21.5755C62.2594 22.2417 62.9759 23.1792 62.9759 24.4869C62.9759 26.8062 61.0983 28.2372 58.455 28.2372C56.8491 28.2372 55.3915 27.7931 54.3293 27.0035V24.8324C55.6139 26.0413 57.0468 26.5841 58.4798 26.5841C59.9124 26.5841 60.9502 25.9673 60.9502 24.857C60.9502 24.1908 60.6043 23.6727 59.6903 23.3026L56.7998 22.143C55.3176 21.5016 54.5024 20.6627 54.5024 19.0836C54.5024 16.9617 56.207 15.6293 58.6774 15.6293ZM113.669 11.9551V28.0151H111.643V25.8932C110.655 27.3489 109.074 28.2372 107.172 28.2372C103.614 28.2372 101.07 25.5971 101.07 21.9949C101.07 18.3187 103.614 15.6293 107.172 15.6293C109.074 15.6293 110.655 16.5423 111.643 18.0226V13.1901L113.669 11.9551ZM138.003 15.6293V17.9239C135.582 17.5785 133.556 19.2069 133.556 22.217V28.0151H131.555V15.8513H133.556V18.442C134.519 16.6409 136.076 15.6293 138.003 15.6293ZM94.523 15.6293C97.5863 15.6293 99.217 17.8745 99.217 20.86V28.0151H97.1912V21.2054C97.1912 18.8368 96.1537 17.5785 94.029 17.5785C91.7809 17.5785 90.2987 19.503 90.2987 21.9209V28.0151H88.2976V15.8513H90.2987V17.9239C91.2128 16.5175 92.6703 15.6293 94.523 15.6293ZM78.8856 17.5291C76.4151 17.5291 74.661 19.4043 74.661 21.9703C74.661 24.4869 76.4151 26.3373 78.8856 26.3373C81.3807 26.3373 83.1592 24.4869 83.1592 21.9703C83.1592 19.4043 81.3807 17.5291 78.8856 17.5291ZM107.37 17.5291C104.899 17.5291 103.145 19.4043 103.145 21.9703C103.145 24.4869 104.899 26.3373 107.37 26.3373C109.865 26.3373 111.643 24.4869 111.643 21.9703C111.643 19.4043 109.865 17.5291 107.37 17.5291ZM144.427 17.5291C141.956 17.5291 140.202 19.4043 140.202 21.9703C140.202 24.4869 141.956 26.3373 144.427 26.3373C146.922 26.3373 148.7 24.4869 148.7 21.9703C148.7 19.4043 146.922 17.5291 144.427 17.5291ZM122.143 17.5291C119.672 17.5291 117.918 19.4043 117.918 21.9703C117.918 24.4869 119.672 26.3373 122.143 26.3373C124.638 26.3373 126.416 24.4869 126.416 21.9703C126.416 19.4043 124.638 17.5291 122.143 17.5291ZM69.5698 15.8293C70.0761 15.5033 70.7261 15.5009 71.2349 15.8232L71.2775 15.8502C72.2325 16.4553 72.2346 17.8462 71.2814 18.4541C70.7683 18.7815 70.1105 18.7773 69.6015 18.4435L67.5827 17.1087L69.5698 15.8293Z"></path>
                </svg>
                <div class="navbar-divider"></div>
                <div>
                    <h1>AI Factory Model Monitoring</h1>
                </div>
            </div>
            <div class="navbar-nav">
                <span class="nav-badge">v1.0</span>
            </div>
        </div>
    """)

    # Sidebar for controls
    with gr.Sidebar(open=True, width=400):
        gr.Markdown("## Controls")
        
        # Data source selection
        with gr.Group(elem_classes="bento-card"):
            mode = gr.Radio(
                ["Synthetic demo", "PostgreSQL"],
                value="Synthetic demo",
                label="Data source",
            )
        
        # Data generation/fetching controls
        with gr.Group(visible=True) as synthetic_group:
            with gr.Group(elem_classes="bento-card"):
                gr.Markdown("#### Synthetic Data")
                ref_n = gr.Number(
                    value=2000, label="Reference rows", precision=0
                )
                cur_n = gr.Number(value=2000, label="Current rows", precision=0)
                drift_strength = gr.Slider(
                    minimum=0.0,
                    maximum=1.0,
                    value=0.2,
                    step=0.05,
                    label="Drift strength",
                )
                seed = gr.Number(value=42, label="Seed", precision=0)
            compute_synth = gr.Button("Generate data + Compute", variant="primary")

        with gr.Group(visible=False) as postgres_group:
            with gr.Group(elem_classes="bento-card"):
                gr.Markdown("#### PostgreSQL Connection")
                pg_host = gr.Textbox(value="localhost", label="Host")
                pg_port = gr.Number(value=5432, label="Port", precision=0)
                pg_database = gr.Textbox(value="driftdb", label="Database")
                pg_user = gr.Textbox(value="driftuser", label="User")
                pg_password = gr.Textbox(
                    value="driftpass", label="Password", type="password"
                )

            test_conn_btn = gr.Button("Test Connection", variant="primary")
            conn_status = gr.Markdown("", elem_classes="connection-status")

            with gr.Group(elem_classes="bento-card"):
                gr.Markdown("#### Table Selection")
                ref_table = gr.Dropdown(
                    label="Reference Table",
                    choices=[],
                    interactive=True,
                    allow_custom_value=True,
                )
                cur_table = gr.Dropdown(
                    label="Current Table",
                    choices=[],
                    interactive=True,
                    allow_custom_value=True,
                )

            compute_postgres = gr.Button("Fetch data + Compute", variant="primary")
        
        # Threshold controls
        with gr.Group(elem_classes="bento-card"):
            gr.Markdown("#### Detection Thresholds")
            alpha = gr.Slider(
                0.001, 0.2, value=0.05, step=0.001, label="Alpha (KS/Chi-square)"
            )
            wasserstein_threshold = gr.Slider(
                0.0,
                1.0,
                value=0.10,
                step=0.01,
                label="Wasserstein threshold",
            )
            js_threshold = gr.Slider(
                0.0,
                1.0,
                value=0.10,
                step=0.01,
                label="JS distance threshold",
            )
            euclidean_threshold = gr.Slider(
                0.0,
                1.0,
                value=0.10,
                step=0.01,
                label="Euclidean threshold",
            )
            psi_threshold = gr.Slider(
                0.0, 1.0, value=0.10, step=0.01, label="PSI threshold"
            )
            bins = gr.Slider(
                10, 200, value=40, step=5, label="Histogram bins"
            )
        
        # Notification settings
        with gr.Group(elem_classes="bento-card"):
            gr.Markdown("#### Notification Settings")
            notify_enabled = gr.Checkbox(
                value=True,
                label="Enable system notifications",
                info="Show desktop notifications when drift is detected"
            )
            notify_sound = gr.Checkbox(
                value=True,
                label="Enable notification sound",
                info="Play sound with notifications"
            )
            notify_min_drift = gr.Slider(
                1, 10,
                value=1,
                step=1,
                label="Minimum drift threshold",
                info="Number of drifted features required to notify"
            )
        test_notification_btn = gr.Button("Test Notification", variant="primary")
        test_notification_status = gr.Markdown("", elem_classes="connection-status")
    
    # Main dashboard content
    with gr.Tabs():
        with gr.Tab("Overview"):
            # Create empty cards with warning
            (empty_card1, empty_card2, empty_card3, empty_card4, empty_card5,
            empty_card6, empty_card7, empty_card8, empty_card9, empty_card10,
            empty_card11, empty_card12, empty_card13) = _create_empty_cards()

            gr.Markdown("### Primary Metrics")
            with gr.Row():
                with gr.Column(scale=1):
                    total_features_card = gr.HTML(value=empty_card1)
                with gr.Column(scale=1):
                    drifted_features_card = gr.HTML(value=empty_card2)
                with gr.Column(scale=1):
                    drift_rate_card = gr.HTML(value=empty_card3)
                with gr.Column(scale=1):
                    stable_features_card = gr.HTML(value=empty_card4)
                    
            gr.Markdown("### Feature Breakdown")
            with gr.Row():
                with gr.Column(scale=1):
                    numerical_features_card = gr.HTML(value=empty_card5)
                with gr.Column(scale=1):
                    categorical_features_card = gr.HTML(value=empty_card6)
                with gr.Column(scale=1):
                    critical_drift_card = gr.HTML(value=empty_card7)
                    
            gr.Markdown("### Statistical Insights")
            with gr.Row():
                with gr.Column(scale=1):
                    total_tests_card = gr.HTML(value=empty_card8)
                with gr.Column(scale=1):
                    avg_pvalue_card = gr.HTML(value=empty_card9)
                with gr.Column(scale=1):
                    max_statistic_card = gr.HTML(value=empty_card10)
                    
            gr.Markdown("### Data Volume")
            with gr.Row():
                with gr.Column(scale=1):
                    ref_samples_card = gr.HTML(value=empty_card11)
                with gr.Column(scale=1):
                    cur_samples_card = gr.HTML(value=empty_card12)
                with gr.Column(scale=1):
                    total_datapoints_card = gr.HTML(value=empty_card13)

            updated_timestamp = gr.Markdown("", elem_classes="timestamp-display")

            gr.Markdown("### Test Results Summary")
            
            # Create empty table with helpful message
            empty_counts = pd.DataFrame(
                {
                    "test": ["No data loaded yet"],
                    "total": ["—"],
                    "drifted": ["—"],
                    "rate": ["Select a data source above"],
                }
            )
            counts_table = gr.Dataframe(
                value=empty_counts, interactive=False, wrap=True
            )

        with gr.Tab("Results"):
            with gr.Row():
                feat_filter = gr.Dropdown(
                    choices=[], multiselect=True, label="Features"
                )
                type_filter = gr.Dropdown(choices=[], multiselect=True, label="Type")
                test_filter = gr.Dropdown(choices=[], multiselect=True, label="Test")
            apply_filters = gr.Button("Refresh table", variant="primary")
            results_table = gr.Dataframe(interactive=False, wrap=True)
            with gr.Row():
                download_csv = gr.DownloadButton(label="Download results (CSV)", elem_id="download-csv-btn")
                download_json = gr.DownloadButton(label="Download results (JSON)", elem_id="download-json-btn")

        with gr.Tab("Statistics"):
            gr.Markdown("### Summary Statistics Comparison")
            gr.Markdown("Compare descriptive statistics between reference and current datasets for numerical features.")
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    summary_stats_ref_table = gr.Dataframe(
                        interactive=False, 
                        wrap=True,
                        value=pd.DataFrame({"Message": ["Load data to see reference statistics"]})
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    summary_stats_cur_table = gr.Dataframe(
                        interactive=False, 
                        wrap=True,
                        value=pd.DataFrame({"Message": ["Load data to see current statistics"]})
                    )
            
            gr.Markdown("### Missing Values Comparison")
            gr.Markdown("Compare missing value counts and percentages across all features.")
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    missing_values_ref_table = gr.Dataframe(
                        interactive=False, 
                        wrap=True,
                        value=pd.DataFrame({"Message": ["Load data to see reference missing values"]})
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    missing_values_cur_table = gr.Dataframe(
                        interactive=False, 
                        wrap=True,
                        value=pd.DataFrame({"Message": ["Load data to see current missing values"]})
                    )
            
            gr.Markdown("### Data Types & Unique Values")
            gr.Markdown("Compare data types and unique value counts between datasets.")
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    data_types_ref_table = gr.Dataframe(
                        interactive=False, 
                        wrap=True,
                        value=pd.DataFrame({"Message": ["Load data to see reference data types"]})
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    data_types_cur_table = gr.Dataframe(
                        interactive=False, 
                        wrap=True,
                        value=pd.DataFrame({"Message": ["Load data to see current data types"]})
                    )
            
            gr.Markdown("### Categorical Features Analysis")
            gr.Markdown("Compare categorical feature statistics including top categories and their frequencies.")
            categorical_stats_table = gr.Dataframe(
                interactive=False, 
                wrap=True,
                value=pd.DataFrame({"Message": ["Load data to see categorical statistics comparison"]})
            )

        with gr.Tab("Explore"):
            selected_feature = gr.Dropdown(
                choices=[], label="Select a feature", allow_custom_value=True
            )
            plot_type = gr.Radio(
                [
                    "Distribution",
                    "CDF (KS test)",
                    "Wasserstein",
                    "Jensen-Shannon (categorical)",
                    "Euclidean (categorical)",
                    "Chi-square (categorical)",
                ],
                value="Distribution",
                label="Plot type",
            )
            plot = gr.Plot()

    results_state = gr.State(None)
    feature_type_map_state = gr.State({})
    feature_choices_state = gr.State([])
    type_choices_state = gr.State([])
    test_choices_state = gr.State([])
    reference_state = gr.State(None)
    current_state = gr.State(None)

    def _toggle_groups(selected_mode: str):
        return (
            gr.update(visible=(selected_mode == "Synthetic demo")),
            gr.update(visible=(selected_mode == "PostgreSQL")),
        )

    mode.change(
        _toggle_groups,
        inputs=mode,
        outputs=[synthetic_group, postgres_group],
    )

    def _compute_synth_handler(
        ref_n_val: float,
        cur_n_val: float,
        seed_val: float,
        drift_strength_val: float,
        alpha_val: float,
        wass_val: float,
        js_val: float,
        eucl_val: float,
        psi_val: float,
        bins_val: int,
        progress=gr.Progress(),
    ):
        progress(0, desc="Generating synthetic data...")
        reference, current = generate_synthetic_data(
            int(ref_n_val), int(cur_n_val), int(seed_val), float(drift_strength_val)
        )
        return _build_compute_response(
            reference,
            current,
            float(alpha_val),
            float(js_val),
            float(psi_val),
            float(wass_val),
            float(eucl_val),
            int(bins_val),
        )

    compute_synth.click(
        _compute_synth_handler,
        inputs=[
            ref_n,
            cur_n,
            seed,
            drift_strength,
            alpha,
            wasserstein_threshold,
            js_threshold,
            euclidean_threshold,
            psi_threshold,
            bins,
        ],
        outputs=[
            total_features_card,
            drifted_features_card,
            drift_rate_card,
            stable_features_card,
            numerical_features_card,
            categorical_features_card,
            critical_drift_card,
            total_tests_card,
            avg_pvalue_card,
            max_statistic_card,
            ref_samples_card,
            cur_samples_card,
            total_datapoints_card,
            counts_table,
            feat_filter,
            type_filter,
            test_filter,
            results_table,
            download_csv,
            download_json,
            results_state,
            feature_type_map_state,
            feature_choices_state,
            type_choices_state,
            test_choices_state,
            selected_feature,
            plot,
            updated_timestamp,
            summary_stats_ref_table,
            summary_stats_cur_table,
            missing_values_ref_table,
            missing_values_cur_table,
            data_types_ref_table,
            data_types_cur_table,
            categorical_stats_table,
            reference_state,
            current_state,
        ],
    )

    def _test_connection_handler(host, port, database, user, password):
        """Test connection and update table dropdowns."""
        status, tables = _test_pg_connection(host, port, database, user, password)
        return (
            status,
            gr.update(choices=tables, value=tables[0] if tables else None),
            gr.update(
                choices=tables,
                value=tables[1] if len(tables) > 1 else (tables[0] if tables else None),
            ),
        )

    test_conn_btn.click(
        _test_connection_handler,
        inputs=[pg_host, pg_port, pg_database, pg_user, pg_password],
        outputs=[conn_status, ref_table, cur_table],
    )

    # Notification settings handlers
    def _update_notification_settings(enabled, sound, min_drift):
        """Update notification service configuration."""
        notification_service = get_notification_service()
        notification_service.update_config(
            enabled=enabled,
            sound_enabled=sound,
            min_drift_threshold=int(min_drift)
        )
    
    def _test_notification_handler():
        """Test the notification system."""
        notification_service = get_notification_service()
        success = notification_service.test_notification()
        if success:
            return "Test notification sent successfully!"
        else:
            return "Failed to send notification. Check system permissions."
    
    # Update notification settings when controls change
    notify_enabled.change(
        _update_notification_settings,
        inputs=[notify_enabled, notify_sound, notify_min_drift],
        outputs=None
    )
    
    notify_sound.change(
        _update_notification_settings,
        inputs=[notify_enabled, notify_sound, notify_min_drift],
        outputs=None
    )
    
    notify_min_drift.change(
        _update_notification_settings,
        inputs=[notify_enabled, notify_sound, notify_min_drift],
        outputs=None
    )
    
    # Test notification button
    test_notification_btn.click(
        _test_notification_handler,
        inputs=None,
        outputs=[test_notification_status]
    )

    def _compute_postgres_handler(
        host,
        port,
        database,
        user,
        password,
        ref_tbl,
        cur_tbl,
        alpha_val,
        wass_val,
        js_val,
        eucl_val,
        psi_val,
        bins_val,
        progress=gr.Progress(),
    ):
        """Fetch data from PostgreSQL and compute drift."""
        if not ref_tbl or not cur_tbl:
            raise gr.Error("Please select both reference and current tables.")

        progress(0, desc="Connecting to PostgreSQL...")
        reference_df = _fetch_table_from_postgres(
            host, port, database, user, password, ref_tbl
        )
        progress(0.1, desc="Loading current data from PostgreSQL...")
        current_df = _fetch_table_from_postgres(
            host, port, database, user, password, cur_tbl
        )

        return _build_compute_response(
            reference_df,
            current_df,
            alpha_val,
            js_val,
            psi_val,
            wass_val,
            eucl_val,
            bins_val,
        )

    compute_postgres.click(
        _compute_postgres_handler,
        inputs=[
            pg_host,
            pg_port,
            pg_database,
            pg_user,
            pg_password,
            ref_table,
            cur_table,
            alpha,
            wasserstein_threshold,
            js_threshold,
            euclidean_threshold,
            psi_threshold,
            bins,
        ],
        outputs=[
            total_features_card,
            drifted_features_card,
            drift_rate_card,
            stable_features_card,
            numerical_features_card,
            categorical_features_card,
            critical_drift_card,
            total_tests_card,
            avg_pvalue_card,
            max_statistic_card,
            ref_samples_card,
            cur_samples_card,
            total_datapoints_card,
            counts_table,
            feat_filter,
            type_filter,
            test_filter,
            results_table,
            download_csv,
            download_json,
            results_state,
            feature_type_map_state,
            feature_choices_state,
            type_choices_state,
            test_choices_state,
            selected_feature,
            plot,
            updated_timestamp,
            summary_stats_ref_table,
            summary_stats_cur_table,
            missing_values_ref_table,
            missing_values_cur_table,
            data_types_ref_table,
            data_types_cur_table,
            categorical_stats_table,
            reference_state,
            current_state,
        ],
    )

    def _on_feat_change_and_filter(
        selected_feats: List[str],
        feature_type_map: Dict[str, str],
        type_choices: List[str],
        test_choices: List[str],
        results: Optional[pd.DataFrame],
        current_type_filter: List[str],
    ):
        """Update type/test filters AND apply filters to table."""
        # Update the filter dropdowns
        if not selected_feats:
            new_type_filter = type_choices if type_choices else []
            new_test_filter_choices = test_choices if test_choices else []
            new_test_filter_value = test_choices if test_choices else []
        else:
            selected_types = sorted(
                {
                    feature_type_map.get(f)
                    for f in selected_feats
                    if f in feature_type_map
                }
            )
            new_type_filter = selected_types
            new_test_filter_choices = _tests_for_types(selected_types, test_choices)
            new_test_filter_value = new_test_filter_choices if new_test_filter_choices else []

        # Apply filters to table
        table_view, csv_path, json_path = _apply_filters(
            results,
            selected_feats or [],
            new_type_filter or [],
            new_test_filter_value or [],
        )

        return (
            gr.update(value=new_type_filter if new_type_filter else []),
            gr.update(choices=new_test_filter_choices, value=new_test_filter_value if new_test_filter_value else []),
            table_view,
            csv_path,
            json_path,
        )

    def _on_type_change_and_filter(
        selected_types: List[str],
        all_tests: List[str],
        results: Optional[pd.DataFrame],
        current_feat_filter: List[str],
    ):
        """Update test filter AND apply filters to table."""
        test_for_types = _tests_for_types(selected_types, all_tests)

        # Apply filters to table
        table_view, csv_path, json_path = _apply_filters(
            results,
            current_feat_filter or [],
            selected_types or [],
            test_for_types or [],
        )

        return (
            gr.update(choices=test_for_types, value=test_for_types if test_for_types else []),
            table_view,
            csv_path,
            json_path,
        )

    def _on_test_filter_change(
        results: Optional[pd.DataFrame],
        f: List[str],
        t: List[str],
        tests: List[str],
    ):
        """Apply filters when test filter changes."""
        return _apply_filters(results, f or [], t or [], tests or [])

    feat_filter.change(
        _on_feat_change_and_filter,
        inputs=[
            feat_filter,
            feature_type_map_state,
            type_choices_state,
            test_choices_state,
            results_state,
            type_filter,
        ],
        outputs=[type_filter, test_filter, results_table, download_csv, download_json],
    )

    type_filter.change(
        _on_type_change_and_filter,
        inputs=[type_filter, test_choices_state, results_state, feat_filter],
        outputs=[test_filter, results_table, download_csv, download_json],
    )

    test_filter.change(
        _on_test_filter_change,
        inputs=[results_state, feat_filter, type_filter, test_filter],
        outputs=[results_table, download_csv, download_json],
    )

    def _apply_filters_handler(
        results: Optional[pd.DataFrame], f: List[str], t: List[str], tests: List[str]
    ):
        table_view, csv_path, json_path = _apply_filters(
            results, f or [], t or [], tests or []
        )
        return table_view, csv_path, json_path

    # Keep apply_filters button for manual refresh if needed
    apply_filters.click(
        _apply_filters_handler,
        inputs=[results_state, feat_filter, type_filter, test_filter],
        outputs=[results_table, download_csv, download_json],
    )

    # Threshold sliders dynamically update results
    def _threshold_change_handler(
        results: Optional[pd.DataFrame],
        alpha_val: float,
        wass_val: float,
        js_val: float,
        eucl_val: float,
        psi_val: float,
        f: List[str],
        t: List[str],
        tests: List[str],
    ):
        return _update_thresholds_and_recalculate(
            results,
            float(alpha_val),
            float(wass_val),
            float(js_val),
            float(eucl_val),
            float(psi_val),
            f or [],
            t or [],
            tests or [],
        )

    for threshold_slider in [
        alpha,
        wasserstein_threshold,
        js_threshold,
        euclidean_threshold,
        psi_threshold,
    ]:
        threshold_slider.change(
            _threshold_change_handler,
            inputs=[
                results_state,
                alpha,
                wasserstein_threshold,
                js_threshold,
                euclidean_threshold,
                psi_threshold,
                feat_filter,
                type_filter,
                test_filter,
            ],
            outputs=[
                counts_table,
                results_table,
                download_csv,
                download_json,
                results_state,
            ],
        )

    # Update plot type choices when feature changes
    selected_feature.change(
        _update_plot_type_choices,
        inputs=[reference_state, selected_feature],
        outputs=[plot_type],
    ).then(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )
    bins.change(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )

    plot_type.change(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )



def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Gradio Drift Monitoring app")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "7860")))
    parser.add_argument("--host", type=str, default=os.environ.get("HOST", "0.0.0.0"))
    args = parser.parse_args()

    os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")

    demo.launch(
        server_name=args.host, server_port=args.port, inbrowser=False, show_error=True
    )


if __name__ == "__main__":
    main()
