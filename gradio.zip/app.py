from __future__ import annotations

import argparse
import os
from typing import Any, Dict, List, Optional, Tuple
import tempfile

import gradio as gr
import pandas as pd

from monitor.data import generate_synthetic_data
from monitor.drift import detect_drift, identify_column_types
from monitor.viz import (
    plot_categorical_distributions,
    plot_numeric_distributions,
    plot_numeric_ecdf,
    plot_numeric_binned_probs,
    plot_categorical_difference,
    plot_chi_square_contributions,
    plot_wasserstein_distance,
    plot_jensen_shannon_divergence,
    plot_jensen_shannon_categorical,
)

TESTS_BY_TYPE: Dict[str, List[str]] = {
    "numerical": ["ks", "jensen-shannon", "psi"],
    "categorical": ["chi-square", "jensen-shannon", "psi"],
}


def _read_csv_from_gradio(file_obj: Any) -> pd.DataFrame:
    if file_obj is None:
        raise gr.Error("Please provide a CSV file.")
    path = getattr(file_obj, "name", None) or getattr(file_obj, "path", None)
    if not path:
        raise gr.Error("Could not read uploaded file.")
    return pd.read_csv(path)


def _write_temp_file(name: str, data: bytes) -> str:
    tmpdir = tempfile.mkdtemp(prefix="drift_")
    path = os.path.join(tmpdir, name)
    with open(path, "wb") as f:
        f.write(data)
    return path


def _tests_for_types(selected_types: List[str], all_tests: List[str]) -> List[str]:
    out: set[str] = set()
    for t in selected_types:
        out.update(TESTS_BY_TYPE.get(t, []))
    # Fallback to all if none resolved
    return sorted(out) or sorted(all_tests)


def _compute_from_dfs(
    reference: pd.DataFrame,
    current: pd.DataFrame,
    alpha: float,
    js_threshold: float,
    psi_threshold: float,
    wasserstein_threshold: float,
    bins: int,
) -> Tuple[
    str,
    pd.DataFrame,
    object,
    object,
    object,
    pd.DataFrame,
    str,
    str,
    pd.DataFrame,
    Dict[str, str],
    List[str],
    List[str],
    List[str],
    object,
    Any,
]:
    results = detect_drift(
        reference,
        current,
        alpha=alpha,
        js_threshold=js_threshold,
        psi_threshold=psi_threshold,
        wasserstein_threshold=wasserstein_threshold,
        bins=bins,
    )

    total_features = len(results["feature"].unique()) if not results.empty else 0
    drifted = (
        int(results.groupby("feature")["drift_detected"].any().sum())
        if not results.empty
        else 0
    )
    pct_drifted = 100.0 * drifted / max(total_features, 1)
    metrics_md = (
        f"**Total features**: {total_features}\n\n"
        f"**Features with drift**: {drifted}\n\n"
        f"**% Drifted**: {pct_drifted:.1f}%\n\n"
        f"Thresholds: KS/Chi-square uses alpha; Wasserstein, JS, and PSI use the sliders."
    )

    if results.empty:
        counts = pd.DataFrame({"test": [], "total": [], "drifted": [], "rate": []})
    else:
        counts = (
            results.groupby(["test"])["drift_detected"]
            .agg(total="count", drifted="sum")
            .reset_index()
        )
        counts["rate"] = (counts["drifted"] / counts["total"]).round(3)

    feature_type_map: Dict[str, str] = (
        results.groupby("feature")["feature_type"].first().to_dict()
        if not results.empty
        else {}
    )
    all_features = (
        sorted(results["feature"].unique().tolist()) if not results.empty else []
    )
    all_types = (
        sorted(results["feature_type"].unique().tolist()) if not results.empty else []
    )
    all_tests = sorted(results["test"].unique().tolist()) if not results.empty else []

    feat_filter_update = gr.update(choices=all_features, value=[])
    type_filter_update = gr.update(choices=all_types, value=all_types)
    test_filter_update = gr.update(choices=all_tests, value=all_tests)

    table_view = results

    csv_path = _write_temp_file(
        "drift_report.csv", results.to_csv(index=False).encode("utf-8")
    )
    json_path = _write_temp_file(
        "drift_report.json", results.to_json(orient="records", indent=2).encode("utf-8")
    )

    selected_feature_update = gr.update(
        choices=list(reference.columns),
        value=(list(reference.columns)[0] if len(reference.columns) else None),
    )
    if reference.shape[1] > 0:
        first_feature = reference.columns[0]
        numeric_cols, categorical_cols = identify_column_types(reference)
        if first_feature in numeric_cols:
            init_fig = plot_numeric_distributions(
                reference[first_feature], current[first_feature], bins=bins
            )
        else:
            init_fig = plot_categorical_distributions(
                reference[first_feature], current[first_feature]
            )
    else:
        init_fig = None

    return (
        metrics_md,
        counts,
        feat_filter_update,
        type_filter_update,
        test_filter_update,
        table_view,
        csv_path,
        json_path,
        results,
        feature_type_map,
        all_features,
        all_types,
        all_tests,
        selected_feature_update,
        init_fig,
    )


def _build_compute_response(
    reference: pd.DataFrame,
    current: pd.DataFrame,
    alpha: float,
    js_threshold: float,
    psi_threshold: float,
    wasserstein_threshold: float,
    bins: int,
) -> Tuple[
    str,
    pd.DataFrame,
    object,
    object,
    object,
    pd.DataFrame,
    str,
    str,
    pd.DataFrame,
    Dict[str, str],
    List[str],
    List[str],
    List[str],
    object,
    Any,
    pd.DataFrame,
    pd.DataFrame,
]:
    (
        m_md,
        counts,
        feat_u,
        type_u,
        test_u,
        table_view,
        csv_b,
        json_b,
        results,
        feat_type_map,
        all_feats,
        all_types,
        all_tests,
        feature_u,
        init_fig,
    ) = _compute_from_dfs(
        reference,
        current,
        float(alpha),
        float(js_threshold),
        float(psi_threshold),
        float(wasserstein_threshold),
        int(bins),
    )
    return (
        m_md,
        counts,
        feat_u,
        type_u,
        test_u,
        table_view,
        csv_b,
        json_b,
        results,
        feat_type_map,
        all_feats,
        all_types,
        all_tests,
        feature_u,
        init_fig,
        reference,
        current,
    )


def _recalculate_drift_flags(
    results: Optional[pd.DataFrame],
    alpha: float,
    wasserstein_threshold: float,
    js_threshold: float,
    psi_threshold: float,
) -> pd.DataFrame:
    """
    Recalculate drift_detected flags based on new thresholds without recomputing statistics.
    """
    if results is None or len(results) == 0:
        return pd.DataFrame()
    
    updated = results.copy()
    
    # Update drift_detected based on test type and threshold
    for idx, row in updated.iterrows():
        test = row["test"]
        
        if test in ["ks", "chi-square"]:
            # p-value based tests
            updated.at[idx, "threshold"] = alpha
            updated.at[idx, "drift_detected"] = row["p_value"] < alpha
        elif test == "wasserstein":
            # Wasserstein uses its own threshold
            updated.at[idx, "threshold"] = wasserstein_threshold
            updated.at[idx, "drift_detected"] = row["statistic"] >= wasserstein_threshold
        elif test == "jensen-shannon":
            # JS uses its own threshold
            updated.at[idx, "threshold"] = js_threshold
            updated.at[idx, "drift_detected"] = row["statistic"] >= js_threshold
        elif test == "psi":
            # PSI uses its own threshold
            updated.at[idx, "threshold"] = psi_threshold
            updated.at[idx, "drift_detected"] = row["statistic"] >= psi_threshold
    
    return updated


def _update_thresholds_and_recalculate(
    results: Optional[pd.DataFrame],
    alpha: float,
    wasserstein_threshold: float,
    js_threshold: float,
    psi_threshold: float,
    feat_filter: List[str],
    type_filter: List[str],
    test_filter: List[str],
) -> Tuple[str, pd.DataFrame, pd.DataFrame, str, str, pd.DataFrame]:
    """
    Update thresholds, recalculate drift flags, update metrics, and apply filters.
    """
    if results is None or len(results) == 0:
        empty = pd.DataFrame()
        return "", empty, empty, "", "", empty
    
    # Recalculate drift flags with new thresholds
    updated_results = _recalculate_drift_flags(
        results, alpha, wasserstein_threshold, js_threshold, psi_threshold
    )
    
    # Recalculate metrics
    total_features = len(updated_results["feature"].unique())
    drifted = int(updated_results.groupby("feature")["drift_detected"].any().sum())
    pct_drifted = 100.0 * drifted / max(total_features, 1)
    metrics_md = (
        f"**Total features**: {total_features}\n\n"
        f"**Features with drift**: {drifted}\n\n"
        f"**% Drifted**: {pct_drifted:.1f}%\n\n"
        f"Thresholds: KS/Chi-square uses alpha; Wasserstein, JS, and PSI use the sliders."
    )
    
    # Recalculate counts
    counts = (
        updated_results.groupby(["test"])["drift_detected"]
        .agg(total="count", drifted="sum")
        .reset_index()
    )
    counts["rate"] = (counts["drifted"] / counts["total"]).round(3)
    
    # Apply filters
    filtered = updated_results.copy()
    if feat_filter:
        filtered = filtered[filtered["feature"].isin(feat_filter)]
    if type_filter:
        filtered = filtered[filtered["feature_type"].isin(type_filter)]
    if test_filter:
        filtered = filtered[filtered["test"].isin(test_filter)]
    
    csv_path = _write_temp_file(
        "drift_report.csv", filtered.to_csv(index=False).encode("utf-8")
    )
    json_path = _write_temp_file(
        "drift_report.json",
        filtered.to_json(orient="records", indent=2).encode("utf-8"),
    )
    
    return metrics_md, counts, filtered, csv_path, json_path, updated_results


def _apply_filters(
    results: Optional[pd.DataFrame],
    feat_filter: List[str],
    type_filter: List[str],
    test_filter: List[str],
) -> Tuple[pd.DataFrame, str, str]:
    if results is None or len(results) == 0:
        empty = pd.DataFrame()
        return empty, "", ""

    filtered = results.copy()
    if feat_filter:
        filtered = filtered[filtered["feature"].isin(feat_filter)]
    if type_filter:
        filtered = filtered[filtered["feature_type"].isin(type_filter)]
    if test_filter:
        filtered = filtered[filtered["test"].isin(test_filter)]

    table_view = filtered
    csv_path = _write_temp_file(
        "drift_report.csv", filtered.to_csv(index=False).encode("utf-8")
    )
    json_path = _write_temp_file(
        "drift_report.json",
        filtered.to_json(orient="records", indent=2).encode("utf-8"),
    )
    return table_view, csv_path, json_path


def _on_feat_change(
    selected_feats: List[str],
    feature_type_map: Dict[str, str],
    type_choices: List[str],
    test_choices: List[str],
) -> Tuple[object, object]:
    if not selected_feats:
        return gr.update(value=type_choices), gr.update(
            choices=test_choices, value=test_choices
        )
    selected_types = sorted(
        {feature_type_map.get(f) for f in selected_feats if f in feature_type_map}
    )
    test_for_types = _tests_for_types(selected_types, test_choices)
    return gr.update(value=selected_types), gr.update(
        choices=test_for_types, value=test_for_types
    )


def _on_type_change(selected_types: List[str], all_tests: List[str]) -> object:
    test_for_types = _tests_for_types(selected_types, all_tests)
    return gr.update(choices=test_for_types, value=test_for_types)


def _render_plot(
    reference: Optional[pd.DataFrame],
    current: Optional[pd.DataFrame],
    feature: Optional[str],
    bins: int,
    plot_type: str,
) -> Any:
    if (
        reference is None
        or current is None
        or not feature
        or feature not in reference.columns
        or feature not in current.columns
    ):
        return None
    numeric_cols, categorical_cols = identify_column_types(reference)
    if feature in numeric_cols:
        if plot_type == "CDF":
            return plot_numeric_ecdf(reference[feature], current[feature])
        if plot_type == "Wasserstein (numerical)":
            return plot_wasserstein_distance(reference[feature], current[feature])
        if plot_type == "Jensen-Shannon":
            return plot_jensen_shannon_divergence(
                reference[feature], current[feature], bins=bins
            )
        if plot_type == "Binned probs (PSI)":
            return plot_numeric_binned_probs(
                reference[feature], current[feature], bins=bins
            )
        return plot_numeric_distributions(
            reference[feature], current[feature], bins=bins
        )
    # Categorical features
    if plot_type == "Jensen-Shannon":
        return plot_jensen_shannon_categorical(reference[feature], current[feature])
    if plot_type == "Categorical diff":
        return plot_categorical_difference(reference[feature], current[feature])
    if plot_type == "Chi-square contrib":
        return plot_chi_square_contributions(reference[feature], current[feature])
    return plot_categorical_distributions(reference[feature], current[feature])


with gr.Blocks(title="Drift Monitoring") as demo:
    gr.Markdown("# Drift Monitoring")

    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("### Controls")
            mode = gr.Radio(
                ["Synthetic demo", "Upload CSVs"],
                value="Synthetic demo",
                label="Data source",
            )

            with gr.Group(visible=True) as synthetic_group:
                ref_n = gr.Number(value=2000, label="Reference rows", precision=0)
                cur_n = gr.Number(value=2000, label="Current rows", precision=0)
                drift_strength = gr.Slider(
                    minimum=0.0,
                    maximum=1.0,
                    value=0.2,
                    step=0.05,
                    label="Drift strength",
                )
                seed = gr.Number(value=42, label="Seed", precision=0)
                compute_synth = gr.Button("Generate data + Compute", variant="primary")

            with gr.Group(visible=False) as upload_group:
                ref_file = gr.File(label="Upload reference CSV", file_types=[".csv"])
                cur_file = gr.File(label="Upload current CSV", file_types=[".csv"])
                compute_upload = gr.Button("Compute", variant="primary")

            alpha = gr.Slider(
                0.001, 0.2, value=0.05, step=0.001, label="Alpha (KS/Chi-square)"
            )
            wasserstein_threshold = gr.Slider(
                0.0, 1.0, value=0.10, step=0.01, label="Wasserstein threshold (numerical)"
            )
            js_threshold = gr.Slider(
                0.0, 1.0, value=0.10, step=0.01, label="JS distance threshold (categorical)"
            )
            psi_threshold = gr.Slider(
                0.0, 1.0, value=0.10, step=0.01, label="PSI threshold"
            )
            bins = gr.Slider(
                10, 200, value=40, step=5, label="Histogram bins (numeric)"
            )

        with gr.Column(scale=3):
            with gr.Tabs():
                with gr.Tab("Overview"):
                    metrics_md = gr.Markdown()
                    counts_table = gr.Dataframe(interactive=False, wrap=True)

                with gr.Tab("Results"):
                    with gr.Row():
                        feat_filter = gr.Dropdown(
                            choices=[], multiselect=True, label="Features"
                        )
                        type_filter = gr.Dropdown(
                            choices=[], multiselect=True, label="Type"
                        )
                        test_filter = gr.Dropdown(
                            choices=[], multiselect=True, label="Test"
                        )
                    apply_filters = gr.Button("Refresh table", variant="secondary", size="sm")
                    results_table = gr.Dataframe(interactive=False, wrap=True)
                    with gr.Row():
                        download_csv = gr.DownloadButton(label="Download results (CSV)")
                        download_json = gr.DownloadButton(
                            label="Download results (JSON)"
                        )

                with gr.Tab("Explore"):
                    selected_feature = gr.Dropdown(choices=[], label="Select a feature")
                    plot_type = gr.Radio(
                        [
                            "Histogram",
                            "CDF",
                            "Wasserstein (numerical)",
                            "Jensen-Shannon",
                            "Binned probs (PSI)",
                            "Categorical diff",
                            "Chi-square contrib",
                        ],
                        value="Histogram",
                        label="Plot type",
                    )
                    plot = gr.Plot()

                with gr.Tab("Algorithm Guide"):
                    gr.Markdown("""
# Drift Detection Algorithms Guide

This guide explains when and how to use each drift detection algorithm, optimized for **large banks and financial institutions**.

---

## 📊 Overview

The system runs **3 tests per feature**:
- **Significance test** (p-value based): KS or Chi-square
- **Alert KPI** (threshold based): Wasserstein or Jensen-Shannon  
- **Reporting KPI** (threshold based): PSI

---

## 🔢 Numerical Features

### 1. **KS Test (Kolmogorov-Smirnov)**
**Type:** Significance test  
**Output:** p-value  
**Use for:** Statistical significance

**How it works:**
- Compares empirical CDFs of reference vs current
- Measures maximum vertical distance between CDFs
- Nonparametric (no distribution assumptions)
- Works on raw continuous data (bin-free)

**When drift is detected:**
- p-value < alpha (default: 0.05)

**Best for:**
- ✅ Standard significance testing
- ✅ Detecting any type of distribution shift (location, scale, shape)
- ✅ Regulatory reporting (well-established test)

**Watch-outs:**
- ⚠️ Over-sensitive with huge sample sizes (N > 100k)
- ⚠️ Only provides yes/no signal (use Wasserstein for effect size)
- ⚠️ 1-D only (cannot handle multivariate drift directly)

---

### 2. **Wasserstein Distance (Earth-Mover's)**
**Type:** Effect size / Alert KPI ⭐  
**Output:** Distance (≥0)  
**Use for:** Primary alerting on drift magnitude

**How it works:**
- Measures "how much work" to transform one distribution into another
- Think of it as moving piles of earth from reference to current shape
- Computed from CDFs (bin-free in 1-D)
- Has units of the original feature (interpretable!)

**When drift is detected:**
- distance ≥ wasserstein_threshold (default: 0.10)

**Best for:**
- ✅ **Top alert KPI** for continuous features
- ✅ Understanding drift magnitude ("how far did it move?")
- ✅ Robust to outliers (works on CDFs)
- ✅ Intuitive interpretation

**Watch-outs:**
- ⚠️ No p-value (pair with KS for significance)
- ⚠️ Thresholds are feature-specific (need to calibrate)
- ⚠️ More compute than binned metrics

**Example thresholds:**
- < 0.05: Negligible drift
- 0.05 - 0.10: Small drift
- 0.10 - 0.25: Moderate drift (⚠️ alert)
- \\> 0.25: Large drift (🚨 investigate)

---

### 3. **PSI (Population Stability Index)**
**Type:** Reporting KPI  
**Output:** Divergence score (≥0)  
**Use for:** Standard model monitoring reports

**How it works:**
- Bins data into fixed buckets (default: 40)
- Computes symmetric KL divergence: KL(ref||cur) + KL(cur||ref)
- Industry standard in banking/finance

**When drift is detected:**
- PSI ≥ psi_threshold (default: 0.10)

**Best for:**
- ✅ **Common reporting KPI** in finance
- ✅ Easy-to-explain thresholds
- ✅ Dashboard-friendly
- ✅ Model risk management compliance

**Watch-outs:**
- ⚠️ Heavily bin-dependent (keep bins fixed!)
- ⚠️ May miss subtle shape shifts
- ⚠️ No units (harder to interpret than Wasserstein)

**Industry-standard thresholds:**
- < 0.10: No significant drift ✅
- 0.10 - 0.25: Small drift (monitor) ⚠️
- \\> 0.25: Large drift (investigate) 🚨

---

## 🏷️ Categorical Features

### 1. **Chi-square Test**
**Type:** Significance test  
**Output:** p-value  
**Use for:** Statistical significance

**How it works:**
- Builds 2×K contingency table (reference vs current × categories)
- Tests if category proportions changed significantly
- Reports Cramér's V as effect size

**When drift is detected:**
- p-value < alpha (default: 0.05)

**Best for:**
- ✅ Standard significance testing
- ✅ Regulatory reporting
- ✅ Pair with JS for effect size

**Watch-outs:**
- ⚠️ Needs expected counts ≥5 in each cell
- ⚠️ Over-flags with huge N
- ⚠️ Not an effect size (use JS or Cramér's V)

---

### 2. **Jensen-Shannon Distance**
**Type:** Effect size / Alert KPI ⭐  
**Output:** Distance (0 to ~0.69)  
**Use for:** Primary alerting on distribution shifts

**How it works:**
- Symmetric, bounded measure of probability distribution difference
- Computed from category probabilities (smoothed to avoid zeros)
- JS = √(½ KL(P||M) + ½ KL(Q||M)) where M = (P+Q)/2

**When drift is detected:**
- distance ≥ js_threshold (default: 0.10)

**Best for:**
- ✅ **Top alert KPI** for categorical features
- ✅ Symmetric (fair comparison)
- ✅ Bounded (0 = identical, ~0.69 = completely different)
- ✅ Great for setting alert thresholds

**Watch-outs:**
- ⚠️ Smooth rare categories to avoid infinity issues
- ⚠️ No p-value (pair with Chi-square)
- ⚠️ Max value is ~0.69 (not 1.0)

**Example thresholds:**
- < 0.05: Negligible drift
- 0.05 - 0.10: Small drift
- 0.10 - 0.20: Moderate drift (⚠️ alert)
- \\> 0.20: Large drift (🚨 investigate)

---

### 3. **PSI (Population Stability Index)**
**Type:** Reporting KPI  
**Output:** Divergence score (≥0)  
**Use for:** Standard model monitoring reports

(Same as numerical, but applied to category probabilities)

**Best for:**
- ✅ **Common reporting KPI** in finance
- ✅ Keep category definitions fixed across time

---

## 🎯 Quick Decision Guide

| Your Question | Recommended Metric |
|--------------|-------------------|
| "Did something change significantly?" | **KS** (numerical) or **Chi-square** (categorical) |
| "How big is the drift? Should I alert?" | **Wasserstein** (numerical) or **Jensen-Shannon** (categorical) |
| "What should I put in my monthly report?" | **PSI** (both types) |
| "Is my model still valid?" | Use **all three** for comprehensive view |
| "Which features drifted most?" | Sort by **Wasserstein** or **JS** distance |

---

## 💡 Best Practices for Large Banks

1. **Use paired metrics:**
   - Numerical: KS (significance) + Wasserstein (magnitude) + PSI (reporting)
   - Categorical: Chi-square (significance) + JS (magnitude) + PSI (reporting)

2. **Set thresholds based on:**
   - Business impact (e.g., model performance degradation)
   - Historical variability (calibrate on stable periods)
   - Regulatory requirements (e.g., SR 11-7)

3. **Monitor trends:**
   - Single drift detection can be noisy
   - Look for sustained drift over multiple periods
   - Track drift velocity (rate of change)

4. **Keep baselines fixed:**
   - Reference data = training data or validation period
   - Don't update reference too frequently (loses trend visibility)
   - Use consistent binning for PSI across time

5. **Combine with business metrics:**
   - Drift detection is early warning
   - Validate with model performance (AUC, precision, etc.)
   - Investigate root causes before retraining

---

## 📚 References

- **KS test**: Massey (1951), "The Kolmogorov-Smirnov Test"
- **Wasserstein**: Ramdas et al. (2017), "On Wasserstein Two-Sample Testing"
- **Jensen-Shannon**: Lin (1991), "Divergence Measures Based on Shannon Entropy"
- **PSI**: Siddiqi (2006), "Credit Risk Scorecards"
- **Model Risk**: SR 11-7 (Federal Reserve guidance on model risk management)
                    """)


    results_state = gr.State(None)
    feature_type_map_state = gr.State({})
    feature_choices_state = gr.State([])
    type_choices_state = gr.State([])
    test_choices_state = gr.State([])
    reference_state = gr.State(None)
    current_state = gr.State(None)

    def _toggle_groups(selected_mode: str):
        return gr.update(visible=(selected_mode == "Synthetic demo")), gr.update(
            visible=(selected_mode == "Upload CSVs")
        )

    mode.change(_toggle_groups, inputs=mode, outputs=[synthetic_group, upload_group])

    def _compute_synth_handler(
        ref_n_val: float,
        cur_n_val: float,
        seed_val: float,
        drift_strength_val: float,
        alpha_val: float,
        wass_val: float,
        js_val: float,
        psi_val: float,
        bins_val: int,
    ):
        reference, current = generate_synthetic_data(
            int(ref_n_val), int(cur_n_val), int(seed_val), float(drift_strength_val)
        )
        return _build_compute_response(
            reference,
            current,
            float(alpha_val),
            float(js_val),
            float(psi_val),
            float(wass_val),
            int(bins_val),
        )

    compute_synth.click(
        _compute_synth_handler,
        inputs=[
            ref_n,
            cur_n,
            seed,
            drift_strength,
            alpha,
            wasserstein_threshold,
            js_threshold,
            psi_threshold,
            bins,
        ],
        outputs=[
            metrics_md,
            counts_table,
            feat_filter,
            type_filter,
            test_filter,
            results_table,
            download_csv,
            download_json,
            results_state,
            feature_type_map_state,
            feature_choices_state,
            type_choices_state,
            test_choices_state,
            selected_feature,
            plot,
            reference_state,
            current_state,
        ],
    )

    def _compute_upload_handler(
        ref_file_obj: Any,
        cur_file_obj: Any,
        alpha_val: float,
        wass_val: float,
        js_val: float,
        psi_val: float,
        bins_val: int,
    ):
        if ref_file_obj is None or cur_file_obj is None:
            raise gr.Error("Provide both reference and current CSV files.")
        reference = _read_csv_from_gradio(ref_file_obj)
        current = _read_csv_from_gradio(cur_file_obj)
        return _build_compute_response(
            reference,
            current,
            float(alpha_val),
            float(js_val),
            float(psi_val),
            float(wass_val),
            int(bins_val),
        )

    compute_upload.click(
        _compute_upload_handler,
        inputs=[ref_file, cur_file, alpha, wasserstein_threshold, js_threshold, psi_threshold, bins],
        outputs=[
            metrics_md,
            counts_table,
            feat_filter,
            type_filter,
            test_filter,
            results_table,
            download_csv,
            download_json,
            results_state,
            feature_type_map_state,
            feature_choices_state,
            type_choices_state,
            test_choices_state,
            selected_feature,
            plot,
            reference_state,
            current_state,
        ],
    )

    def _on_feat_change_and_filter(
        selected_feats: List[str],
        feature_type_map: Dict[str, str],
        type_choices: List[str],
        test_choices: List[str],
        results: Optional[pd.DataFrame],
        current_type_filter: List[str],
    ):
        """Update type/test filters AND apply filters to table."""
        # Update the filter dropdowns
        if not selected_feats:
            new_type_filter = type_choices
            new_test_filter_choices = test_choices
            new_test_filter_value = test_choices
        else:
            selected_types = sorted(
                {feature_type_map.get(f) for f in selected_feats if f in feature_type_map}
            )
            new_type_filter = selected_types
            new_test_filter_choices = _tests_for_types(selected_types, test_choices)
            new_test_filter_value = new_test_filter_choices
        
        # Apply filters to table
        table_view, csv_path, json_path = _apply_filters(
            results, selected_feats or [], new_type_filter or [], new_test_filter_value or []
        )
        
        return (
            gr.update(value=new_type_filter),
            gr.update(choices=new_test_filter_choices, value=new_test_filter_value),
            table_view,
            csv_path,
            json_path,
        )

    def _on_type_change_and_filter(
        selected_types: List[str],
        all_tests: List[str],
        results: Optional[pd.DataFrame],
        current_feat_filter: List[str],
    ):
        """Update test filter AND apply filters to table."""
        test_for_types = _tests_for_types(selected_types, all_tests)
        
        # Apply filters to table
        table_view, csv_path, json_path = _apply_filters(
            results, current_feat_filter or [], selected_types or [], test_for_types or []
        )
        
        return (
            gr.update(choices=test_for_types, value=test_for_types),
            table_view,
            csv_path,
            json_path,
        )

    def _on_test_filter_change(
        results: Optional[pd.DataFrame],
        f: List[str],
        t: List[str],
        tests: List[str],
    ):
        """Apply filters when test filter changes."""
        return _apply_filters(results, f or [], t or [], tests or [])

    feat_filter.change(
        _on_feat_change_and_filter,
        inputs=[
            feat_filter,
            feature_type_map_state,
            type_choices_state,
            test_choices_state,
            results_state,
            type_filter,
        ],
        outputs=[type_filter, test_filter, results_table, download_csv, download_json],
    )
    
    type_filter.change(
        _on_type_change_and_filter,
        inputs=[type_filter, test_choices_state, results_state, feat_filter],
        outputs=[test_filter, results_table, download_csv, download_json],
    )
    
    test_filter.change(
        _on_test_filter_change,
        inputs=[results_state, feat_filter, type_filter, test_filter],
        outputs=[results_table, download_csv, download_json],
    )

    def _apply_filters_handler(
        results: Optional[pd.DataFrame], f: List[str], t: List[str], tests: List[str]
    ):
        table_view, csv_path, json_path = _apply_filters(
            results, f or [], t or [], tests or []
        )
        return table_view, csv_path, json_path

    # Keep apply_filters button for manual refresh if needed
    apply_filters.click(
        _apply_filters_handler,
        inputs=[results_state, feat_filter, type_filter, test_filter],
        outputs=[results_table, download_csv, download_json],
    )

    # Threshold sliders dynamically update results
    def _threshold_change_handler(
        results: Optional[pd.DataFrame],
        alpha_val: float,
        wass_val: float,
        js_val: float,
        psi_val: float,
        f: List[str],
        t: List[str],
        tests: List[str],
    ):
        return _update_thresholds_and_recalculate(
            results,
            float(alpha_val),
            float(wass_val),
            float(js_val),
            float(psi_val),
            f or [],
            t or [],
            tests or [],
        )

    for threshold_slider in [alpha, wasserstein_threshold, js_threshold, psi_threshold]:
        threshold_slider.change(
            _threshold_change_handler,
            inputs=[
                results_state,
                alpha,
                wasserstein_threshold,
                js_threshold,
                psi_threshold,
                feat_filter,
                type_filter,
                test_filter,
            ],
            outputs=[
                metrics_md,
                counts_table,
                results_table,
                download_csv,
                download_json,
                results_state,
            ],
        )

    selected_feature.change(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )
    bins.change(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )

    plot_type.change(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Gradio Drift Monitoring app")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "7860")))
    parser.add_argument("--host", type=str, default=os.environ.get("HOST", "0.0.0.0"))
    args = parser.parse_args()

    os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")

    demo.launch(
        server_name=args.host, server_port=args.port, inbrowser=False, show_error=True
    )


if __name__ == "__main__":
    main()
