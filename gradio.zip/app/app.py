"""Drift Monitoring Dashboard built with Reflex.

A professional, production-ready web application for monitoring ML model drift.
"""

import reflex as rx
from typing import Optional
import pandas as pd
from monitor.data import generate_synthetic_data
from monitor.drift import detect_drift, identify_column_types


class DriftState(rx.State):
    """Application state for drift monitoring."""

    # Data source
    data_source: str = "synthetic"

    # Synthetic data settings
    ref_n: int = 2000
    cur_n: int = 2000
    drift_strength: float = 0.2
    seed: int = 42

    # Thresholds
    alpha: float = 0.05
    wasserstein_threshold: float = 0.10
    js_threshold: float = 0.10
    euclidean_threshold: float = 0.10
    psi_threshold: float = 0.10
    bins: int = 40

    # Results
    total_features: int = 0
    drifted_features: int = 0
    drift_rate: float = 0.0
    stable_features: int = 0
    numerical_features: int = 0
    categorical_features: int = 0
    total_tests: int = 0
    avg_p_value: float = 0.0
    max_drift_statistic: float = 0.0
    critical_drift_features: int = 0
    results_df: Optional[pd.DataFrame] = None
    counts_df: Optional[pd.DataFrame] = None
    reference_df: Optional[pd.DataFrame] = None
    current_df: Optional[pd.DataFrame] = None

    # UI state
    is_loading: bool = False
    selected_tab: str = "overview"
    selected_feature: str = ""

    def compute_drift(self):
        """Generate data and compute drift detection."""
        self.is_loading = True
        yield

        # Generate synthetic data
        reference_df, current_df = generate_synthetic_data(
            reference_n=self.ref_n,
            current_n=self.cur_n,
            drift_strength=self.drift_strength,
            seed=self.seed,
        )

        self.reference_df = reference_df
        self.current_df = current_df

        # Detect drift
        results = detect_drift(
            reference_df,
            current_df,
            alpha=self.alpha,
            js_threshold=self.js_threshold,
            psi_threshold=self.psi_threshold,
            wasserstein_threshold=self.wasserstein_threshold,
            euclidean_threshold=self.euclidean_threshold,
            bins=self.bins,
        )

        self.results_df = results

        # Calculate metrics
        if not results.empty:
            self.total_features = len(results["feature"].unique())
            self.drifted_features = int(
                results.groupby("feature")["drift_detected"].any().sum()
            )
            self.drift_rate = (
                100.0 * self.drifted_features / max(self.total_features, 1)
            )
            self.stable_features = self.total_features - self.drifted_features
            
            # Feature type counts
            numeric_cols, categorical_cols = identify_column_types(reference_df)
            self.numerical_features = len(numeric_cols)
            self.categorical_features = len(categorical_cols)
            
            # Total tests run
            self.total_tests = len(results)
            
            # Average p-value (excluding NaN values)
            p_values = results["p_value"].dropna()
            self.avg_p_value = float(p_values.mean()) if len(p_values) > 0 else 0.0
            
            # Max drift statistic
            self.max_drift_statistic = float(results["statistic"].max())
            
            # Critical drift features (features with 2+ tests showing drift)
            drift_counts = results[results["drift_detected"]].groupby("feature").size()
            self.critical_drift_features = int((drift_counts >= 2).sum())

            # Calculate counts
            counts = (
                results.groupby(["test"])["drift_detected"]
                .agg(total="count", drifted="sum")
                .reset_index()
            )
            counts["rate"] = (counts["drifted"] / counts["total"]).round(3)
            self.counts_df = counts

            # Set first feature as selected
            if len(reference_df.columns) > 0:
                self.selected_feature = reference_df.columns[0]

        self.is_loading = False


def metric_card(value: str, label: str, color: str = "blue") -> rx.Component:
    """Create a metric card component."""
    color_map = {
        "blue": "blue",
        "red": "red",
        "green": "green",
    }

    return rx.box(
        rx.vstack(
            rx.heading(
                value,
                size="9",
                weight="bold",
            ),
            rx.text(
                label,
                size="2",
                color="gray",
                weight="medium",
                text_transform="uppercase",
                letter_spacing="0.05em",
            ),
            spacing="2",
            align="start",
        ),
        padding="1.5rem",
        background="white",
        border_radius="8px",
        border_left=f"4px solid var(--{color_map[color]}-9)",
        box_shadow="0 2px 4px rgba(0,0,0,0.1)",
    )


def header() -> rx.Component:
    """Dashboard header component."""
    return rx.box(
        rx.vstack(
            rx.heading(
                "🎯 Drift Monitoring Dashboard",
                size="8",
                color="white",
                weight="bold",
            ),
            rx.text(
                "Real-time model drift detection and monitoring for production ML systems",
                size="3",
                color="rgba(255,255,255,0.9)",
            ),
            spacing="2",
            align="start",
        ),
        padding="2rem",
        background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        border_radius="12px",
        margin_bottom="1.5rem",
        box_shadow="0 4px 6px rgba(0,0,0,0.1)",
    )


def control_panel() -> rx.Component:
    """Control panel for data generation and thresholds."""
    return rx.vstack(
        rx.heading("📊 Data Source", size="5", margin_bottom="1rem"),
        rx.text("Generate Synthetic Data", weight="bold", size="3"),
        rx.vstack(
            rx.hstack(
                rx.text("Reference rows:", size="2"),
                rx.input(
                    value=DriftState.ref_n,
                    on_change=DriftState.set_ref_n,
                    type="number",
                    width="100%",
                ),
                width="100%",
            ),
            rx.hstack(
                rx.text("Current rows:", size="2"),
                rx.input(
                    value=DriftState.cur_n,
                    on_change=DriftState.set_cur_n,
                    type="number",
                    width="100%",
                ),
                width="100%",
            ),
            rx.hstack(
                rx.text("Drift strength:", size="2"),
                rx.slider(
                    default_value=0.2,
                    min=0.0,
                    max=1.0,
                    step=0.05,
                    on_change=DriftState.set_drift_strength,
                    width="100%",
                ),
                width="100%",
            ),
            rx.hstack(
                rx.text("Seed:", size="2"),
                rx.input(
                    value=DriftState.seed,
                    on_change=DriftState.set_seed,
                    type="number",
                    width="100%",
                ),
                width="100%",
            ),
            spacing="3",
            width="100%",
        ),
        rx.button(
            rx.cond(
                DriftState.is_loading,
                rx.spinner(size="3"),
                rx.text("Generate Data + Compute"),
            ),
            on_click=DriftState.compute_drift,
            size="3",
            width="100%",
            margin_top="1rem",
        ),
        rx.divider(margin_y="1.5rem"),
        rx.heading("⚙️ Thresholds", size="5", margin_bottom="1rem"),
        rx.vstack(
            rx.vstack(
                rx.text("Alpha (KS/Chi-square)", size="2", weight="bold"),
                rx.slider(
                    value=DriftState.alpha,
                    min=0.001,
                    max=0.2,
                    step=0.001,
                    on_change=DriftState.set_alpha,
                    width="100%",
                ),
                rx.text(DriftState.alpha, size="1", color="gray"),
                spacing="1",
                width="100%",
            ),
            rx.vstack(
                rx.text("Wasserstein (numerical)", size="2", weight="bold"),
                rx.slider(
                    value=DriftState.wasserstein_threshold,
                    min=0.0,
                    max=1.0,
                    step=0.01,
                    on_change=DriftState.set_wasserstein_threshold,
                    width="100%",
                ),
                rx.text(DriftState.wasserstein_threshold, size="1", color="gray"),
                spacing="1",
                width="100%",
            ),
            rx.vstack(
                rx.text("Jensen-Shannon (categorical)", size="2", weight="bold"),
                rx.slider(
                    value=DriftState.js_threshold,
                    min=0.0,
                    max=1.0,
                    step=0.01,
                    on_change=DriftState.set_js_threshold,
                    width="100%",
                ),
                rx.text(DriftState.js_threshold, size="1", color="gray"),
                spacing="1",
                width="100%",
            ),
            rx.vstack(
                rx.text("Euclidean (categorical)", size="2", weight="bold"),
                rx.slider(
                    value=DriftState.euclidean_threshold,
                    min=0.0,
                    max=1.0,
                    step=0.01,
                    on_change=DriftState.set_euclidean_threshold,
                    width="100%",
                ),
                rx.text(DriftState.euclidean_threshold, size="1", color="gray"),
                spacing="1",
                width="100%",
            ),
            rx.vstack(
                rx.text("PSI threshold", size="2", weight="bold"),
                rx.slider(
                    value=DriftState.psi_threshold,
                    min=0.0,
                    max=1.0,
                    step=0.01,
                    on_change=DriftState.set_psi_threshold,
                    width="100%",
                ),
                rx.text(DriftState.psi_threshold, size="1", color="gray"),
                spacing="1",
                width="100%",
            ),
            spacing="4",
            width="100%",
        ),
        padding="1.5rem",
        background="#f7fafc",
        border_radius="8px",
        border="1px solid #e2e8f0",
        width="100%",
    )


def overview_tab() -> rx.Component:
    """Overview tab with key metrics."""
    return rx.vstack(
        rx.heading("Overview", size="6", margin_bottom="1rem"),
        
        # Primary metrics row
        rx.grid(
            metric_card(
                DriftState.total_features.to_string(),
                "Total Features",
                "blue",
            ),
            metric_card(
                DriftState.drifted_features.to_string(),
                "Features with Drift",
                rx.cond(
                    DriftState.drift_rate > 20,
                    "red",
                    rx.cond(DriftState.drift_rate == 0, "green", "blue"),
                ),
            ),
            metric_card(
                rx.text(DriftState.drift_rate.to_string(), "%"),
                "Drift Rate",
                rx.cond(DriftState.drift_rate > 20, "red", "green"),
            ),
            metric_card(
                DriftState.stable_features.to_string(),
                "Stable Features",
                "green",
            ),
            columns="4",
            spacing="4",
            width="100%",
        ),
        
        # Feature breakdown row
        rx.heading("Feature Breakdown", size="6", margin_top="2rem", margin_bottom="1rem"),
        rx.grid(
            metric_card(
                DriftState.numerical_features.to_string(),
                "Numerical Features",
                "blue",
            ),
            metric_card(
                DriftState.categorical_features.to_string(),
                "Categorical Features",
                "blue",
            ),
            metric_card(
                DriftState.critical_drift_features.to_string(),
                "Critical Drift (2+ tests)",
                rx.cond(DriftState.critical_drift_features > 0, "red", "green"),
            ),
            columns="3",
            spacing="4",
            width="100%",
        ),
        
        # Statistical insights row
        rx.heading("Statistical Insights", size="6", margin_top="2rem", margin_bottom="1rem"),
        rx.grid(
            metric_card(
                DriftState.total_tests.to_string(),
                "Total Tests Run",
                "blue",
            ),
            metric_card(
                rx.text(DriftState.avg_p_value.to_string()),
                "Avg P-Value (significance tests)",
                rx.cond(
                    DriftState.avg_p_value < 0.05,
                    "red",
                    rx.cond(DriftState.avg_p_value < 0.1, "blue", "green"),
                ),
            ),
            metric_card(
                rx.text(DriftState.max_drift_statistic.to_string()),
                "Max Drift Statistic",
                rx.cond(DriftState.max_drift_statistic > 1.0, "red", "blue"),
            ),
            columns="3",
            spacing="4",
            width="100%",
        ),
        
        # Data volume row
        rx.heading("Data Volume", size="6", margin_top="2rem", margin_bottom="1rem"),
        rx.grid(
            metric_card(
                DriftState.ref_n.to_string(),
                "Reference Samples",
                "blue",
            ),
            metric_card(
                DriftState.cur_n.to_string(),
                "Current Samples",
                "blue",
            ),
            metric_card(
                rx.text(
                    rx.cond(
                        DriftState.total_features > 0,
                        ((DriftState.ref_n + DriftState.cur_n) * DriftState.total_features).to_string(),
                        "0"
                    )
                ),
                "Total Data Points",
                "blue",
            ),
            columns="3",
            spacing="4",
            width="100%",
        ),
        
        rx.heading(
            "Test Statistics by Method", size="6", margin_top="2rem", margin_bottom="1rem"
        ),
        rx.cond(
            DriftState.counts_df.to_string() != "None",
            rx.data_table(
                data=DriftState.counts_df,
                pagination=True,
                search=True,
                sort=True,
            ),
            rx.text(
                "No data yet. Click 'Generate Data + Compute' to start.", color="gray"
            ),
        ),
        rx.heading("Configuration", size="6", margin_top="2rem", margin_bottom="1rem"),
        rx.box(
            rx.grid(
                rx.vstack(
                    rx.text("Alpha (KS/χ²)", weight="bold", size="2"),
                    rx.text(DriftState.alpha.to_string(), size="3"),
                    spacing="1",
                ),
                rx.vstack(
                    rx.text("Wasserstein", weight="bold", size="2"),
                    rx.text(DriftState.wasserstein_threshold.to_string(), size="3"),
                    spacing="1",
                ),
                rx.vstack(
                    rx.text("Jensen-Shannon", weight="bold", size="2"),
                    rx.text(DriftState.js_threshold.to_string(), size="3"),
                    spacing="1",
                ),
                rx.vstack(
                    rx.text("Euclidean", weight="bold", size="2"),
                    rx.text(DriftState.euclidean_threshold.to_string(), size="3"),
                    spacing="1",
                ),
                rx.vstack(
                    rx.text("PSI", weight="bold", size="2"),
                    rx.text(DriftState.psi_threshold.to_string(), size="3"),
                    spacing="1",
                ),
                rx.vstack(
                    rx.text("Bins", weight="bold", size="2"),
                    rx.text(DriftState.bins.to_string(), size="3"),
                    spacing="1",
                ),
                columns="3",
                spacing="4",
            ),
            padding="1rem",
            background="#f7fafc",
            border_radius="8px",
        ),
        spacing="4",
        width="100%",
    )


def results_tab() -> rx.Component:
    """Results tab with detailed drift detection results."""
    return rx.vstack(
        rx.heading("Drift Detection Results", size="6", margin_bottom="1rem"),
        rx.cond(
            DriftState.results_df.to_string() != "None",
            rx.data_table(
                data=DriftState.results_df,
                pagination=True,
                search=True,
                sort=True,
            ),
            rx.text(
                "No results yet. Click 'Generate Data + Compute' to start.",
                color="gray",
            ),
        ),
        spacing="4",
        width="100%",
    )


def index() -> rx.Component:
    """Main application page."""
    return rx.container(
        header(),
        rx.grid(
            # Left column - Control panel
            rx.box(
                control_panel(),
                width="100%",
            ),
            # Right column - Tabs
            rx.box(
                rx.tabs.root(
                    rx.tabs.list(
                        rx.tabs.trigger("📊 Overview", value="overview"),
                        rx.tabs.trigger("📋 Results", value="results"),
                    ),
                    rx.tabs.content(
                        overview_tab(),
                        value="overview",
                    ),
                    rx.tabs.content(
                        results_tab(),
                        value="results",
                    ),
                    default_value="overview",
                    width="100%",
                ),
                width="100%",
            ),
            columns="1fr 3fr",
            spacing="6",
            width="100%",
        ),
        size="4",
        padding="2rem",
    )


# Create the Reflex app
app = rx.App(
    theme=rx.theme(
        appearance="light",
        has_background=True,
        radius="large",
        accent_color="purple",
    )
)

app.add_page(index, title="Drift Monitoring Dashboard")
