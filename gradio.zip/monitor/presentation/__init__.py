"""
Presentation Layer - UI Components and Formatting

This layer handles all user interface concerns including:
- Visualization (plots and charts)
- UI component builders
- Data formatting for display
- Dashboard layouts
"""

from .dashboard_components import (
    DashboardComponentBuilder,
    MetricCardBuilder,
)
from .viz import (
    plot_categorical_difference,
    plot_categorical_distributions,
    plot_chi_square_contributions,
    plot_euclidean_categorical,
    plot_jensen_shannon_categorical,
    plot_jensen_shannon_divergence,
    plot_numeric_binned_probs,
    plot_numeric_distributions,
    plot_numeric_ecdf,
    plot_wasserstein_distance,
)

__all__ = [
    # Visualizations
    "plot_categorical_distributions",
    "plot_numeric_distributions",
    "plot_numeric_ecdf",
    "plot_chi_square_contributions",
    "plot_wasserstein_distance",
    "plot_jensen_shannon_categorical",
    "plot_jensen_shannon_divergence",
    "plot_euclidean_categorical",
    "plot_numeric_binned_probs",
    "plot_categorical_difference",
    # UI Components
    "DashboardComponentBuilder",
    "MetricCardBuilder",
]
