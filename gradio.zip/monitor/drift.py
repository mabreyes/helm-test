from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, ks_2samp, wasserstein_distance, entropy
from scipy.spatial.distance import jensenshannon


@dataclass
class DriftResult:
    feature: str
    feature_type: str  # "numerical" or "categorical"
    test: str
    statistic: float
    p_value: float
    effect_size: float | None
    threshold: float | None
    drift_detected: bool
    n_ref: int
    n_cur: int


def identify_column_types(df: pd.DataFrame) -> Tuple[List[str], List[str]]:
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.columns.difference(numeric_cols).tolist()
    return numeric_cols, categorical_cols


_EPSILON = 1e-12


def _normalize_counts_to_probabilities(counts: np.ndarray) -> np.ndarray:
    total = float(np.sum(counts))
    if total <= 0.0:
        return np.zeros_like(counts, dtype=float)
    probs = counts.astype(float) / total
    # Smooth and renormalize to avoid zeros which can cause infs in divergences
    probs = probs + _EPSILON
    probs = probs / probs.sum()
    return probs


def _jensen_shannon_from_probs(p: np.ndarray, q: np.ndarray) -> float:
    p = np.asarray(p, dtype=float)
    q = np.asarray(q, dtype=float)
    # jensenshannon returns the distance (sqrt of JSD)
    return float(jensenshannon(p, q))


def _psi_from_probs(p: np.ndarray, q: np.ndarray) -> float:
    p = np.asarray(p, dtype=float)
    q = np.asarray(q, dtype=float)
    # PSI equals symmetric KL (Jeffreys divergence): KL(p||q) + KL(q||p)
    return float(entropy(p, q) + entropy(q, p))


def _chi_square_test(ref: pd.Series, cur: pd.Series, alpha: float) -> DriftResult:
    """
    Chi-square test for categorical features (significance test).
    Best for large banks: use for significance, pair with JS for effect size.
    Watch-out: needs expected counts ≥5; over-flags with huge N.
    """
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts().reindex(categories, fill_value=0)
    cur_counts = cur.value_counts().reindex(categories, fill_value=0)
    contingency = np.vstack([ref_counts.values, cur_counts.values])

    chi2, p_value, dof, _ = chi2_contingency(contingency, correction=False)

    n_total = contingency.sum()
    r, k = contingency.shape
    denom = n_total * (min(r - 1, k - 1))
    cramer_v = float(np.sqrt(chi2 / denom)) if denom > 0 else 0.0

    return DriftResult(
        feature="",
        feature_type="categorical",
        test="chi-square",
        statistic=float(chi2),
        p_value=float(p_value),
        effect_size=cramer_v,
        threshold=float(alpha),
        drift_detected=bool(p_value < alpha),
        n_ref=int(ref_counts.sum()),
        n_cur=int(cur_counts.sum()),
    )


def _ks_test(ref: pd.Series, cur: pd.Series, alpha: float) -> DriftResult:
    """
    KS test for numerical features (significance test).
    Best for large banks: standard significance test, pair with Wasserstein for effect size.
    """
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 or len(cur_clean) == 0:
        return DriftResult(
            feature="",
            feature_type="numerical",
            test="ks",
            statistic=float("nan"),
            p_value=float("nan"),
            effect_size=float("nan"),
            threshold=float(alpha),
            drift_detected=False,
            n_ref=int(len(ref_clean)),
            n_cur=int(len(cur_clean)),
        )

    stat, p_value = ks_2samp(
        ref_clean.values, cur_clean.values, alternative="two-sided", mode="auto"
    )
    w_dist = wasserstein_distance(ref_clean.values, cur_clean.values)

    return DriftResult(
        feature="",
        feature_type="numerical",
        test="ks",
        statistic=float(stat),
        p_value=float(p_value),
        effect_size=float(w_dist),
        threshold=float(alpha),
        drift_detected=bool(p_value < alpha),
        n_ref=int(len(ref_clean)),
        n_cur=int(len(cur_clean)),
    )


def _wasserstein_test(
    ref: pd.Series, cur: pd.Series, threshold: float = 0.1
) -> DriftResult:
    """
    Wasserstein (Earth-Mover's) distance for numerical features (effect size / alert KPI).
    Best for large banks: top alert KPI for continuous data, measures how far distributions moved.
    Bin-free, works on raw continuous data via CDFs.
    """
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 or len(cur_clean) == 0:
        return DriftResult(
            feature="",
            feature_type="numerical",
            test="wasserstein",
            statistic=float("nan"),
            p_value=float("nan"),
            effect_size=float("nan"),
            threshold=float(threshold),
            drift_detected=False,
            n_ref=int(len(ref_clean)),
            n_cur=int(len(cur_clean)),
        )

    w_dist = wasserstein_distance(ref_clean.values, cur_clean.values)

    return DriftResult(
        feature="",
        feature_type="numerical",
        test="wasserstein",
        statistic=float(w_dist),
        p_value=float("nan"),
        effect_size=float(w_dist),
        threshold=float(threshold),
        drift_detected=bool(w_dist >= threshold),
        n_ref=int(len(ref_clean)),
        n_cur=int(len(cur_clean)),
    )


def _psi_numeric(
    ref: pd.Series, cur: pd.Series, bins: int = 40, threshold: float = 0.1
) -> DriftResult:
    """
    PSI (Population Stability Index) for numerical features with fixed bins.
    Best for large banks: common reporting KPI, industry-familiar thresholds.
    Keep bins fixed across time periods for consistent monitoring.
    """
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 or len(cur_clean) == 0:
        return DriftResult(
            feature="",
            feature_type="numerical",
            test="psi",
            statistic=float("nan"),
            p_value=float("nan"),
            effect_size=float("nan"),
            threshold=float(threshold),
            drift_detected=False,
            n_ref=int(len(ref_clean)),
            n_cur=int(len(cur_clean)),
        )

    combined = np.concatenate([ref_clean.values, cur_clean.values])
    bin_edges = np.histogram_bin_edges(combined, bins=bins)
    ref_counts, _ = np.histogram(ref_clean.values, bins=bin_edges)
    cur_counts, _ = np.histogram(cur_clean.values, bins=bin_edges)

    p = _normalize_counts_to_probabilities(ref_counts)
    q = _normalize_counts_to_probabilities(cur_counts)

    psi_value = _psi_from_probs(p, q)

    return DriftResult(
        feature="",
        feature_type="numerical",
        test="psi",
        statistic=float(psi_value),
        p_value=float("nan"),
        effect_size=float("nan"),
        threshold=float(threshold),
        drift_detected=bool(psi_value >= threshold),
        n_ref=int(len(ref_clean)),
        n_cur=int(len(cur_clean)),
    )


def _js_categorical(
    ref: pd.Series, cur: pd.Series, threshold: float = 0.1
) -> DriftResult:
    """
    Jensen-Shannon distance for categorical features (alert KPI).
    Best for large banks: top alert KPI, symmetric bounded distance on category probabilities.
    Pair with Chi-square for p-value. Smooth rare categories to avoid issues.
    """
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts().reindex(categories, fill_value=0)
    cur_counts = cur.value_counts().reindex(categories, fill_value=0)

    p = _normalize_counts_to_probabilities(ref_counts.values)
    q = _normalize_counts_to_probabilities(cur_counts.values)

    js_distance = _jensen_shannon_from_probs(p, q)

    return DriftResult(
        feature="",
        feature_type="categorical",
        test="jensen-shannon",
        statistic=float(js_distance),
        p_value=float("nan"),
        effect_size=float("nan"),
        threshold=float(threshold),
        drift_detected=bool(js_distance >= threshold),
        n_ref=int(ref_counts.sum()),
        n_cur=int(cur_counts.sum()),
    )


def _psi_categorical(
    ref: pd.Series, cur: pd.Series, threshold: float = 0.1
) -> DriftResult:
    """
    PSI (Population Stability Index) for categorical features.
    Best for large banks: common reporting KPI, industry-familiar thresholds.
    Keep category definitions fixed across time periods.
    """
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts().reindex(categories, fill_value=0)
    cur_counts = cur.value_counts().reindex(categories, fill_value=0)

    p = _normalize_counts_to_probabilities(ref_counts.values)
    q = _normalize_counts_to_probabilities(cur_counts.values)

    psi_value = _psi_from_probs(p, q)

    return DriftResult(
        feature="",
        feature_type="categorical",
        test="psi",
        statistic=float(psi_value),
        p_value=float("nan"),
        effect_size=float("nan"),
        threshold=float(threshold),
        drift_detected=bool(psi_value >= threshold),
        n_ref=int(ref_counts.sum()),
        n_cur=int(cur_counts.sum()),
    )


def _euclidean_categorical(
    ref: pd.Series, cur: pd.Series, threshold: float = 0.1
) -> DriftResult:
    """
    Euclidean distance (L2 norm) on category probability vectors.
    Fast, lightweight secondary signal for categorical drift.
    0 = no difference, higher values = more drift.
    
    Best for large banks: secondary/cheap signal for quick feature ranking.
    Watch-out: noisy on rare categories; not a statistical test.
    """
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_probs = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    cur_probs = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)

    # Compute L2 (Euclidean) distance on probability vectors
    euclidean_dist = float(np.sqrt(np.sum((ref_probs.values - cur_probs.values) ** 2)))

    return DriftResult(
        feature="",
        feature_type="categorical",
        test="euclidean",
        statistic=float(euclidean_dist),
        p_value=float("nan"),
        effect_size=float("nan"),
        threshold=float(threshold),
        drift_detected=bool(euclidean_dist >= threshold),
        n_ref=int(len(ref)),
        n_cur=int(len(cur)),
    )


def detect_drift(
    reference_df: pd.DataFrame,
    current_df: pd.DataFrame,
    alpha: float = 0.05,
    *,
    js_threshold: float = 0.1,
    psi_threshold: float = 0.1,
    wasserstein_threshold: float = 0.1,
    euclidean_threshold: float = 0.1,
    bins: int = 40,
) -> pd.DataFrame:
    """
    Run drift detection tests optimized for large banks / financial institutions.
    
    Numerical (continuous): KS test + Wasserstein + PSI
    Categorical: Chi-square + Jensen-Shannon + Euclidean (L2) + PSI

    Parameters
    ----------
    alpha : float
        Significance level for KS and Chi-square tests (compared to p-value).
        Default: 0.05
    js_threshold : float
        Threshold on Jensen-Shannon distance to flag drift (categorical only).
        Default: 0.1
    psi_threshold : float
        Threshold on PSI (symmetric KL) to flag drift (both numerical and categorical).
        Default: 0.1
    wasserstein_threshold : float
        Threshold on Wasserstein distance to flag drift (numerical only).
        Default: 0.1
    euclidean_threshold : float
        Threshold on Euclidean (L2) distance to flag drift (categorical only).
        Default: 0.1
    bins : int
        Number of histogram bins used for numerical PSI.
        Default: 40

    Returns
    -------
    pd.DataFrame
        One row per (feature, test) combination with columns:
        feature, feature_type, test, statistic, p_value, effect_size, 
        threshold, drift_detected, n_ref, n_cur
    """
    if set(reference_df.columns) != set(current_df.columns):
        raise ValueError("Reference and current dataframes must have the same columns")

    numeric_cols, categorical_cols = identify_column_types(reference_df)

    results: List[DriftResult] = []
    
    # Numerical: KS (significance) + Wasserstein (alert KPI) + PSI (reporting)
    for col in numeric_cols:
        res_ks = _ks_test(reference_df[col], current_df[col], alpha)
        res_ks.feature = col
        results.append(res_ks)

        res_wass = _wasserstein_test(
            reference_df[col], current_df[col], threshold=wasserstein_threshold
        )
        res_wass.feature = col
        results.append(res_wass)

        res_psi = _psi_numeric(
            reference_df[col], current_df[col], bins=bins, threshold=psi_threshold
        )
        res_psi.feature = col
        results.append(res_psi)

    # Categorical: Chi-square (significance) + JS (alert KPI) + Euclidean (fast signal) + PSI (reporting)
    for col in categorical_cols:
        res_chi = _chi_square_test(reference_df[col], current_df[col], alpha)
        res_chi.feature = col
        results.append(res_chi)

        res_js = _js_categorical(
            reference_df[col], current_df[col], threshold=js_threshold
        )
        res_js.feature = col
        results.append(res_js)

        res_eucl = _euclidean_categorical(
            reference_df[col], current_df[col], threshold=euclidean_threshold
        )
        res_eucl.feature = col
        results.append(res_eucl)

        res_psi = _psi_categorical(
            reference_df[col], current_df[col], threshold=psi_threshold
        )
        res_psi.feature = col
        results.append(res_psi)

    out = pd.DataFrame([r.__dict__ for r in results])
    # Order columns for readability
    cols = [
        "feature",
        "feature_type",
        "test",
        "statistic",
        "p_value",
        "effect_size",
        "threshold",
        "drift_detected",
        "n_ref",
        "n_cur",
    ]
    return out[cols]
