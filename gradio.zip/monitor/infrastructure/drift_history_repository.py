"""
Drift History Repository - Infrastructure Layer

Single Responsibility: Persist and query drift history in PostgreSQL.
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime

import pandas as pd
from sqlalchemy import create_engine, text

from ..domain.history import DriftHistoryRepository, DriftSnapshotRow, DriftSnapshotRun


class PostgresDriftHistoryRepository(DriftHistoryRepository):
    """
    PostgreSQL implementation of DriftHistoryRepository.

    Single Responsibility: Provide DB persistence for drift history.
    """

    def __init__(self, connection_url: str):
        self._url = connection_url

    def _engine(self):
        return create_engine(self._url)

    def ensure_schema(self) -> None:
        ddl_runs = """
        CREATE TABLE IF NOT EXISTS drift_runs (
            run_id UUID PRIMARY KEY,
            ts TIMESTAMPTZ NOT NULL,
            ref_samples INT NOT NULL,
            cur_samples INT NOT NULL,
            total_features INT NOT NULL,
            total_tests INT NOT NULL
        );
        """
        ddl_rows = """
        CREATE TABLE IF NOT EXISTS drift_history (
            run_id UUID REFERENCES drift_runs(run_id) ON DELETE CASCADE,
            ts TIMESTAMPTZ NOT NULL,
            feature TEXT NOT NULL,
            feature_type TEXT NOT NULL,
            test TEXT NOT NULL,
            statistic DOUBLE PRECISION,
            p_value DOUBLE PRECISION,
            effect_size DOUBLE PRECISION,
            threshold DOUBLE PRECISION,
            drift_detected BOOLEAN NOT NULL,
            n_ref INT,
            n_cur INT,
            PRIMARY KEY (run_id, feature, test)
        );
        CREATE INDEX IF NOT EXISTS idx_drift_history_ftt ON drift_history(feature, test, ts);
        CREATE INDEX IF NOT EXISTS idx_drift_history_ts ON drift_history(ts);
        """
        with self._engine().begin() as conn:
            conn.execute(text(ddl_runs))
            for stmt in ddl_rows.split(";"):
                if stmt.strip():
                    conn.execute(text(stmt))

    def save_run(self, run: DriftSnapshotRun, rows: Iterable[DriftSnapshotRow]) -> None:
        df_rows = pd.DataFrame(
            [
                {
                    "run_id": r.run_id,
                    "ts": r.timestamp,
                    "feature": r.feature,
                    "feature_type": r.feature_type,
                    "test": r.test,
                    "statistic": r.statistic,
                    "p_value": r.p_value,
                    "effect_size": r.effect_size,
                    "threshold": r.threshold,
                    "drift_detected": r.drift_detected,
                    "n_ref": r.n_ref,
                    "n_cur": r.n_cur,
                }
                for r in rows
            ]
        )

        with self._engine().begin() as conn:
            # upsert run
            conn.execute(
                text(
                    """
                    INSERT INTO drift_runs(run_id, ts, ref_samples, cur_samples, total_features, total_tests)
                    VALUES (:run_id, :ts, :ref_samples, :cur_samples, :total_features, :total_tests)
                    ON CONFLICT (run_id) DO NOTHING
                    """
                ),
                {
                    "run_id": run.run_id,
                    "ts": run.timestamp,
                    "ref_samples": run.ref_samples,
                    "cur_samples": run.cur_samples,
                    "total_features": run.total_features,
                    "total_tests": run.total_tests,
                },
            )

        # bulk insert rows
        df_rows.to_sql(
            "drift_history", self._engine(), if_exists="append", index=False, method="multi"
        )

    def query_trend(
        self,
        features: list[str],
        tests: list[str],
        interval: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> pd.DataFrame:
        if interval not in {"minute", "hour", "day", "week", "month", "year"}:
            raise ValueError("Invalid interval. Use minute/hour/day/week/month/year")

        where = ["feature = ANY(:features)", "test = ANY(:tests)"]
        params: dict = {"features": features, "tests": tests}
        if start is not None:
            where.append("ts >= :start")
            params["start"] = start
        if end is not None:
            where.append("ts <= :end")
            params["end"] = end

        where_sql = " AND ".join(where)
        sql = f"""
            SELECT
                date_trunc(:interval, ts) AS bucket,
                feature,
                test,
                AVG(CASE WHEN drift_detected THEN 1.0 ELSE 0.0 END) AS drift_rate,
                AVG(statistic) AS avg_statistic,
                AVG(p_value) AS avg_p_value,
                AVG(effect_size) AS avg_effect_size,
                AVG(threshold) AS avg_threshold,
                COUNT(*) AS n
            FROM drift_history
            WHERE {where_sql}
            GROUP BY bucket, feature, test
            ORDER BY bucket
        """
        with self._engine().begin() as conn:
            df = pd.read_sql(
                text(sql),
                con=conn,
                params={"interval": interval, **params},
                parse_dates=["bucket"],
            )
        return df

    def list_catalog(
        self, start: datetime | None = None, end: datetime | None = None
    ) -> tuple[list[str], list[str], dict[str, str]]:
        """
        Return distinct features, tests, and a feature->type mapping available in history
        within an optional time window.
        """
        where = []
        params: dict = {}
        if start is not None:
            where.append("ts >= :start")
            params["start"] = start
        if end is not None:
            where.append("ts <= :end")
            params["end"] = end
        where_sql = f"WHERE {' AND '.join(where)}" if where else ""
        sql_features = (
            f"SELECT DISTINCT feature, feature_type FROM drift_history {where_sql} ORDER BY feature"
        )
        sql_tests = f"SELECT DISTINCT test FROM drift_history {where_sql} ORDER BY test"
        with self._engine().begin() as conn:
            df_feat = pd.read_sql(text(sql_features), con=conn)
            df_tests = pd.read_sql(text(sql_tests), con=conn)
        features = df_feat["feature"].astype(str).tolist() if not df_feat.empty else []
        tests = df_tests["test"].astype(str).tolist() if not df_tests.empty else []
        fmap = (
            {row["feature"]: str(row["feature_type"]) for _, row in df_feat.iterrows()}
            if not df_feat.empty
            else {}
        )
        return features, tests, fmap


def get_history_repo_from_env() -> PostgresDriftHistoryRepository | None:
    """
    Helper to build a history repository from env var DRIFT_HISTORY_URL.

    Example: postgresql://user:pass@host:5432/db
    """
    import os

    url = os.environ.get("DRIFT_HISTORY_URL")
    if not url:
        return None
    repo = PostgresDriftHistoryRepository(url)
    try:
        repo.ensure_schema()
    except Exception:
        # Fail silently; app can continue without history
        return None
    return repo
