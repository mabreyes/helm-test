"""
Report Writer - Persistence Layer

Single Responsibility: Handle all report writing and persistence operations.
"""

from __future__ import annotations

import json
import os

import pandas as pd

from ..domain.models import DriftAnalysisResult


class ReportWriter:
    """
    Write drift analysis results to various formats.

    Single Responsibility: Persist analysis results to storage.
    Isolates the domain from file I/O concerns.
    """

    @staticmethod
    def save_report(
        analysis_result: DriftAnalysisResult,
        outdir: str,
    ) -> tuple[str, str]:
        """
        Save drift analysis report to CSV and JSON files.

        Args:
            analysis_result: The drift analysis result to save
            outdir: Output directory

        Returns:
            Tuple of (csv_path, json_path)
        """
        os.makedirs(outdir, exist_ok=True)
        csv_path = os.path.join(outdir, "drift_report.csv")
        json_path = os.path.join(outdir, "drift_report.json")

        # Convert results to DataFrame
        results_df = pd.DataFrame([r.to_dict() for r in analysis_result.results])

        # Save CSV
        results_df.to_csv(csv_path, index=False)

        # Save JSON
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(results_df.to_dict(orient="records"), f, indent=2)

        return csv_path, json_path

    @staticmethod
    def save_results_dataframe(
        results_df: pd.DataFrame,
        outdir: str,
    ) -> tuple[str, str]:
        """
        Save results DataFrame directly (for backward compatibility).

        Args:
            results_df: DataFrame with drift results
            outdir: Output directory

        Returns:
            Tuple of (csv_path, json_path)
        """
        os.makedirs(outdir, exist_ok=True)
        csv_path = os.path.join(outdir, "drift_report.csv")
        json_path = os.path.join(outdir, "drift_report.json")

        results_df.to_csv(csv_path, index=False)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(results_df.to_dict(orient="records"), f, indent=2)

        return csv_path, json_path
