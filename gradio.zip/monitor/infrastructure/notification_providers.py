"""
Notification Infrastructure Services

Single Responsibility: Handle platform-specific notification delivery mechanisms.
This module contains infrastructure services for sending notifications across different platforms.
"""

from abc import ABC, abstractmethod
import platform
import subprocess
from typing import Protocol

from ..domain.models import NotificationMessage
from ..domain.value_objects import NotificationConfig


class NotificationProvider(Protocol):
    """
    Protocol defining the interface for notification providers.
    
    Single Responsibility: Define the contract for notification delivery.
    """

    def send_notification(
        self, notification: NotificationMessage, config: NotificationConfig
    ) -> bool:
        """
        Send a notification using the provider's mechanism.

        Args:
            notification: The notification to send
            config: Notification configuration

        Returns:
            True if successful, False otherwise
        """
        ...


class SystemNotificationProvider:
    """
    Infrastructure Service: Send system notifications using platform-specific methods.

    Single Responsibility: Handle the technical details of sending system notifications.
    """

    def __init__(self):
        self._system = platform.system()

    def send_notification(
        self, notification: NotificationMessage, config: NotificationConfig
    ) -> bool:
        """
        Send a system notification using platform-specific methods.

        Single Responsibility: Route to appropriate platform-specific implementation.

        Args:
            notification: The notification to send
            config: Notification configuration

        Returns:
            True if successful, False otherwise
        """
        try:
            if self._system == "Darwin":  # macOS
                return self._send_macos_notification(notification, config)
            elif self._system == "Linux":
                return self._send_linux_notification(notification, config)
            elif self._system == "Windows":
                return self._send_windows_notification(notification, config)
            else:
                print(f"Unsupported platform: {self._system}")
                return False
        except Exception as e:
            print(f"Failed to send notification: {e}")
            return False

    def _send_macos_notification(
        self, notification: NotificationMessage, config: NotificationConfig
    ) -> bool:
        """
        Send notification on macOS using osascript.

        Single Responsibility: Handle macOS-specific notification delivery.
        """
        # Escape quotes in message
        title = notification.title.replace('"', r"\"")
        message = notification.message.replace('"', r"\"")

        sound_arg = 'sound name "Ping"' if config.sound_enabled else ""

        script = f"""
        display notification "{message}" with title "{title}" {sound_arg}
        """

        result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)

        return result.returncode == 0

    def _send_linux_notification(
        self, notification: NotificationMessage, config: NotificationConfig
    ) -> bool:
        """
        Send notification on Linux using notify-send.

        Single Responsibility: Handle Linux-specific notification delivery.
        """
        try:
            # Set urgency based on severity
            urgency_map = {
                "info": "normal",
                "warning": "normal",
                "critical": "critical"
            }
            urgency = urgency_map.get(notification.severity.value, "normal")

            subprocess.run(
                ["notify-send", "-u", urgency, notification.title, notification.message],
                check=True
            )
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def _send_windows_notification(
        self, notification: NotificationMessage, config: NotificationConfig
    ) -> bool:
        """
        Send notification on Windows using PowerShell.

        Single Responsibility: Handle Windows-specific notification delivery.
        """
        try:
            # Use Windows Toast notifications
            ps_script = f"""
            [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
            [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null

            $template = @"
            <toast>
                <visual>
                    <binding template="ToastText02">
                        <text id="1">{notification.title}</text>
                        <text id="2">{notification.message}</text>
                    </binding>
                </visual>
            </toast>
"@

            $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
            $xml.LoadXml($template)
            $toast = New-Object Windows.UI.Notifications.ToastNotification $xml
            [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Model Monitoring").Show($toast)
            """

            result = subprocess.run(
                ["powershell", "-Command", ps_script], capture_output=True, text=True
            )

            return result.returncode == 0
        except Exception:
            return False


class ConsoleNotificationProvider:
    """
    Infrastructure Service: Send notifications to console (for testing/development).

    Single Responsibility: Provide a simple console-based notification mechanism.
    """

    def send_notification(
        self, notification: NotificationMessage, config: NotificationConfig
    ) -> bool:
        """
        Send notification to console.

        Single Responsibility: Output notification to console with formatting.
        """
        severity_symbols = {
            "info": "ℹ️",
            "warning": "⚠️",
            "critical": "🚨"
        }
        
        symbol = severity_symbols.get(notification.severity.value, "ℹ️")
        
        print(f"\n{symbol} {notification.title}")
        print(f"   {notification.message}")
        print(f"   Time: {notification.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        
        return True


class CompositeNotificationProvider:
    """
    Infrastructure Service: Send notifications through multiple providers.

    Single Responsibility: Coordinate multiple notification delivery mechanisms.
    """

    def __init__(self, providers: list[NotificationProvider]):
        """
        Initialize with a list of notification providers.

        Args:
            providers: List of notification providers to use
        """
        self._providers = providers

    def send_notification(
        self, notification: NotificationMessage, config: NotificationConfig
    ) -> bool:
        """
        Send notification through all providers.

        Single Responsibility: Attempt delivery through all providers and return success if any succeed.
        """
        success = False
        for provider in self._providers:
            try:
                if provider.send_notification(notification, config):
                    success = True
            except Exception as e:
                print(f"Provider {type(provider).__name__} failed: {e}")
        
        return success


# Default provider instance
_default_provider: NotificationProvider | None = None


def get_default_notification_provider() -> NotificationProvider:
    """
    Get the default notification provider for the current platform.
    
    Single Responsibility: Provide a sensible default notification provider.
    """
    global _default_provider
    if _default_provider is None:
        _default_provider = SystemNotificationProvider()
    return _default_provider


def set_default_notification_provider(provider: NotificationProvider) -> None:
    """Set the default notification provider."""
    global _default_provider
    _default_provider = provider
