"""
Infrastructure Layer - External Concerns

This layer handles external systems, I/O operations, and persistence.
It depends on the domain layer but provides concrete implementations.
"""

from .data_repository import DataRepository, SyntheticDataGenerator
from .drift_history_repository import (
    PostgresDriftHistoryRepository,
    get_history_repo_from_env,
)
from .postgres_repository import PostgresConnectionConfig, PostgresRepository
from .report_writer import ReportWriter

__all__ = [
    "DataRepository",
    "SyntheticDataGenerator",
    "ReportWriter",
    "PostgresRepository",
    "PostgresConnectionConfig",
    "PostgresDriftHistoryRepository",
    "get_history_repo_from_env",
]
