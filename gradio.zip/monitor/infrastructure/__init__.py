"""
Infrastructure Layer - External Concerns

This layer handles external systems, I/O operations, and persistence.
It depends on the domain layer but provides concrete implementations.
"""

from .data_repository import DataRepository, SyntheticDataGenerator
from .postgres_repository import PostgresConnectionConfig, PostgresRepository
from .report_writer import ReportWriter

__all__ = [
    "DataRepository",
    "SyntheticDataGenerator",
    "ReportWriter",
    "PostgresRepository",
    "PostgresConnectionConfig",
]
