"""
Data Repository - Data Access Layer

Single Responsibility: Handle all data loading, saving, and generation operations.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd


class DataRepository:
    """
    Repository pattern for data access.

    Single Responsibility: Abstract data storage and retrieval.
    This class isolates the domain logic from data source details.
    """

    @staticmethod
    def save_datasets(
        reference_df: pd.DataFrame,
        current_df: pd.DataFrame,
        outdir: str,
    ) -> tuple[str, str]:
        """
        Save reference and current datasets to CSV files.

        Args:
            reference_df: Reference dataset
            current_df: Current dataset
            outdir: Output directory

        Returns:
            Tuple of (reference_path, current_path)
        """
        os.makedirs(outdir, exist_ok=True)
        ref_path = os.path.join(outdir, "reference.csv")
        cur_path = os.path.join(outdir, "current.csv")
        reference_df.to_csv(ref_path, index=False)
        current_df.to_csv(cur_path, index=False)
        return ref_path, cur_path

    @staticmethod
    def load_dataset(file_path: str) -> pd.DataFrame:
        """
        Load a dataset from a CSV file.

        Args:
            file_path: Path to CSV file

        Returns:
            Loaded DataFrame
        """
        return pd.read_csv(file_path)


class SyntheticDataGenerator:
    """
    Generate synthetic datasets for testing and demonstration.

    Single Responsibility: Create realistic synthetic data with configurable drift.
    """

    def __init__(self, seed: int = 42):
        """
        Initialize the generator.

        Args:
            seed: Random seed for reproducibility
        """
        self._rng = np.random.default_rng(seed)

    def generate(
        self,
        reference_n: int = 2000,
        current_n: int = 2000,
        drift_strength: float = 0.2,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Generate synthetic reference and current datasets.

        Single Responsibility: Create paired datasets with controlled drift.

        Args:
            reference_n: Number of rows in reference dataset
            current_n: Number of rows in current dataset
            drift_strength: Magnitude of drift (0.0 = no drift, higher = more drift)

        Returns:
            Tuple of (reference_df, current_df)
        """
        # Generate numerical features
        age_ref, age_cur = self._generate_age_feature(reference_n, current_n, drift_strength)
        income_ref, income_cur = self._generate_income_feature(
            reference_n, current_n, drift_strength
        )
        score_ref, score_cur = self._generate_score_feature(reference_n, current_n, drift_strength)

        # Generate categorical features
        segment_ref, segment_cur, seg_categories = self._generate_segment_feature(
            reference_n, current_n, drift_strength
        )
        plan_ref, plan_cur, plan_categories = self._generate_plan_feature(
            reference_n, current_n, drift_strength
        )

        # Assemble DataFrames
        reference = pd.DataFrame(
            {
                "age": age_ref,
                "income": income_ref,
                "score": score_ref,
                "segment": pd.Categorical(segment_ref, categories=seg_categories),
                "plan": pd.Categorical(plan_ref, categories=plan_categories),
            }
        )

        current = pd.DataFrame(
            {
                "age": age_cur,
                "income": income_cur,
                "score": score_cur,
                "segment": pd.Categorical(segment_cur, categories=seg_categories),
                "plan": pd.Categorical(plan_cur, categories=plan_categories),
            }
        )

        return reference, current

    def _generate_age_feature(
        self, n_ref: int, n_cur: int, drift: float
    ) -> tuple[np.ndarray, np.ndarray]:
        """Generate age feature with drift."""
        age_ref = self._rng.normal(loc=40.0, scale=10.0, size=n_ref)
        age_ref = np.clip(age_ref, 18, 90)

        age_cur = self._rng.normal(
            loc=40.0 + 5.0 * drift,
            scale=10.0 + 2.0 * drift,
            size=n_cur,
        )
        age_cur = np.clip(age_cur, 18, 90)

        return age_ref, age_cur

    def _generate_income_feature(
        self, n_ref: int, n_cur: int, drift: float
    ) -> tuple[np.ndarray, np.ndarray]:
        """Generate income feature with drift."""
        income_ref = self._rng.lognormal(mean=10.5, sigma=0.50, size=n_ref)
        income_ref = np.clip(income_ref, 0, np.quantile(income_ref, 0.995))

        income_cur = self._rng.lognormal(
            mean=10.5 + 0.20 * drift,
            sigma=0.50 + 0.10 * drift,
            size=n_cur,
        )
        income_cur = np.clip(income_cur, 0, np.quantile(income_cur, 0.995))

        return income_ref, income_cur

    def _generate_score_feature(
        self, n_ref: int, n_cur: int, drift: float
    ) -> tuple[np.ndarray, np.ndarray]:
        """Generate score feature with drift."""
        alpha_ref = 2.0
        beta_ref = 5.0
        alpha_cur = max(0.5, alpha_ref - 0.5 * drift)
        beta_cur = max(0.5, beta_ref + 0.5 * drift)

        score_ref = self._rng.beta(alpha_ref, beta_ref, size=n_ref) * 100.0
        score_cur = self._rng.beta(alpha_cur, beta_cur, size=n_cur) * 100.0

        return score_ref, score_cur

    def _generate_segment_feature(
        self, n_ref: int, n_cur: int, drift: float
    ) -> tuple[np.ndarray, np.ndarray, list]:
        """Generate segment feature with drift."""
        categories = ["A", "B", "C"]
        ref_p = [0.60, 0.30, 0.10]

        # Move probability mass from A to C
        a_drop = min(ref_p[0] - 0.05, 0.20 * drift)
        cur_p = self._normalize_probabilities([ref_p[0] - a_drop, ref_p[1], ref_p[2] + a_drop])

        segment_ref = self._rng.choice(categories, size=n_ref, p=ref_p)
        segment_cur = self._rng.choice(categories, size=n_cur, p=cur_p)

        return segment_ref, segment_cur, categories

    def _generate_plan_feature(
        self, n_ref: int, n_cur: int, drift: float
    ) -> tuple[np.ndarray, np.ndarray, list]:
        """Generate plan feature with drift."""
        categories = ["Basic", "Plus", "Pro"]
        ref_p = [0.50, 0.35, 0.15]

        # Move probability mass from Basic to Plus and Pro
        basic_drop = min(ref_p[0] - 0.10, 0.20 * drift)
        cur_p = self._normalize_probabilities(
            [
                ref_p[0] - basic_drop,
                ref_p[1] + basic_drop * 0.6,
                ref_p[2] + basic_drop * 0.4,
            ]
        )

        plan_ref = self._rng.choice(categories, size=n_ref, p=ref_p)
        plan_cur = self._rng.choice(categories, size=n_cur, p=cur_p)

        return plan_ref, plan_cur, categories

    @staticmethod
    def _normalize_probabilities(probs: list[float]) -> list[float]:
        """Normalize probabilities to sum to 1."""
        total = sum(probs)
        if total <= 0:
            raise ValueError("Sum of probabilities must be positive")
        return [p / total for p in probs]
