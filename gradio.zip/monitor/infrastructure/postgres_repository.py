"""
PostgreSQL Repository - Infrastructure Layer

Single Responsibility: Handle all PostgreSQL database operations.
"""

from __future__ import annotations

import pandas as pd
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import Engine


class PostgresConnectionConfig:
    """
    Value object for PostgreSQL connection configuration.

    Single Responsibility: Encapsulate connection parameters.
    """

    def __init__(
        self,
        host: str,
        port: int,
        database: str,
        user: str,
        password: str,
    ):
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password

    def get_connection_string(self) -> str:
        """Build PostgreSQL connection string."""
        return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"


class PostgresRepository:
    """
    Repository for PostgreSQL operations.

    Single Responsibility: Provide database access methods.
    """

    def __init__(self, config: PostgresConnectionConfig):
        """
        Initialize with database configuration.

        Args:
            config: PostgreSQL connection configuration
        """
        self._config = config
        self._engine: Engine | None = None

    def test_connection(self) -> tuple[str, list[str]]:
        """
        Test database connection and list tables.

        Returns:
            Tuple of (status_message, table_names)
        """
        try:
            engine = create_engine(self._config.get_connection_string())

            # Test connection
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))

            # Get tables
            inspector = inspect(engine)
            tables = inspector.get_table_names()

            if not tables:
                return "Connected successfully, but no tables found.", []

            return f"Connected successfully. Found {len(tables)} table(s).", tables
        except Exception as e:
            return f"Connection failed: {str(e)}", []

    def fetch_table(self, table_name: str) -> pd.DataFrame:
        """
        Fetch all data from a PostgreSQL table.

        Args:
            table_name: Name of table to fetch

        Returns:
            DataFrame with table data

        Raises:
            Exception: If table fetch fails
        """
        engine = create_engine(self._config.get_connection_string())
        query = f'SELECT * FROM "{table_name}"'
        df = pd.read_sql(query, engine)

        if df.empty:
            raise ValueError(f"Table '{table_name}' is empty.")

        return df

    def load_dataframe(
        self,
        df: pd.DataFrame,
        table_name: str,
        if_exists: str = "replace",
    ) -> None:
        """
        Load a DataFrame into PostgreSQL table.

        Args:
            df: DataFrame to load
            table_name: Target table name
            if_exists: What to do if table exists ('replace', 'append', 'fail')
        """
        engine = create_engine(self._config.get_connection_string())
        df.to_sql(
            table_name,
            engine,
            if_exists=if_exists,
            index=False,
            method="multi",
        )

    def drop_table_if_exists(self, table_name: str) -> None:
        """
        Drop a table if it exists.

        Args:
            table_name: Name of table to drop
        """
        engine = create_engine(self._config.get_connection_string())
        with engine.connect() as conn:
            conn.execute(text(f'DROP TABLE IF EXISTS "{table_name}" CASCADE'))
            conn.commit()

    def get_table_count(self, table_name: str) -> int:
        """
        Get row count for a table.

        Args:
            table_name: Table name

        Returns:
            Number of rows in table
        """
        engine = create_engine(self._config.get_connection_string())
        with engine.connect() as conn:
            result = conn.execute(text(f'SELECT COUNT(*) FROM "{table_name}"'))
            return result.scalar()
