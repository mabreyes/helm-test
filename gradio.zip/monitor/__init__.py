"""
Drift Monitoring - ML Model Drift Detection Library

A professional drift monitoring system built with Domain-Driven Design (DDD)
and Single Responsibility Principle (SRP).

Architecture Layers:
-------------------
- domain: Core business logic and models
- services: Statistical algorithms and domain services
- infrastructure: I/O, persistence, external systems
- application: Use case orchestration
- presentation: UI components and visualizations

Quick Start:
-----------
>>> from monitor.application import DriftAnalyzer
>>> from monitor.infrastructure import SyntheticDataGenerator
>>>
>>> # Generate test data
>>> generator = SyntheticDataGenerator(seed=42)
>>> ref_df, cur_df = generator.generate(drift_strength=0.2)
>>>
>>> # Analyze drift
>>> analyzer = DriftAnalyzer()
>>> result = analyzer.analyze_drift(ref_df, cur_df)
>>>
>>> # Access results
>>> print(f"Drift rate: {result.get_drift_rate():.1%}")
>>> print(f"Drifted features: {result.get_drifted_features()}")
"""

__version__ = "2.0.0"

# Domain Layer
# Utilities
from . import notifications

# Application Layer
from .application import DriftAnalyzer
from .domain import (
    DriftAnalysisResult,
    DriftResult,
    DriftThresholds,
    FeatureType,
    StatisticalTestConfig,
)

# Infrastructure Layer
from .infrastructure import (
    DataRepository,
    PostgresConnectionConfig,
    PostgresRepository,
    ReportWriter,
    SyntheticDataGenerator,
)

# Presentation Layer
from .presentation import (
    # UI Components
    DashboardComponentBuilder,
    MetricCardBuilder,
    # Visualizations
    plot_categorical_distributions,
    plot_chi_square_contributions,
    plot_euclidean_categorical,
    plot_jensen_shannon_categorical,
    plot_numeric_distributions,
    plot_numeric_ecdf,
    plot_wasserstein_distance,
)

# Services Layer
from .services import (
    CategoricalDriftTests,
    DriftDetectionService,
    NumericalDriftTests,
)

__all__ = [
    # Version
    "__version__",
    # Domain
    "DriftResult",
    "DriftAnalysisResult",
    "DriftThresholds",
    "StatisticalTestConfig",
    "FeatureType",
    # Services
    "NumericalDriftTests",
    "CategoricalDriftTests",
    "DriftDetectionService",
    # Infrastructure
    "DataRepository",
    "SyntheticDataGenerator",
    "ReportWriter",
    "PostgresRepository",
    "PostgresConnectionConfig",
    # Application
    "DriftAnalyzer",
    # Presentation - Visualizations
    "plot_categorical_distributions",
    "plot_numeric_distributions",
    "plot_numeric_ecdf",
    "plot_chi_square_contributions",
    "plot_wasserstein_distance",
    "plot_jensen_shannon_categorical",
    "plot_euclidean_categorical",
    # Presentation - UI
    "DashboardComponentBuilder",
    "MetricCardBuilder",
    # Utilities
    "notifications",
]
