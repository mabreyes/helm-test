"""
Drift Monitoring - ML Model Drift Detection Library

A professional drift monitoring system built with Domain-Driven Design (DDD)
and Single Responsibility Principle (SRP).

Architecture Layers:
-------------------
- domain: Core business logic and models
- services: Statistical algorithms and domain services
- infrastructure: I/O, persistence, external systems
- application: Use case orchestration
- presentation: UI components and visualizations

Quick Start:
-----------
>>> from monitor.application import DriftAnalyzer
>>> from monitor.infrastructure import SyntheticDataGenerator
>>>
>>> # Generate test data
>>> generator = SyntheticDataGenerator(seed=42)
>>> ref_df, cur_df = generator.generate(drift_strength=0.2)
>>>
>>> # Analyze drift
>>> analyzer = DriftAnalyzer()
>>> result = analyzer.analyze_drift(ref_df, cur_df)
>>>
>>> # Access results
>>> print(f"Drift rate: {result.get_drift_rate():.1%}")
>>> print(f"Drifted features: {result.get_drifted_features()}")
"""

__version__ = "2.0.0"

# Domain Layer

# Application Layer
from .application import DriftAnalyzer

# Domain Layer
from .domain import (
    DriftAnalysisResult,
    DriftResult,
    DriftThresholds,
    FeatureType,
    StatisticalTestConfig,
)

# Infrastructure Layer
from .infrastructure import (
    DataRepository,
    PostgresConnectionConfig,
    PostgresRepository,
    ReportWriter,
    SyntheticDataGenerator,
)

# Presentation Layer
# Note: UI components and visualizations moved to dashboard module
# Services Layer
from .services import (
    CategoricalDriftTests,
    DriftDetectionService,
    NumericalDriftTests,
)

__all__ = [
    # Version
    "__version__",
    # Domain
    "DriftResult",
    "DriftAnalysisResult",
    "DriftThresholds",
    "StatisticalTestConfig",
    "FeatureType",
    # Services
    "NumericalDriftTests",
    "CategoricalDriftTests",
    "DriftDetectionService",
    # Infrastructure
    "DataRepository",
    "SyntheticDataGenerator",
    "ReportWriter",
    "PostgresRepository",
    "PostgresConnectionConfig",
    # Application
    "DriftAnalyzer",
    # Note: UI components and visualizations moved to dashboard module
]
