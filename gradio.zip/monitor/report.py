from __future__ import annotations

import json
import os
from typing import Tuple

import pandas as pd


def save_report(results: pd.DataFrame, outdir: str) -> Tuple[str, str]:
    os.makedirs(outdir, exist_ok=True)
    csv_path = os.path.join(outdir, "drift_report.csv")
    json_path = os.path.join(outdir, "drift_report.json")

    results.to_csv(csv_path, index=False)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results.to_dict(orient="records"), f, indent=2)

    return csv_path, json_path
