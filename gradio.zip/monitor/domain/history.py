"""
Domain models and interfaces for drift history tracking.

Single Responsibility: Represent drift history concepts and contracts.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:  # pragma: no cover
    import pandas as pd


@dataclass(frozen=True)
class DriftSnapshotRun:
    """
    Immutable value object representing a drift analysis run.

    Single Responsibility: Identify and describe a single analysis execution.
    """

    run_id: str
    timestamp: datetime
    ref_samples: int
    cur_samples: int
    total_features: int
    total_tests: int


@dataclass(frozen=True)
class DriftSnapshotRow:
    """
    Immutable value object representing a single feature/test drift row within a run.

    Single Responsibility: Capture one feature/test measurement outcome.
    """

    run_id: str
    timestamp: datetime
    feature: str
    feature_type: str
    test: str
    statistic: float | None
    p_value: float | None
    effect_size: float | None
    threshold: float | None
    drift_detected: bool
    n_ref: int
    n_cur: int


class DriftHistoryRepository(Protocol):
    """
    Repository port for storing and querying drift history.

    Single Responsibility: Define persistence operations for drift history.
    """

    def ensure_schema(self) -> None:
        """Ensure required tables and indexes exist."""
        ...

    def save_run(self, run: DriftSnapshotRun, rows: Iterable[DriftSnapshotRow]) -> None:
        """Persist a run and its rows atomically."""
        ...

    def query_trend(
        self,
        features: list[str],
        tests: list[str],
        interval: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> pd.DataFrame:  # type: ignore[name-defined]
        """
        Query drift trend aggregated by time bucket.

        Returns DataFrame columns: [bucket, feature, test, drift_rate, avg_statistic, n]
        """
        ...
