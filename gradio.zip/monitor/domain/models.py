"""
Domain Models - Core business entities

Single Responsibility: Represent core business concepts and their invariants.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class FeatureType(str, Enum):
    """Value object representing feature data types."""

    NUMERICAL = "numerical"
    CATEGORICAL = "categorical"


@dataclass(frozen=True)
class DriftResult:
    """
    Immutable value object representing a single drift test result.

    Single Responsibility: Encapsulate all information about one drift test.
    Domain Concept: A drift test measures whether a feature has drifted between datasets.
    """

    feature: str
    feature_type: str
    test: str
    statistic: float
    p_value: float
    effect_size: float | None
    threshold: float | None
    drift_detected: bool
    n_ref: int
    n_cur: int

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "feature": self.feature,
            "feature_type": self.feature_type,
            "test": self.test,
            "statistic": self.statistic,
            "p_value": self.p_value,
            "effect_size": self.effect_size,
            "threshold": self.threshold,
            "drift_detected": self.drift_detected,
            "n_ref": self.n_ref,
            "n_cur": self.n_cur,
        }


@dataclass
class DriftAnalysisResult:
    """
    Aggregate root representing the complete drift analysis.

    Single Responsibility: Aggregate all drift test results and provide summary metrics.
    Domain Concept: The complete analysis of drift across all features.
    """

    results: list[DriftResult]
    total_features: int
    total_tests: int

    def get_drifted_features(self) -> list[str]:
        """Get unique features that showed drift in any test."""
        drifted = set()
        for result in self.results:
            if result.drift_detected:
                drifted.add(result.feature)
        return sorted(drifted)

    def get_drift_rate(self) -> float:
        """Calculate the proportion of features with drift."""
        if self.total_features == 0:
            return 0.0
        drifted_count = len(self.get_drifted_features())
        return drifted_count / self.total_features

    def get_critical_drifts(self, min_tests_failed: int = 2) -> list[str]:
        """
        Get features with critical drift (failed multiple tests).

        Args:
            min_tests_failed: Minimum number of failed tests to be considered critical
        """
        feature_failures = {}
        for result in self.results:
            if result.drift_detected:
                feature_failures[result.feature] = feature_failures.get(result.feature, 0) + 1

        critical = [
            feature for feature, count in feature_failures.items() if count >= min_tests_failed
        ]
        return sorted(critical)

    def get_stable_features(self) -> list[str]:
        """Get features that showed no drift in any test."""
        drifted = set(self.get_drifted_features())
        all_features = {result.feature for result in self.results}
        stable = all_features - drifted
        return sorted(stable)


class NotificationSeverity(str, Enum):
    """Enumeration of notification severity levels."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass(frozen=True)
class NotificationMessage:
    """
    Immutable value object representing a notification message.

    Single Responsibility: Encapsulate all information about a notification.
    Domain Concept: A notification is a message sent to alert users about system events.
    """

    title: str
    message: str
    timestamp: datetime = field(default_factory=datetime.now)
    severity: NotificationSeverity = NotificationSeverity.INFO

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "title": self.title,
            "message": self.message,
            "timestamp": self.timestamp.isoformat(),
            "severity": self.severity.value,
        }


@dataclass(frozen=True)
class NotificationHistory:
    """
    Immutable aggregate representing notification history.

    Single Responsibility: Track and provide access to notification history.
    Domain Concept: The history of notifications sent by the system.
    """

    notifications: tuple[NotificationMessage, ...] = field(default_factory=tuple)
    max_size: int = 100

    def add_notification(self, notification: NotificationMessage) -> NotificationHistory:
        """
        Add a notification to history and return new history instance.

        Single Responsibility: Add notification while maintaining immutability.
        """
        notifications_list = list(self.notifications)
        notifications_list.append(notification)

        # Maintain max_size limit
        if len(notifications_list) > self.max_size:
            notifications_list = notifications_list[-self.max_size :]

        return NotificationHistory(notifications=tuple(notifications_list), max_size=self.max_size)

    def get_recent(self, n: int = 10) -> list[NotificationMessage]:
        """Get the n most recent notifications."""
        return list(self.notifications[-n:])

    def clear(self) -> NotificationHistory:
        """Return empty notification history."""
        return NotificationHistory(max_size=self.max_size)

    def __len__(self) -> int:
        """Return number of notifications in history."""
        return len(self.notifications)
