"""
Value Objects - Immutable domain concepts

Single Responsibility: Encapsulate configuration and thresholds as domain concepts.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class DriftThresholds:
    """
    Immutable value object for drift detection thresholds.

    Single Responsibility: Encapsulate all threshold values for drift tests.
    """

    alpha: float = 0.05  # Significance level for statistical tests
    js_threshold: float = 0.1  # Jensen-Shannon distance threshold
    psi_threshold: float = 0.1  # PSI threshold
    wasserstein_threshold: float = 0.1  # Wasserstein distance threshold
    euclidean_threshold: float = 0.1  # Euclidean distance threshold
    bins: int = 40  # Number of bins for PSI computation

    def validate(self) -> None:
        """Validate threshold values."""
        if not 0 < self.alpha < 1:
            raise ValueError(f"alpha must be between 0 and 1, got {self.alpha}")
        if self.bins < 1:
            raise ValueError(f"bins must be positive, got {self.bins}")
        if any(
            t < 0
            for t in [
                self.js_threshold,
                self.psi_threshold,
                self.wasserstein_threshold,
                self.euclidean_threshold,
            ]
        ):
            raise ValueError("Thresholds must be non-negative")


@dataclass(frozen=True)
class StatisticalTestConfig:
    """
    Configuration for statistical test behavior.

    Single Responsibility: Configure how statistical tests are executed.
    """

    thresholds: DriftThresholds

    def __post_init__(self):
        self.thresholds.validate()


class FeatureType:
    """
    Value object to classify feature types.

    Single Responsibility: Determine and classify feature data types.
    """

    @staticmethod
    def identify_column_types(df: pd.DataFrame) -> tuple[list[str], list[str]]:
        """
        Identify numerical and categorical columns in a DataFrame.

        Args:
            df: DataFrame to analyze

        Returns:
            Tuple of (numerical_columns, categorical_columns)
        """
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        categorical_cols = df.columns.difference(numeric_cols).tolist()
        return numeric_cols, categorical_cols
