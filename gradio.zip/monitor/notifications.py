"""
Notification Module - Single Responsibility: Handle all notification operations.

This module is responsible for:
- Sending system notifications
- Managing notification preferences
- Formatting notification messages
- Tracking notification history
"""

import platform
import subprocess
from datetime import datetime
from typing import Optional, Dict, List
from dataclasses import dataclass, field


@dataclass
class NotificationConfig:
    """Configuration for notification behavior."""
    enabled: bool = True
    show_on_drift: bool = True
    show_summary: bool = True
    sound_enabled: bool = True
    min_drift_threshold: int = 1  # Minimum number of drifted features to notify


@dataclass
class NotificationMessage:
    """Represents a notification message."""
    title: str
    message: str
    timestamp: datetime = field(default_factory=datetime.now)
    severity: str = "info"  # info, warning, critical
    

class NotificationHistory:
    """Tracks notification history."""
    
    def __init__(self, max_size: int = 100):
        self.max_size = max_size
        self._history: List[NotificationMessage] = []
    
    def add(self, notification: NotificationMessage) -> None:
        """Add a notification to history."""
        self._history.append(notification)
        if len(self._history) > self.max_size:
            self._history.pop(0)
    
    def get_recent(self, n: int = 10) -> List[NotificationMessage]:
        """Get the n most recent notifications."""
        return self._history[-n:]
    
    def clear(self) -> None:
        """Clear notification history."""
        self._history.clear()


class NotificationService:
    """
    Main notification service following Single Responsibility Principle.
    Handles all notification operations for the monitoring system.
    """
    
    def __init__(self, config: Optional[NotificationConfig] = None):
        self.config = config or NotificationConfig()
        self.history = NotificationHistory()
        self._system = platform.system()
    
    def notify_drift_detected(
        self,
        total_features: int,
        drifted_features: int,
        critical_drift: int,
        drift_rate: float
    ) -> bool:
        """
        Send a system notification about drift detection.
        
        Args:
            total_features: Total number of features analyzed
            drifted_features: Number of features with drift
            critical_drift: Number of features with critical drift
            drift_rate: Overall drift rate (0-1)
        
        Returns:
            True if notification was sent successfully, False otherwise
        """
        if not self.config.enabled or not self.config.show_on_drift:
            return False
        
        if drifted_features < self.config.min_drift_threshold:
            return False
        
        # Determine severity
        if critical_drift > 0:
            severity = "critical"
            title = "Critical Drift Detected"
        elif drift_rate > 0.5:
            severity = "warning"
            title = "Significant Drift Detected"
        else:
            severity = "info"
            title = "Drift Detected"
        
        # Format message
        message = self._format_drift_message(
            total_features, drifted_features, critical_drift, drift_rate
        )
        
        # Create notification object
        notification = NotificationMessage(
            title=title,
            message=message,
            severity=severity
        )
        
        # Send system notification
        success = self._send_system_notification(notification)
        
        # Add to history
        if success:
            self.history.add(notification)
        
        return success
    
    def notify_analysis_complete(
        self,
        total_features: int,
        total_tests: int,
        duration_seconds: float
    ) -> bool:
        """
        Send a notification when analysis is complete.
        
        Args:
            total_features: Number of features analyzed
            total_tests: Number of tests performed
            duration_seconds: Time taken for analysis
        
        Returns:
            True if notification was sent successfully
        """
        if not self.config.enabled or not self.config.show_summary:
            return False
        
        title = "Analysis Complete"
        message = (
            f"Analyzed {total_features} features with {total_tests} tests\n"
            f"Completed in {duration_seconds:.1f} seconds"
        )
        
        notification = NotificationMessage(
            title=title,
            message=message,
            severity="info"
        )
        
        success = self._send_system_notification(notification)
        
        if success:
            self.history.add(notification)
        
        return success
    
    def _format_drift_message(
        self,
        total_features: int,
        drifted_features: int,
        critical_drift: int,
        drift_rate: float
    ) -> str:
        """Format the drift notification message."""
        lines = [
            f"{drifted_features} of {total_features} features drifted ({drift_rate:.1%})"
        ]
        
        if critical_drift > 0:
            lines.append(f"{critical_drift} features with critical drift")
        
        return "\n".join(lines)
    
    def _send_system_notification(self, notification: NotificationMessage) -> bool:
        """
        Send a system notification using platform-specific methods.
        
        Args:
            notification: The notification to send
        
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._system == "Darwin":  # macOS
                return self._send_macos_notification(notification)
            elif self._system == "Linux":
                return self._send_linux_notification(notification)
            elif self._system == "Windows":
                return self._send_windows_notification(notification)
            else:
                print(f"Unsupported platform: {self._system}")
                return False
        except Exception as e:
            print(f"Failed to send notification: {e}")
            return False
    
    def _send_macos_notification(self, notification: NotificationMessage) -> bool:
        """Send notification on macOS using osascript."""
        # Escape quotes in message
        title = notification.title.replace('"', r'\"')
        message = notification.message.replace('"', r'\"')
        
        sound_arg = 'sound name "Ping"' if self.config.sound_enabled else ""
        
        script = f'''
        display notification "{message}" with title "{title}" {sound_arg}
        '''
        
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True
        )
        
        return result.returncode == 0
    
    def _send_linux_notification(self, notification: NotificationMessage) -> bool:
        """Send notification on Linux using notify-send."""
        try:
            # Set urgency based on severity
            urgency_map = {
                "info": "normal",
                "warning": "normal",
                "critical": "critical"
            }
            urgency = urgency_map.get(notification.severity, "normal")
            
            subprocess.run(
                [
                    "notify-send",
                    "-u", urgency,
                    notification.title,
                    notification.message
                ],
                check=True
            )
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
    
    def _send_windows_notification(self, notification: NotificationMessage) -> bool:
        """Send notification on Windows using PowerShell."""
        try:
            # Use BurntToast or Windows Toast notifications
            ps_script = f'''
            [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
            [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
            
            $template = @"
            <toast>
                <visual>
                    <binding template="ToastText02">
                        <text id="1">{notification.title}</text>
                        <text id="2">{notification.message}</text>
                    </binding>
                </visual>
            </toast>
"@
            
            $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
            $xml.LoadXml($template)
            $toast = New-Object Windows.UI.Notifications.ToastNotification $xml
            [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Model Monitoring").Show($toast)
            '''
            
            result = subprocess.run(
                ["powershell", "-Command", ps_script],
                capture_output=True,
                text=True
            )
            
            return result.returncode == 0
        except Exception:
            return False
    
    def update_config(self, **kwargs) -> None:
        """Update notification configuration."""
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
    
    def test_notification(self) -> bool:
        """Send a test notification to verify the system is working."""
        notification = NotificationMessage(
            title="Test Notification",
            message="Notification system is working correctly!",
            severity="info"
        )
        return self._send_system_notification(notification)


# Global notification service instance
_notification_service: Optional[NotificationService] = None


def get_notification_service() -> NotificationService:
    """Get or create the global notification service instance."""
    global _notification_service
    if _notification_service is None:
        _notification_service = NotificationService()
    return _notification_service


def initialize_notification_service(config: Optional[NotificationConfig] = None) -> NotificationService:
    """Initialize the notification service with custom configuration."""
    global _notification_service
    _notification_service = NotificationService(config)
    return _notification_service

