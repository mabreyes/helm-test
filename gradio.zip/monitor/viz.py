from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from scipy.stats import wasserstein_distance
from scipy.spatial.distance import jensenshannon

APPLE_FONT_STACK = "-apple-system, BlinkMacSystemFont, 'SF Pro Text','SF Pro Display','Helvetica Neue',Helvetica,Arial,'Apple Color Emoji','Segoe UI',Roboto,'Noto Sans','Liberation Sans',sans-serif"


def plot_numeric_distributions(
    ref: pd.Series,
    cur: pd.Series,
    bins: int = 40,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    fig = go.Figure()
    if len(ref_clean) > 0:
        fig.add_trace(
            go.Histogram(
                x=ref_clean,
                nbinsx=bins,
                name=ref_name,
                opacity=0.6,
                histnorm="probability",
            )
        )
    if len(cur_clean) > 0:
        fig.add_trace(
            go.Histogram(
                x=cur_clean,
                nbinsx=bins,
                name=cur_name,
                opacity=0.6,
                histnorm="probability",
            )
        )

    fig.update_layout(
        title="Probability Distribution (Histogram)<br><sub>Compare probability densities between reference and current datasets</sub>",
        barmode="overlay",
        xaxis_title="Value",
        yaxis_title="Probability",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_categorical_distributions(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    cur_counts = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)

    fig = go.Figure()
    fig.add_trace(go.Bar(x=categories, y=ref_counts.values, name=ref_name, opacity=0.8))
    fig.add_trace(go.Bar(x=categories, y=cur_counts.values, name=cur_name, opacity=0.8))

    fig.update_layout(
        title="Category Proportions<br><sub>Compare category distributions between reference and current datasets</sub>",
        barmode="group",
        xaxis_title="Category",
        yaxis_title="Proportion",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_numeric_binned_probs(
    ref: pd.Series,
    cur: pd.Series,
    bins: int = 40,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 and len(cur_clean) == 0:
        return go.Figure()

    combined = np.concatenate(
        [
            ref_clean.values if len(ref_clean) else np.array([], dtype=float),
            cur_clean.values if len(cur_clean) else np.array([], dtype=float),
        ]
    )
    # Fallback single edge if everything empty
    if combined.size == 0:
        combined = np.array([0.0, 1.0])

    bin_edges = np.histogram_bin_edges(combined, bins=bins)
    ref_counts, _ = np.histogram(
        ref_clean.values if len(ref_clean) else np.array([], dtype=float),
        bins=bin_edges,
    )
    cur_counts, _ = np.histogram(
        cur_clean.values if len(cur_clean) else np.array([], dtype=float),
        bins=bin_edges,
    )

    def _normalize(counts: np.ndarray) -> np.ndarray:
        total = float(np.sum(counts))
        return (
            (counts.astype(float) / total)
            if total > 0
            else np.zeros_like(counts, dtype=float)
        )

    p = _normalize(ref_counts)
    q = _normalize(cur_counts)
    centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0
    abs_diff = np.abs(q - p)

    fig = go.Figure()
    fig.add_trace(go.Bar(x=centers, y=p, name=ref_name, opacity=0.7))
    fig.add_trace(go.Bar(x=centers, y=q, name=cur_name, opacity=0.7))
    fig.add_trace(
        go.Scatter(
            x=centers,
            y=abs_diff,
            mode="lines",
            name="|Δ| (current - reference)",
            line=dict(dash="dot", width=2),
        )
    )

    fig.update_layout(
        title="Binned Probabilities (PSI Computation)<br><sub>Fixed bins used for PSI calculation - shows per-bin probability differences</sub>",
        barmode="overlay",
        xaxis_title="Value",
        yaxis_title="Probability",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_categorical_difference(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_probs = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    cur_probs = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    diff = (cur_probs - ref_probs).values
    colors = ["seagreen" if d >= 0 else "crimson" for d in diff]

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=categories, y=diff, marker_color=colors, name=f"Δ {cur_name}-{ref_name}"
        )
    )

    fig.update_layout(
        title="Category Probability Shift<br><sub>Green bars show proportion increase, red bars show decrease from reference to current</sub>",
        xaxis_title="Category",
        yaxis_title="Probability difference",
        legend_title="Legend",
        margin=dict(l=10, r=10, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_chi_square_contributions(
    ref: pd.Series,
    cur: pd.Series,
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts().reindex(categories, fill_value=0)
    cur_counts = cur.value_counts().reindex(categories, fill_value=0)

    contingency = np.vstack([ref_counts.values, cur_counts.values]).astype(float)
    n_total = contingency.sum()
    if n_total <= 0:
        return go.Figure()
    row_sums = contingency.sum(axis=1, keepdims=True)
    col_sums = contingency.sum(axis=0, keepdims=True)
    expected = row_sums @ (col_sums / n_total)
    with np.errstate(divide="ignore", invalid="ignore"):
        contrib = (contingency - expected) ** 2 / np.where(expected > 0, expected, 1.0)
    per_category_contrib = contrib.sum(axis=0)

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=categories,
            y=per_category_contrib,
            name="Chi-square contribution",
            marker_color="steelblue",
        )
    )
    fig.update_layout(
        title="Chi-Square Test Contributions by Category<br><sub>Shows which categories contribute most to the Chi-square statistic</sub>",
        xaxis_title="Category",
        yaxis_title="Contribution",
        legend_title="Legend",
        margin=dict(l=10, r=10, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_numeric_ecdf(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    fig = go.Figure()

    if len(ref_clean) > 0:
        x_ref = ref_clean.sort_values().values
        y_ref = (pd.Series(range(1, len(x_ref) + 1)) / len(x_ref)).values
        fig.add_trace(
            go.Scatter(
                x=x_ref,
                y=y_ref,
                mode="lines",
                name=ref_name,
                line=dict(width=2),
                line_shape="hv",
            )
        )

    if len(cur_clean) > 0:
        x_cur = cur_clean.sort_values().values
        y_cur = (pd.Series(range(1, len(x_cur) + 1)) / len(x_cur)).values
        fig.add_trace(
            go.Scatter(
                x=x_cur,
                y=y_cur,
                mode="lines",
                name=cur_name,
                line=dict(width=2),
                line_shape="hv",
            )
        )

    fig.update_layout(
        title="Empirical Cumulative Distribution Function (ECDF)<br><sub>Used by KS test - maximum vertical distance measures distribution difference</sub>",
        xaxis_title="Value",
        yaxis_title="ECDF",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )

    return fig


def plot_wasserstein_distance(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    """
    Visualize Wasserstein distance (Earth-Mover's distance) between two distributions.
    Shows CDFs and highlights the area representing the distance.
    """
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 or len(cur_clean) == 0:
        return go.Figure()

    # Calculate Wasserstein distance
    w_dist = wasserstein_distance(ref_clean.values, cur_clean.values)

    # Create ECDFs
    x_ref = np.sort(ref_clean.values)
    y_ref = np.arange(1, len(x_ref) + 1) / len(x_ref)
    
    x_cur = np.sort(cur_clean.values)
    y_cur = np.arange(1, len(x_cur) + 1) / len(x_cur)

    # Create merged x-axis for area fill
    x_merged = np.sort(np.concatenate([x_ref, x_cur]))
    y_ref_interp = np.interp(x_merged, x_ref, y_ref, left=0, right=1)
    y_cur_interp = np.interp(x_merged, x_cur, y_cur, left=0, right=1)

    fig = go.Figure()

    # Add shaded area showing the "work" needed to transform one distribution to another
    fig.add_trace(
        go.Scatter(
            x=np.concatenate([x_merged, x_merged[::-1]]),
            y=np.concatenate([y_ref_interp, y_cur_interp[::-1]]),
            fill='toself',
            fillcolor='rgba(135, 206, 250, 0.3)',
            line=dict(width=0),
            name='Wasserstein area',
            hoverinfo='skip',
        )
    )

    # Add reference CDF
    fig.add_trace(
        go.Scatter(
            x=x_ref,
            y=y_ref,
            mode="lines",
            name=ref_name,
            line=dict(width=3, color='#1f77b4'),
            line_shape="hv",
        )
    )

    # Add current CDF
    fig.add_trace(
        go.Scatter(
            x=x_cur,
            y=y_cur,
            mode="lines",
            name=cur_name,
            line=dict(width=3, color='#ff7f0e'),
            line_shape="hv",
        )
    )

    fig.update_layout(
        title=f"Wasserstein Distance: {w_dist:.4f}<br><sub>Measures how far distributions moved (Earth-Mover's distance)</sub>",
        xaxis_title="Value",
        yaxis_title="Cumulative Probability",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
        hovermode='x unified',
    )

    return fig


def plot_jensen_shannon_divergence(
    ref: pd.Series,
    cur: pd.Series,
    bins: int = 40,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    """
    Visualize Jensen-Shannon divergence between two distributions.
    Shows probability distributions and their divergence.
    """
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 and len(cur_clean) == 0:
        return go.Figure()

    # Create bins on combined data
    combined = np.concatenate([ref_clean.values, cur_clean.values])
    bin_edges = np.histogram_bin_edges(combined, bins=bins)
    
    # Get histograms
    ref_counts, _ = np.histogram(ref_clean.values, bins=bin_edges)
    cur_counts, _ = np.histogram(cur_clean.values, bins=bin_edges)
    
    # Normalize to probabilities with smoothing
    epsilon = 1e-12
    p = ref_counts.astype(float) / ref_counts.sum() if ref_counts.sum() > 0 else np.zeros_like(ref_counts, dtype=float)
    q = cur_counts.astype(float) / cur_counts.sum() if cur_counts.sum() > 0 else np.zeros_like(cur_counts, dtype=float)
    p = p + epsilon
    p = p / p.sum()
    q = q + epsilon
    q = q / q.sum()
    
    # Calculate Jensen-Shannon distance
    js_dist = float(jensenshannon(p, q))
    
    # Calculate the mixture (M = (P + Q) / 2)
    m = (p + q) / 2.0
    
    # Bin centers for plotting
    centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0

    fig = go.Figure()

    # Add reference distribution
    fig.add_trace(
        go.Bar(
            x=centers,
            y=p,
            name=ref_name,
            opacity=0.7,
            marker_color='#1f77b4',
        )
    )

    # Add current distribution
    fig.add_trace(
        go.Bar(
            x=centers,
            y=q,
            name=cur_name,
            opacity=0.7,
            marker_color='#ff7f0e',
        )
    )

    # Add mixture distribution
    fig.add_trace(
        go.Scatter(
            x=centers,
            y=m,
            mode="lines",
            name="Mixture M = (P+Q)/2",
            line=dict(width=3, color='green', dash='dash'),
        )
    )

    # Add divergence indicators
    divergence = np.maximum(np.abs(p - m), np.abs(q - m))
    fig.add_trace(
        go.Scatter(
            x=centers,
            y=divergence,
            mode="lines",
            name="Max divergence from M",
            line=dict(width=2, color='red', dash='dot'),
            yaxis='y2',
        )
    )

    fig.update_layout(
        title=f"Jensen-Shannon Distance: {js_dist:.4f}<br><sub>Symmetric bounded measure of distribution difference (0=identical, 1=completely different)</sub>",
        xaxis_title="Value",
        yaxis_title="Probability",
        yaxis2=dict(
            title="Divergence",
            overlaying='y',
            side='right',
            showgrid=False,
        ),
        legend_title="Component",
        barmode="overlay",
        margin=dict(l=10, r=60, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
        hovermode='x unified',
    )

    return fig


def plot_jensen_shannon_categorical(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    """
    Visualize Jensen-Shannon divergence for categorical features.
    Shows probability distributions and their divergence.
    """
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts().reindex(categories, fill_value=0)
    cur_counts = cur.value_counts().reindex(categories, fill_value=0)

    # Normalize to probabilities with smoothing
    epsilon = 1e-12
    p = ref_counts.values.astype(float) / ref_counts.sum()
    q = cur_counts.values.astype(float) / cur_counts.sum()
    p = p + epsilon
    p = p / p.sum()
    q = q + epsilon
    q = q / q.sum()

    # Calculate Jensen-Shannon distance
    js_dist = float(jensenshannon(p, q))

    # Calculate the mixture
    m = (p + q) / 2.0

    # Calculate KL divergences for each category
    kl_p_m = p * np.log2(p / m)
    kl_q_m = q * np.log2(q / m)

    fig = go.Figure()

    # Add reference distribution
    fig.add_trace(
        go.Bar(
            x=categories,
            y=p,
            name=ref_name,
            opacity=0.7,
            marker_color='#1f77b4',
        )
    )

    # Add current distribution
    fig.add_trace(
        go.Bar(
            x=categories,
            y=q,
            name=cur_name,
            opacity=0.7,
            marker_color='#ff7f0e',
        )
    )

    # Add mixture distribution
    fig.add_trace(
        go.Scatter(
            x=categories,
            y=m,
            mode="markers+lines",
            name="Mixture M = (P+Q)/2",
            line=dict(width=3, color='green', dash='dash'),
            marker=dict(size=10, symbol='diamond'),
        )
    )

    # Add per-category contribution to JS divergence
    contribution = (kl_p_m + kl_q_m) / 2.0
    fig.add_trace(
        go.Bar(
            x=categories,
            y=contribution,
            name="JS contribution",
            marker_color='rgba(255, 0, 0, 0.3)',
            yaxis='y2',
        )
    )

    fig.update_layout(
        title=f"Jensen-Shannon Distance: {js_dist:.4f}<br><sub>Symmetric bounded measure of distribution difference (0=identical, ~0.69=completely different)</sub>",
        xaxis_title="Category",
        yaxis_title="Probability",
        yaxis2=dict(
            title="JS Contribution",
            overlaying='y',
            side='right',
            showgrid=False,
        ),
        legend_title="Component",
        barmode="overlay",
        margin=dict(l=10, r=80, t=60, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )

    return fig
