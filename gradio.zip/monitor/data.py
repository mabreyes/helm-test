from __future__ import annotations

import os
from typing import Tuple

import numpy as np
import pandas as pd


def _normalize_probabilities(probs: list[float]) -> list[float]:
    total = sum(probs)
    if total <= 0:
        raise ValueError("Sum of probabilities must be positive")
    return [p / total for p in probs]


def generate_synthetic_data(
    reference_n: int = 2000,
    current_n: int = 2000,
    seed: int = 42,
    drift_strength: float = 0.2,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Generate synthetic reference and current datasets with both numerical and categorical features.

    Numerical: KS drift via shifts in means/variances
    Categorical: Chi-square drift via probability mass shifts

    Parameters
    ----------
    reference_n : int
        Number of rows in the reference dataset.
    current_n : int
        Number of rows in the current dataset.
    seed : int
        Random seed for reproducibility.
    drift_strength : float
        0.0 = no drift, higher values increase drift magnitude.

    Returns
    -------
    (reference_df, current_df)
    """
    rng = np.random.default_rng(seed)

    # Numerical features
    age_ref = rng.normal(loc=40.0, scale=10.0, size=reference_n)
    age_ref = np.clip(age_ref, 18, 90)
    age_cur = rng.normal(
        loc=40.0 + 5.0 * drift_strength,
        scale=10.0 + 2.0 * drift_strength,
        size=current_n,
    )
    age_cur = np.clip(age_cur, 18, 90)

    income_ref = rng.lognormal(mean=10.5, sigma=0.50, size=reference_n)
    income_ref = np.clip(income_ref, 0, np.quantile(income_ref, 0.995))
    income_cur = rng.lognormal(
        mean=10.5 + 0.20 * drift_strength,
        sigma=0.50 + 0.10 * drift_strength,
        size=current_n,
    )
    income_cur = np.clip(income_cur, 0, np.quantile(income_cur, 0.995))

    alpha_ref = 2.0
    beta_ref = 5.0
    # keep parameters > 0
    alpha_cur = max(0.5, alpha_ref - 0.5 * drift_strength)
    beta_cur = max(0.5, beta_ref + 0.5 * drift_strength)
    score_ref = rng.beta(alpha_ref, beta_ref, size=reference_n) * 100.0
    score_cur = rng.beta(alpha_cur, beta_cur, size=current_n) * 100.0

    # Categorical features
    seg_categories = ["A", "B", "C"]
    seg_ref_p = [0.60, 0.30, 0.10]
    # Move mass from A -> C proportionally to drift_strength
    a_drop = min(seg_ref_p[0] - 0.05, 0.20 * drift_strength)
    seg_cur_p = _normalize_probabilities(
        [seg_ref_p[0] - a_drop, seg_ref_p[1], seg_ref_p[2] + a_drop]
    )

    plan_categories = ["Basic", "Plus", "Pro"]
    plan_ref_p = [0.50, 0.35, 0.15]
    # Move mass from Basic -> Plus and Pro
    basic_drop = min(plan_ref_p[0] - 0.10, 0.20 * drift_strength)
    plan_cur_p = _normalize_probabilities(
        [
            plan_ref_p[0] - basic_drop,
            plan_ref_p[1] + basic_drop * 0.6,
            plan_ref_p[2] + basic_drop * 0.4,
        ]
    )

    segment_ref = rng.choice(seg_categories, size=reference_n, p=seg_ref_p)
    segment_cur = rng.choice(seg_categories, size=current_n, p=seg_cur_p)

    plan_ref = rng.choice(plan_categories, size=reference_n, p=plan_ref_p)
    plan_cur = rng.choice(plan_categories, size=current_n, p=plan_cur_p)

    reference = pd.DataFrame(
        {
            "age": age_ref,
            "income": income_ref,
            "score": score_ref,
            "segment": pd.Categorical(segment_ref, categories=seg_categories),
            "plan": pd.Categorical(plan_ref, categories=plan_categories),
        }
    )

    current = pd.DataFrame(
        {
            "age": age_cur,
            "income": income_cur,
            "score": score_cur,
            "segment": pd.Categorical(segment_cur, categories=seg_categories),
            "plan": pd.Categorical(plan_cur, categories=plan_categories),
        }
    )

    return reference, current


def save_datasets(
    reference_df: pd.DataFrame, current_df: pd.DataFrame, outdir: str
) -> tuple[str, str]:
    os.makedirs(outdir, exist_ok=True)
    ref_path = os.path.join(outdir, "reference.csv")
    cur_path = os.path.join(outdir, "current.csv")
    reference_df.to_csv(ref_path, index=False)
    current_df.to_csv(cur_path, index=False)
    return ref_path, cur_path
