"""
Drift Detection Service

Single Responsibility: Orchestrate the execution of drift tests across all features.
This is a Domain Service that coordinates multiple statistical tests.
"""

from __future__ import annotations

import pandas as pd

from ..domain.models import DriftAnalysisResult, DriftResult
from ..domain.value_objects import DriftThresholds, FeatureType
from .statistical_tests import CategoricalDriftTests, NumericalDriftTests


class DriftDetectionService:
    """
    Domain Service: Orchestrate drift detection across features.

    Single Responsibility:
    - Coordinate statistical tests for all features
    - Apply appropriate tests based on feature type
    - Aggregate results into DriftAnalysisResult

    This service implements the business logic of "how to detect drift"
    but delegates the actual statistical computations to specialized services.
    """

    def __init__(
        self,
        numerical_tests: NumericalDriftTests | None = None,
        categorical_tests: CategoricalDriftTests | None = None,
    ):
        """
        Initialize with test services (dependency injection).

        Args:
            numerical_tests: Service for numerical drift tests
            categorical_tests: Service for categorical drift tests
        """
        self._numerical_tests = numerical_tests or NumericalDriftTests()
        self._categorical_tests = categorical_tests or CategoricalDriftTests()

    def detect_drift(
        self,
        reference_df: pd.DataFrame,
        current_df: pd.DataFrame,
        thresholds: DriftThresholds | None = None,
    ) -> DriftAnalysisResult:
        """
        Execute drift detection across all features.

        Single Responsibility: Orchestrate the complete drift detection workflow.

        Args:
            reference_df: Baseline dataset
            current_df: Current dataset to compare
            thresholds: Configuration for drift thresholds

        Returns:
            DriftAnalysisResult containing all test results

        Raises:
            ValueError: If dataframes don't have matching columns
        """
        if set(reference_df.columns) != set(current_df.columns):
            raise ValueError("Reference and current dataframes must have the same columns")

        thresholds = thresholds or DriftThresholds()
        thresholds.validate()

        numeric_cols, categorical_cols = FeatureType.identify_column_types(reference_df)

        results: list[DriftResult] = []

        # Execute numerical tests
        results.extend(
            self._execute_numerical_tests(reference_df, current_df, numeric_cols, thresholds)
        )

        # Execute categorical tests
        results.extend(
            self._execute_categorical_tests(reference_df, current_df, categorical_cols, thresholds)
        )

        total_features = len(numeric_cols) + len(categorical_cols)

        return DriftAnalysisResult(
            results=results,
            total_features=total_features,
            total_tests=len(results),
        )

    def _execute_numerical_tests(
        self,
        reference_df: pd.DataFrame,
        current_df: pd.DataFrame,
        columns: list[str],
        thresholds: DriftThresholds,
    ) -> list[DriftResult]:
        """
        Execute all numerical drift tests.

        Single Responsibility: Apply numerical test suite to all numerical features.
        """
        results = []

        for col in columns:
            # KS test (significance)
            res_ks = self._numerical_tests.ks_test(
                reference_df[col], current_df[col], thresholds.alpha
            )
            res_ks = DriftResult(
                feature=col, **{k: v for k, v in res_ks.to_dict().items() if k != "feature"}
            )
            results.append(res_ks)

            # Wasserstein test (alert KPI)
            res_wass = self._numerical_tests.wasserstein_test(
                reference_df[col], current_df[col], thresholds.wasserstein_threshold
            )
            res_wass = DriftResult(
                feature=col, **{k: v for k, v in res_wass.to_dict().items() if k != "feature"}
            )
            results.append(res_wass)

            # PSI test (reporting)
            res_psi = self._numerical_tests.psi_test(
                reference_df[col], current_df[col], thresholds.bins, thresholds.psi_threshold
            )
            res_psi = DriftResult(
                feature=col, **{k: v for k, v in res_psi.to_dict().items() if k != "feature"}
            )
            results.append(res_psi)

        return results

    def _execute_categorical_tests(
        self,
        reference_df: pd.DataFrame,
        current_df: pd.DataFrame,
        columns: list[str],
        thresholds: DriftThresholds,
    ) -> list[DriftResult]:
        """
        Execute all categorical drift tests.

        Single Responsibility: Apply categorical test suite to all categorical features.
        """
        results = []

        for col in columns:
            # Chi-square test (significance)
            res_chi = self._categorical_tests.chi_square_test(
                reference_df[col], current_df[col], thresholds.alpha
            )
            res_chi = DriftResult(
                feature=col, **{k: v for k, v in res_chi.to_dict().items() if k != "feature"}
            )
            results.append(res_chi)

            # Jensen-Shannon test (alert KPI)
            res_js = self._categorical_tests.jensen_shannon_test(
                reference_df[col], current_df[col], thresholds.js_threshold
            )
            res_js = DriftResult(
                feature=col, **{k: v for k, v in res_js.to_dict().items() if k != "feature"}
            )
            results.append(res_js)

            # Euclidean test (fast signal)
            res_eucl = self._categorical_tests.euclidean_test(
                reference_df[col], current_df[col], thresholds.euclidean_threshold
            )
            res_eucl = DriftResult(
                feature=col, **{k: v for k, v in res_eucl.to_dict().items() if k != "feature"}
            )
            results.append(res_eucl)

            # PSI test (reporting)
            res_psi = self._categorical_tests.psi_test(
                reference_df[col], current_df[col], thresholds.psi_threshold
            )
            res_psi = DriftResult(
                feature=col, **{k: v for k, v in res_psi.to_dict().items() if k != "feature"}
            )
            results.append(res_psi)

        return results
