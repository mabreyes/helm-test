"""
Statistical Tests Services

Single Responsibility: Execute statistical tests for drift detection.
Each class is responsible for one type of feature (numerical or categorical).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial.distance import jensenshannon
from scipy.stats import chi2_contingency, entropy, ks_2samp, wasserstein_distance

from ..domain.models import DriftResult

# Constants
_EPSILON = 1e-12


class ProbabilityNormalizer:
    """
    Single Responsibility: Normalize counts to probabilities with smoothing.
    """

    @staticmethod
    def normalize(counts: np.ndarray) -> np.ndarray:
        """
        Convert counts to normalized probabilities with epsilon smoothing.

        Args:
            counts: Array of counts

        Returns:
            Normalized probability array
        """
        total = float(np.sum(counts))
        if total <= 0.0:
            return np.zeros_like(counts, dtype=float)
        probs = counts.astype(float) / total
        # Smooth and renormalize to avoid zeros which can cause infs in divergences
        probs = probs + _EPSILON
        probs = probs / probs.sum()
        return probs


class DivergenceCalculator:
    """
    Single Responsibility: Calculate divergence metrics between probability distributions.
    """

    @staticmethod
    def jensen_shannon_distance(p: np.ndarray, q: np.ndarray) -> float:
        """Calculate Jensen-Shannon distance between two probability distributions."""
        p = np.asarray(p, dtype=float)
        q = np.asarray(q, dtype=float)
        return float(jensenshannon(p, q))

    @staticmethod
    def psi(p: np.ndarray, q: np.ndarray) -> float:
        """
        Calculate Population Stability Index (PSI).
        PSI = KL(p||q) + KL(q||p) (symmetric KL divergence)
        """
        p = np.asarray(p, dtype=float)
        q = np.asarray(q, dtype=float)
        return float(entropy(p, q) + entropy(q, p))


class NumericalDriftTests:
    """
    Domain Service: Execute drift tests for numerical features.

    Single Responsibility: Provide all drift test implementations for numerical data.
    """

    def __init__(self):
        self._normalizer = ProbabilityNormalizer()
        self._divergence_calc = DivergenceCalculator()

    def ks_test(self, ref: pd.Series, cur: pd.Series, alpha: float) -> DriftResult:
        """
        Kolmogorov-Smirnov test for numerical features.

        Single Responsibility: Execute KS test and return structured result.

        Best for: Standard significance test for continuous distributions.
        Pair with Wasserstein for effect size.
        """
        ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
        cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

        if len(ref_clean) == 0 or len(cur_clean) == 0:
            return DriftResult(
                feature="",
                feature_type="numerical",
                test="ks",
                statistic=float("nan"),
                p_value=float("nan"),
                effect_size=float("nan"),
                threshold=float(alpha),
                drift_detected=False,
                n_ref=int(len(ref_clean)),
                n_cur=int(len(cur_clean)),
            )

        stat, p_value = ks_2samp(
            ref_clean.values, cur_clean.values, alternative="two-sided", mode="auto"
        )
        w_dist = wasserstein_distance(ref_clean.values, cur_clean.values)

        return DriftResult(
            feature="",
            feature_type="numerical",
            test="ks",
            statistic=float(stat),
            p_value=float(p_value),
            effect_size=float(w_dist),
            threshold=float(alpha),
            drift_detected=bool(p_value < alpha),
            n_ref=int(len(ref_clean)),
            n_cur=int(len(cur_clean)),
        )

    def wasserstein_test(self, ref: pd.Series, cur: pd.Series, threshold: float) -> DriftResult:
        """
        Wasserstein (Earth-Mover's) distance test.

        Single Responsibility: Calculate Wasserstein distance and check threshold.

        Best for: Alert KPI for continuous data, measures distribution shift magnitude.
        """
        ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
        cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

        if len(ref_clean) == 0 or len(cur_clean) == 0:
            return DriftResult(
                feature="",
                feature_type="numerical",
                test="wasserstein",
                statistic=float("nan"),
                p_value=float("nan"),
                effect_size=float("nan"),
                threshold=float(threshold),
                drift_detected=False,
                n_ref=int(len(ref_clean)),
                n_cur=int(len(cur_clean)),
            )

        w_dist = wasserstein_distance(ref_clean.values, cur_clean.values)

        return DriftResult(
            feature="",
            feature_type="numerical",
            test="wasserstein",
            statistic=float(w_dist),
            p_value=float("nan"),
            effect_size=float(w_dist),
            threshold=float(threshold),
            drift_detected=bool(w_dist >= threshold),
            n_ref=int(len(ref_clean)),
            n_cur=int(len(cur_clean)),
        )

    def psi_test(self, ref: pd.Series, cur: pd.Series, bins: int, threshold: float) -> DriftResult:
        """
        Population Stability Index (PSI) test for numerical features.

        Single Responsibility: Calculate PSI using fixed bins.

        Best for: Common reporting KPI with industry-familiar thresholds.
        """
        ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
        cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

        if len(ref_clean) == 0 or len(cur_clean) == 0:
            return DriftResult(
                feature="",
                feature_type="numerical",
                test="psi",
                statistic=float("nan"),
                p_value=float("nan"),
                effect_size=float("nan"),
                threshold=float(threshold),
                drift_detected=False,
                n_ref=int(len(ref_clean)),
                n_cur=int(len(cur_clean)),
            )

        combined = np.concatenate([ref_clean.values, cur_clean.values])
        bin_edges = np.histogram_bin_edges(combined, bins=bins)
        ref_counts, _ = np.histogram(ref_clean.values, bins=bin_edges)
        cur_counts, _ = np.histogram(cur_clean.values, bins=bin_edges)

        p = self._normalizer.normalize(ref_counts)
        q = self._normalizer.normalize(cur_counts)

        psi_value = self._divergence_calc.psi(p, q)

        return DriftResult(
            feature="",
            feature_type="numerical",
            test="psi",
            statistic=float(psi_value),
            p_value=float("nan"),
            effect_size=float("nan"),
            threshold=float(threshold),
            drift_detected=bool(psi_value >= threshold),
            n_ref=int(len(ref_clean)),
            n_cur=int(len(cur_clean)),
        )


class CategoricalDriftTests:
    """
    Domain Service: Execute drift tests for categorical features.

    Single Responsibility: Provide all drift test implementations for categorical data.
    """

    def __init__(self):
        self._normalizer = ProbabilityNormalizer()
        self._divergence_calc = DivergenceCalculator()

    def chi_square_test(self, ref: pd.Series, cur: pd.Series, alpha: float) -> DriftResult:
        """
        Chi-square test for categorical features.

        Single Responsibility: Execute Chi-square test and return structured result.

        Best for: Significance test for categorical distributions.
        Pair with Jensen-Shannon for effect size.
        """
        ref = ref.astype("object").fillna("<NA>")
        cur = cur.astype("object").fillna("<NA>")

        categories = sorted(set(ref.unique()).union(set(cur.unique())))
        ref_counts = ref.value_counts().reindex(categories, fill_value=0)
        cur_counts = cur.value_counts().reindex(categories, fill_value=0)
        contingency = np.vstack([ref_counts.values, cur_counts.values])

        chi2, p_value, dof, _ = chi2_contingency(contingency, correction=False)

        # Calculate Cramér's V as effect size
        n_total = contingency.sum()
        r, k = contingency.shape
        denom = n_total * (min(r - 1, k - 1))
        cramer_v = float(np.sqrt(chi2 / denom)) if denom > 0 else 0.0

        return DriftResult(
            feature="",
            feature_type="categorical",
            test="chi-square",
            statistic=float(chi2),
            p_value=float(p_value),
            effect_size=cramer_v,
            threshold=float(alpha),
            drift_detected=bool(p_value < alpha),
            n_ref=int(ref_counts.sum()),
            n_cur=int(cur_counts.sum()),
        )

    def jensen_shannon_test(self, ref: pd.Series, cur: pd.Series, threshold: float) -> DriftResult:
        """
        Jensen-Shannon distance test for categorical features.

        Single Responsibility: Calculate JS distance and check threshold.

        Best for: Alert KPI, symmetric bounded distance on category probabilities.
        """
        ref = ref.astype("object").fillna("<NA>")
        cur = cur.astype("object").fillna("<NA>")

        categories = sorted(set(ref.unique()).union(set(cur.unique())))
        ref_counts = ref.value_counts().reindex(categories, fill_value=0)
        cur_counts = cur.value_counts().reindex(categories, fill_value=0)

        p = self._normalizer.normalize(ref_counts.values)
        q = self._normalizer.normalize(cur_counts.values)

        js_distance = self._divergence_calc.jensen_shannon_distance(p, q)

        return DriftResult(
            feature="",
            feature_type="categorical",
            test="jensen-shannon",
            statistic=float(js_distance),
            p_value=float("nan"),
            effect_size=float("nan"),
            threshold=float(threshold),
            drift_detected=bool(js_distance >= threshold),
            n_ref=int(ref_counts.sum()),
            n_cur=int(cur_counts.sum()),
        )

    def euclidean_test(self, ref: pd.Series, cur: pd.Series, threshold: float) -> DriftResult:
        """
        Euclidean distance (L2 norm) on category probability vectors.

        Single Responsibility: Calculate L2 distance between categorical distributions.

        Best for: Fast secondary signal for quick feature ranking.
        """
        ref = ref.astype("object").fillna("<NA>")
        cur = cur.astype("object").fillna("<NA>")

        categories = sorted(set(ref.unique()).union(set(cur.unique())))
        ref_probs = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
        cur_probs = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)

        euclidean_dist = float(np.sqrt(np.sum((ref_probs.values - cur_probs.values) ** 2)))

        return DriftResult(
            feature="",
            feature_type="categorical",
            test="euclidean",
            statistic=float(euclidean_dist),
            p_value=float("nan"),
            effect_size=float("nan"),
            threshold=float(threshold),
            drift_detected=bool(euclidean_dist >= threshold),
            n_ref=int(len(ref)),
            n_cur=int(len(cur)),
        )

    def psi_test(self, ref: pd.Series, cur: pd.Series, threshold: float) -> DriftResult:
        """
        Population Stability Index (PSI) for categorical features.

        Single Responsibility: Calculate PSI for categorical data.

        Best for: Common reporting KPI with industry-familiar thresholds.
        """
        ref = ref.astype("object").fillna("<NA>")
        cur = cur.astype("object").fillna("<NA>")

        categories = sorted(set(ref.unique()).union(set(cur.unique())))
        ref_counts = ref.value_counts().reindex(categories, fill_value=0)
        cur_counts = cur.value_counts().reindex(categories, fill_value=0)

        p = self._normalizer.normalize(ref_counts.values)
        q = self._normalizer.normalize(cur_counts.values)

        psi_value = self._divergence_calc.psi(p, q)

        return DriftResult(
            feature="",
            feature_type="categorical",
            test="psi",
            statistic=float(psi_value),
            p_value=float("nan"),
            effect_size=float("nan"),
            threshold=float(threshold),
            drift_detected=bool(psi_value >= threshold),
            n_ref=int(ref_counts.sum()),
            n_cur=int(cur_counts.sum()),
        )
