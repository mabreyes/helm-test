"""
Drift Analyzer - Application Service

Single Responsibility: Orchestrate the complete drift analysis use case.
This is the main entry point for drift detection functionality.
"""

from __future__ import annotations

import pandas as pd

from ..domain.models import DriftAnalysisResult
from ..domain.value_objects import DriftThresholds
from ..infrastructure.data_repository import DataRepository, SyntheticDataGenerator
from ..infrastructure.report_writer import ReportWriter
from ..services.drift_detection_service import DriftDetectionService


class DriftAnalyzer:
    """
    Application Service: Orchestrate drift analysis use case.

    Single Responsibility: Coordinate all components to execute drift analysis.

    This class implements the use case:
    "As a data scientist, I want to analyze drift between two datasets
    and get a comprehensive report of the results."

    It coordinates:
    - Data loading (Infrastructure)
    - Drift detection (Domain Service)
    - Report generation (Infrastructure)
    """

    def __init__(
        self,
        drift_service: DriftDetectionService | None = None,
        data_repository: DataRepository | None = None,
        report_writer: ReportWriter | None = None,
    ):
        """
        Initialize with dependencies (Dependency Injection pattern).

        Args:
            drift_service: Service for drift detection
            data_repository: Repository for data access
            report_writer: Writer for report persistence
        """
        self._drift_service = drift_service or DriftDetectionService()
        self._data_repository = data_repository or DataRepository()
        self._report_writer = report_writer or ReportWriter()

    def analyze_drift(
        self,
        reference_df: pd.DataFrame,
        current_df: pd.DataFrame,
        thresholds: DriftThresholds | None = None,
    ) -> DriftAnalysisResult:
        """
        Execute complete drift analysis.

        Single Responsibility: Orchestrate the drift analysis workflow.

        Args:
            reference_df: Baseline dataset
            current_df: Current dataset to compare
            thresholds: Optional custom thresholds

        Returns:
            DriftAnalysisResult with complete analysis
        """
        return self._drift_service.detect_drift(reference_df, current_df, thresholds)

    def analyze_and_save(
        self,
        reference_df: pd.DataFrame,
        current_df: pd.DataFrame,
        output_dir: str,
        thresholds: DriftThresholds | None = None,
    ) -> tuple[DriftAnalysisResult, tuple[str, str]]:
        """
        Execute drift analysis and save results to files.

        Single Responsibility: Orchestrate analysis and persistence together.

        Args:
            reference_df: Baseline dataset
            current_df: Current dataset to compare
            output_dir: Directory to save reports
            thresholds: Optional custom thresholds

        Returns:
            Tuple of (analysis_result, (csv_path, json_path))
        """
        # Analyze drift
        analysis_result = self.analyze_drift(reference_df, current_df, thresholds)

        # Save report
        report_paths = self._report_writer.save_report(analysis_result, output_dir)

        return analysis_result, report_paths

    def generate_synthetic_data_and_analyze(
        self,
        reference_n: int = 2000,
        current_n: int = 2000,
        drift_strength: float = 0.2,
        seed: int = 42,
        thresholds: DriftThresholds | None = None,
    ) -> tuple[DriftAnalysisResult, pd.DataFrame, pd.DataFrame]:
        """
        Generate synthetic data and analyze drift.

        Single Responsibility: Orchestrate data generation and analysis for testing.

        Args:
            reference_n: Number of reference samples
            current_n: Number of current samples
            drift_strength: Magnitude of drift to inject
            seed: Random seed
            thresholds: Optional custom thresholds

        Returns:
            Tuple of (analysis_result, reference_df, current_df)
        """
        # Generate data
        generator = SyntheticDataGenerator(seed=seed)
        reference_df, current_df = generator.generate(
            reference_n=reference_n,
            current_n=current_n,
            drift_strength=drift_strength,
        )

        # Analyze
        analysis_result = self.analyze_drift(reference_df, current_df, thresholds)

        return analysis_result, reference_df, current_df
