"""
Notification Application Service

Single Responsibility: Orchestrate notification use cases and coordinate between domain and infrastructure.
This service implements the business logic for notification workflows.
"""

from __future__ import annotations

from ..domain.models import (
    DriftAnalysisResult,
    NotificationHistory,
    NotificationMessage,
    NotificationSeverity,
)
from ..domain.value_objects import NotificationConfig
from ..infrastructure.notification_providers import NotificationProvider


class NotificationApplicationService:
    """
    Application Service: Orchestrate notification use cases.

    Single Responsibility: Coordinate notification business logic and infrastructure.

    This service implements the use cases:
    - "As a data scientist, I want to be notified when drift is detected"
    - "As a data scientist, I want to be notified when analysis is complete"
    - "As a system administrator, I want to manage notification preferences"
    """

    def __init__(
        self,
        notification_provider: NotificationProvider | None = None,
        config: NotificationConfig | None = None,
    ):
        """
        Initialize with dependencies (Dependency Injection pattern).

        Args:
            notification_provider: Infrastructure service for sending notifications
            config: Notification configuration
        """
        self._notification_provider = notification_provider or NotificationProvider()
        self._config = config or NotificationConfig()
        self._history = NotificationHistory()

    def notify_drift_detected(self, analysis_result: DriftAnalysisResult) -> bool:
        """
        Send notification about drift detection.

        Single Responsibility: Orchestrate drift notification use case.

        Args:
            analysis_result: Complete drift analysis result

        Returns:
            True if notification was sent successfully, False otherwise
        """
        if not self._config.enabled or not self._config.show_on_drift:
            return False

        drifted_features = analysis_result.get_drifted_features()
        if len(drifted_features) < self._config.min_drift_threshold:
            return False

        # Determine severity and create notification
        critical_drifts = analysis_result.get_critical_drifts()
        drift_rate = analysis_result.get_drift_rate()

        notification = self._create_drift_notification(
            analysis_result, len(drifted_features), len(critical_drifts), drift_rate
        )

        # Send notification
        success = self._notification_provider.send_notification(notification, self._config)

        # Update history
        if success:
            self._history = self._history.add_notification(notification)

        return success

    def notify_analysis_complete(
        self, analysis_result: DriftAnalysisResult, duration_seconds: float
    ) -> bool:
        """
        Send notification when analysis is complete.

        Single Responsibility: Orchestrate analysis completion notification use case.

        Args:
            analysis_result: Complete drift analysis result
            duration_seconds: Time taken for analysis

        Returns:
            True if notification was sent successfully, False otherwise
        """
        if not self._config.enabled or not self._config.show_summary:
            return False

        notification = self._create_analysis_complete_notification(
            analysis_result, duration_seconds
        )

        # Send notification
        success = self._notification_provider.send_notification(notification, self._config)

        # Update history
        if success:
            self._history = self._history.add_notification(notification)

        return success

    def test_notification(self) -> bool:
        """
        Send a test notification to verify the system is working.

        Single Responsibility: Orchestrate test notification use case.

        Returns:
            True if notification was sent successfully, False otherwise
        """
        notification = NotificationMessage(
            title="Test Notification",
            message="Notification system is working correctly!",
            severity=NotificationSeverity.INFO,
        )

        success = self._notification_provider.send_notification(notification, self._config)

        if success:
            self._history = self._history.add_notification(notification)

        return success

    def update_config(self, **kwargs) -> None:
        """
        Update notification configuration.

        Single Responsibility: Update configuration while maintaining validation.
        """
        config_dict = {
            "enabled": self._config.enabled,
            "show_on_drift": self._config.show_on_drift,
            "show_summary": self._config.show_summary,
            "sound_enabled": self._config.sound_enabled,
            "min_drift_threshold": self._config.min_drift_threshold,
        }

        # Update with provided values
        for key, value in kwargs.items():
            if key in config_dict:
                config_dict[key] = value

        # Create new config and validate
        new_config = NotificationConfig(**config_dict)
        new_config.validate()

        self._config = new_config

    def get_notification_history(self) -> NotificationHistory:
        """Get the current notification history."""
        return self._history

    def clear_history(self) -> None:
        """Clear notification history."""
        self._history = self._history.clear()

    def _create_drift_notification(
        self,
        analysis_result: DriftAnalysisResult,
        drifted_features_count: int,
        critical_drift_count: int,
        drift_rate: float,
    ) -> NotificationMessage:
        """
        Create notification message for drift detection.

        Single Responsibility: Format drift notification message based on severity.
        """
        # Determine severity
        if critical_drift_count > 0:
            severity = NotificationSeverity.CRITICAL
            title = "Critical Drift Detected"
        elif drift_rate > 0.5:
            severity = NotificationSeverity.WARNING
            title = "Significant Drift Detected"
        else:
            severity = NotificationSeverity.INFO
            title = "Drift Detected"

        # Format message
        message_lines = [
            f"{drifted_features_count} of {analysis_result.total_features} features drifted ({drift_rate:.1%})"
        ]

        if critical_drift_count > 0:
            message_lines.append(f"{critical_drift_count} features with critical drift")

        return NotificationMessage(
            title=title,
            message="\n".join(message_lines),
            severity=severity,
        )

    def _create_analysis_complete_notification(
        self, analysis_result: DriftAnalysisResult, duration_seconds: float
    ) -> NotificationMessage:
        """
        Create notification message for analysis completion.

        Single Responsibility: Format analysis completion notification message.
        """
        return NotificationMessage(
            title="Analysis Complete",
            message=(
                f"Analyzed {analysis_result.total_features} features with {analysis_result.total_tests} tests\n"
                f"Completed in {duration_seconds:.1f} seconds"
            ),
            severity=NotificationSeverity.INFO,
        )
