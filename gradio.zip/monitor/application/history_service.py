"""
Drift History Application Service

Single Responsibility: Orchestrate drift history use cases between domain and infrastructure.
"""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

import pandas as pd

from ..domain.history import DriftHistoryRepository, DriftSnapshotRow, DriftSnapshotRun
from ..domain.models import DriftAnalysisResult


class DriftHistoryApplicationService:
    """
    Coordinate recording analysis snapshots and querying trends.
    """

    def __init__(self, repository: DriftHistoryRepository):
        self._repo = repository
        self._repo.ensure_schema()

    def record_analysis(
        self,
        analysis: DriftAnalysisResult,
        ref_samples: int,
        cur_samples: int,
        run_id: str | None = None,
        timestamp: datetime | None = None,
    ) -> str:
        """
        Persist a full analysis snapshot (one row per feature/test).
        """
        rid = run_id or str(uuid4())
        ts = timestamp or datetime.utcnow()

        run = DriftSnapshotRun(
            run_id=rid,
            timestamp=ts,
            ref_samples=int(ref_samples),
            cur_samples=int(cur_samples),
            total_features=int(analysis.total_features),
            total_tests=int(analysis.total_tests),
        )
        rows: list[DriftSnapshotRow] = []
        for r in analysis.results:
            rows.append(
                DriftSnapshotRow(
                    run_id=rid,
                    timestamp=ts,
                    feature=r.feature,
                    feature_type=r.feature_type,
                    test=r.test,
                    statistic=float(r.statistic) if r.statistic is not None else None,
                    p_value=float(r.p_value) if r.p_value is not None else None,
                    effect_size=float(r.effect_size) if r.effect_size is not None else None,
                    threshold=float(r.threshold) if r.threshold is not None else None,
                    drift_detected=bool(r.drift_detected),
                    n_ref=int(r.n_ref),
                    n_cur=int(r.n_cur),
                )
            )

        self._repo.save_run(run, rows)
        return rid

    def query_trend(
        self,
        features: list[str],
        tests: list[str],
        interval: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> pd.DataFrame:
        """
        Return aggregated trend by time bucket for selected features/tests.
        """
        return self._repo.query_trend(features, tests, interval, start, end)
