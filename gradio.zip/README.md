# Drift Monitoring (Optimized for Large Banks / Financial Institutions)

## Setup

```bash
python -m venv .venv
source .venv/bin/activate  # on macOS/Linux
pip install -r requirements.txt
```

## CLI Usage

Generate synthetic reference/current datasets:
```bash
python cli.py generate --outdir data --ref-n 2000 --cur-n 2000 --drift-strength 0.3 --seed 42
```

Run drift detection on two CSVs (auto-detects column types):
```bash
python cli.py detect --reference data/reference.csv --current data/current.csv --alpha 0.05 --outdir outputs
```

This will print a summary and save `outputs/drift_report.csv` and `outputs/drift_report.json`.

## Dashboard

Launch the interactive dashboard:
```bash
python app.py
```

### Dashboard Tabs

1. **Overview**: Summary metrics and test statistics
2. **Results**: Full drift detection results with dynamic filtering
3. **Explore**: Interactive visualizations per feature
4. **Algorithm Guide**: Comprehensive documentation on when and how to use each algorithm

### Features
- **Dynamic thresholds**: Adjust alpha, Wasserstein, JS, and PSI thresholds with live table updates
- **Live filtering**: Filter by feature, type, or test — table updates automatically
- **Interactive visualizations**: 
  - **Wasserstein (numerical)**: Shows CDFs with shaded area representing Earth-Mover's distance
  - **Jensen-Shannon**: Visualizes distribution divergence with mixture distribution
  - Histogram, CDF, binned probabilities for numerical features
  - Category distributions, differences, and Chi-square contributions for categorical features
- **Built-in documentation**: Algorithm Guide tab with detailed explanations, thresholds, and best practices
- **Export**: Download filtered results as CSV or JSON

## How drift is identified

### Numerical features
- **KS test (Kolmogorov–Smirnov)**: Standard significance test; compares empirical CDFs; drift if p-value < alpha. Pair with Wasserstein for effect size.
- **Wasserstein distance (Earth-Mover's)**: **Top alert KPI**; measures how far distributions moved; robust, intuitive effect size; bin-free; drift if distance ≥ `wasserstein_threshold`.
- **Population Stability Index (PSI)**: Common reporting KPI; industry-familiar thresholds; computed on fixed bins; drift if PSI ≥ `psi_threshold`.

### Categorical features
- **Chi-square test**: Significance test on 2×K contingency table; drift if p-value < alpha. Effect size reported as Cramér's V. Pair with JS for effect size. Watch-out: needs expected counts ≥5; over-flags with huge N.
- **Jensen–Shannon distance (JS)**: **Top alert KPI**; symmetric bounded distance on category probabilities; great for alert thresholds; drift if JS ≥ `js_threshold`. Smooths rare categories to avoid issues.
- **Population Stability Index (PSI)**: Common reporting KPI; industry-familiar thresholds; keep category definitions fixed; drift if PSI ≥ `psi_threshold`.

### Controls and defaults
- **alpha**: 0.05 (KS, Chi-square)
- **wasserstein_threshold**: 0.10 (numerical alert KPI)
- **js_threshold**: 0.10 (categorical alert KPI)
- **psi_threshold**: 0.10 (reporting KPI, both types)
- **bins**: 40 (numerical PSI)

### Missing values
- Numerical: ignored (dropped before tests)
- Categorical: treated as explicit category `"<NA>"`

## Notes
- Algorithm selection based on best practices for large banks and financial institutions.
- Numerical: KS (significance) + Wasserstein (alert) + PSI (reporting)
- Categorical: Chi-square (significance) + Jensen-Shannon (alert) + PSI (reporting)
