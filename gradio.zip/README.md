# Drift Monitoring - ML Model Drift Detection

A professional drift monitoring system for machine learning models, built with **Domain-Driven Design (DDD)** and **Single Responsibility Principle (SRP)**.

Optimized for large banks and financial institutions with comprehensive statistical tests and interactive dashboards.

---

## Quick Start

```bash
# Setup virtual environment
python -m venv .venv
source .venv/bin/activate  # macOS/Linux
# .venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Run Gradio dashboard
python app.py
```

---

## Architecture

Clean 4-layer architecture following DDD and SRP:

```
monitor/
├── domain/              # Pure business logic (no dependencies)
│   ├── models.py        # DriftResult, DriftAnalysisResult
│   └── value_objects.py # DriftThresholds, FeatureType
├── services/            # Statistical algorithms
│   ├── statistical_tests.py
│   └── drift_detection_service.py
├── infrastructure/      # I/O and persistence
│   ├── data_repository.py
│   └── report_writer.py
└── application/         # Use case orchestration
    └── drift_analyzer.py
```

---

## Usage

### 1. Gradio Dashboard (Recommended)

```bash
python app.py
```

**Features:**
- 📊 **Multiple data sources**: Synthetic, CSV upload, PostgreSQL
- 📈 **Interactive visualizations**: 6 plot types with algorithm explanations
- 🔍 **Live filtering**: Dynamic threshold adjustment
- 📥 **Export**: Download results as CSV/JSON
- 📚 **Built-in docs**: Algorithm guide with best practices

### 2. Command Line Interface

**Generate synthetic data:**
```bash
python cli.py generate \
  --outdir data \
  --ref-n 2000 \
  --cur-n 2000 \
  --drift-strength 0.3 \
  --seed 42
```

**Detect drift:**
```bash
python cli.py detect \
  --reference data/reference.csv \
  --current data/current.csv \
  --alpha 0.05 \
  --outdir outputs
```

### 3. Python API

```python
from monitor.application import DriftAnalyzer
from monitor.infrastructure import SyntheticDataGenerator
from monitor.domain import DriftThresholds

# Generate test data
generator = SyntheticDataGenerator(seed=42)
ref_df, cur_df = generator.generate(drift_strength=0.2)

# Configure thresholds
thresholds = DriftThresholds(
    alpha=0.05,
    psi_threshold=0.1,
    wasserstein_threshold=0.1,
)

# Analyze drift
analyzer = DriftAnalyzer()
result = analyzer.analyze_drift(ref_df, cur_df, thresholds)

# Access results through domain model
print(f"Drift rate: {result.get_drift_rate():.1%}")
print(f"Drifted features: {result.get_drifted_features()}")
print(f"Critical drifts: {result.get_critical_drifts()}")
```

---

## Drift Detection Algorithms

### Numerical Features (3 tests per feature)

| Test | Purpose | Threshold | Best For |
|------|---------|-----------|----------|
| **KS Test** | Significance test | p-value < 0.05 | Standard statistical testing |
| **Wasserstein** | Effect size (EMD) | distance ≥ 0.1 | Alert KPI, measures shift magnitude |
| **PSI** | Reporting metric | PSI ≥ 0.1 | Industry-familiar reporting |

### Categorical Features (4 tests per feature)

| Test | Purpose | Threshold | Best For |
|------|---------|-----------|----------|
| **Chi-square** | Significance test | p-value < 0.05 | Standard statistical testing |
| **Jensen-Shannon** | Effect size | distance ≥ 0.1 | Alert KPI, symmetric bounded measure |
| **Euclidean (L2)** | Fast signal | distance ≥ 0.1 | Quick feature ranking |
| **PSI** | Reporting metric | PSI ≥ 0.1 | Industry-familiar reporting |

**Thresholds:**
- α (alpha) = 0.05 for statistical tests
- 0.1 for distance metrics and PSI
- 40 bins for numerical PSI calculation

---

## PostgreSQL Integration

### Quick Start with Docker

```bash
# 1. Start PostgreSQL
docker-compose up -d postgres

# 2. Load synthetic data
python load_to_postgres.py \
  --host localhost \
  --port 5432 \
  --database driftdb \
  --user driftuser \
  --password driftpass \
  --drop-existing

# 3. Use in dashboard
python app.py
# Select "PostgreSQL" → Test Connection → Select tables → Fetch data
```

### Manual PostgreSQL Setup

```bash
python load_to_postgres.py \
  --host YOUR_HOST \
  --port 5432 \
  --database YOUR_DB \
  --user YOUR_USER \
  --password YOUR_PASSWORD \
  --ref-table reference_data \
  --cur-table current_data \
  --drift-strength 0.3 \
  --drop-existing
```

---

## Dashboard Features

### 📊 Overview Tab
- Total features analyzed
- Drift rate and drifted features count
- Feature type breakdown (numerical/categorical)
- Critical drift detection (2+ tests failed)
- Test statistics by method

### 📋 Results Tab
- Complete drift detection results
- Dynamic filtering by feature, type, or test
- Live threshold adjustment
- Export to CSV/JSON

### 🔍 Explore Tab
Interactive visualizations:
- **Distribution**: Histograms (numerical) / Bar charts (categorical)
- **CDF**: Empirical CDFs for KS test visualization
- **Wasserstein**: Earth-Mover's distance with shaded area
- **Jensen-Shannon**: Divergence with mixture distribution
- **Euclidean**: L2 norm as vector distance
- **Chi-square**: Per-category contributions

### 📚 Algorithm Guide Tab
Comprehensive documentation:
- When to use each test
- Threshold recommendations
- Interpretation guidelines
- Best practices for banks

---

## Data Sources

### 1. Synthetic Data (Demo)
- Configurable drift strength (0.0 - 1.0)
- Reproducible with seed
- 5 features: age, income, score, segment, plan

### 2. CSV Upload
- Upload reference and current CSV files
- Automatic feature type detection
- Missing value handling

### 3. PostgreSQL
- Direct database connection
- Auto-discover tables
- Secure credential management
- Suitable for production data

---

## Architecture Benefits

✅ **Single Responsibility** - Each class has one reason to change
✅ **Domain-Driven Design** - Pure business logic, value objects
✅ **Testable** - Easy unit testing with dependency injection
✅ **Maintainable** - Clear layer separation
✅ **Extensible** - Add features without modifying core
✅ **Production-Ready** - Clean, professional code

---

## Project Structure

```
scb-model-monitoring/
├── app.py                  # Gradio dashboard (main UI)
├── cli.py                  # Command-line interface
├── load_to_postgres.py     # PostgreSQL data loader
├── monitor/                # Core package (DDD architecture)
│   ├── domain/             # Business models & value objects
│   ├── services/           # Statistical algorithms
│   ├── infrastructure/     # I/O and persistence
│   ├── application/        # Use case orchestration
│   ├── viz.py              # Visualization utilities
│   └── notifications.py    # Notification service
├── requirements.txt        # Python dependencies
├── docker-compose.yml      # PostgreSQL setup
└── README.md               # This file
```

---

## Development

### Run Tests
```bash
source .venv/bin/activate
python -m pytest
```

### Code Quality
```bash
# All code follows:
# - Single Responsibility Principle (SRP)
# - Domain-Driven Design (DDD)
# - Clean Architecture patterns
# - No linter errors
```

---

## Technical Details

### Missing Values
- **Numerical**: Dropped before statistical tests
- **Categorical**: Treated as explicit `"<NA"` category

### Feature Detection
- Automatic type detection: numerical vs categorical
- Pandas dtype-based classification

### Statistical Rigor
- Non-parametric tests (KS, Chi-square)
- Effect size measures (Wasserstein, JS, Cramér's V)
- Industry-standard thresholds (PSI)

---

## Requirements

- Python 3.9+
- pandas, numpy, scipy
- gradio (dashboard)
- sqlalchemy, psycopg2 (PostgreSQL)
- plotly (visualizations)

See `requirements.txt` for complete list.

---

## License

Proprietary - Internal use only

---

## Support

For questions or issues, please contact the ML Engineering team.
