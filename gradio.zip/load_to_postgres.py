#!/usr/bin/env python3
"""
Load synthetic drift monitoring data into PostgreSQL.

Usage:
    python load_to_postgres.py --host localhost --port 5432 --database mydb --user postgres --password yourpass

Optional arguments:
    --ref-n 2000            Number of reference rows
    --cur-n 2000            Number of current rows
    --drift-strength 0.3    Drift strength (0.0 to 1.0)
    --seed 42               Random seed
    --ref-table reference_data    Reference table name
    --cur-table current_data      Current table name
    --drop-existing         Drop tables if they exist
"""

import argparse
import sys
from sqlalchemy import create_engine, text
import pandas as pd

from monitor.data import generate_synthetic_data


def main():
    parser = argparse.ArgumentParser(
        description="Generate synthetic data and load into PostgreSQL"
    )

    # Database connection arguments
    parser.add_argument("--host", default="localhost", help="PostgreSQL host")
    parser.add_argument("--port", type=int, default=5432, help="PostgreSQL port")
    parser.add_argument("--database", required=True, help="Database name")
    parser.add_argument("--user", default="postgres", help="Database user")
    parser.add_argument("--password", required=True, help="Database password")

    # Data generation arguments
    parser.add_argument("--ref-n", type=int, default=2000, help="Reference rows")
    parser.add_argument("--cur-n", type=int, default=2000, help="Current rows")
    parser.add_argument(
        "--drift-strength", type=float, default=0.3, help="Drift strength (0.0-1.0)"
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed")

    # Table names
    parser.add_argument(
        "--ref-table", default="reference_data", help="Reference table name"
    )
    parser.add_argument(
        "--cur-table", default="current_data", help="Current table name"
    )

    # Options
    parser.add_argument(
        "--drop-existing", action="store_true", help="Drop tables if they exist"
    )

    args = parser.parse_args()

    print("=" * 60)
    print("PostgreSQL Data Loader - Drift Monitoring")
    print("=" * 60)

    # Generate synthetic data
    print(f"\n📊 Generating synthetic data...")
    print(f"   Reference rows: {args.ref_n}")
    print(f"   Current rows: {args.cur_n}")
    print(f"   Drift strength: {args.drift_strength}")
    print(f"   Seed: {args.seed}")

    reference_df, current_df = generate_synthetic_data(
        reference_n=args.ref_n,
        current_n=args.cur_n,
        drift_strength=args.drift_strength,
        seed=args.seed,
    )

    print(f"   ✅ Generated {len(reference_df)} reference rows")
    print(f"   ✅ Generated {len(current_df)} current rows")
    print(f"   Features: {', '.join(reference_df.columns)}")

    # Connect to PostgreSQL
    print(f"\n🔌 Connecting to PostgreSQL...")
    print(f"   Host: {args.host}:{args.port}")
    print(f"   Database: {args.database}")
    print(f"   User: {args.user}")

    try:
        connection_string = f"postgresql://{args.user}:{args.password}@{args.host}:{args.port}/{args.database}"
        engine = create_engine(connection_string)

        # Test connection
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))

        print(f"   ✅ Connected successfully")
    except Exception as e:
        print(f"   ❌ Connection failed: {e}")
        sys.exit(1)

    # Drop existing tables if requested
    if args.drop_existing:
        print(f"\n🗑️  Dropping existing tables...")
        try:
            with engine.connect() as conn:
                conn.execute(text(f'DROP TABLE IF EXISTS "{args.ref_table}" CASCADE'))
                conn.execute(text(f'DROP TABLE IF EXISTS "{args.cur_table}" CASCADE'))
                conn.commit()
            print(f"   ✅ Dropped tables (if they existed)")
        except Exception as e:
            print(f"   ⚠️  Warning: {e}")

    # Load data into PostgreSQL
    print(f"\n💾 Loading data into PostgreSQL...")
    print(f"   Reference table: {args.ref_table}")
    print(f"   Current table: {args.cur_table}")

    try:
        # Load reference data
        reference_df.to_sql(
            args.ref_table,
            engine,
            if_exists="replace",
            index=False,
            method="multi",
        )
        print(f"   ✅ Loaded {len(reference_df)} rows into '{args.ref_table}'")

        # Load current data
        current_df.to_sql(
            args.cur_table,
            engine,
            if_exists="replace",
            index=False,
            method="multi",
        )
        print(f"   ✅ Loaded {len(current_df)} rows into '{args.cur_table}'")

    except Exception as e:
        print(f"   ❌ Failed to load data: {e}")
        sys.exit(1)

    # Verify data
    print(f"\n🔍 Verifying data...")
    try:
        with engine.connect() as conn:
            ref_count = conn.execute(
                text(f'SELECT COUNT(*) FROM "{args.ref_table}"')
            ).scalar()
            cur_count = conn.execute(
                text(f'SELECT COUNT(*) FROM "{args.cur_table}"')
            ).scalar()

        print(f"   ✅ '{args.ref_table}': {ref_count} rows")
        print(f"   ✅ '{args.cur_table}': {cur_count} rows")

    except Exception as e:
        print(f"   ⚠️  Verification warning: {e}")

    # Print summary
    print(f"\n" + "=" * 60)
    print("✅ SUCCESS!")
    print("=" * 60)
    print(f"\nYou can now use these tables in the dashboard:")
    print(f"  - Reference table: {args.ref_table}")
    print(f"  - Current table: {args.cur_table}")
    print(f"\nConnection details:")
    print(f"  - Host: {args.host}")
    print(f"  - Port: {args.port}")
    print(f"  - Database: {args.database}")
    print(f"  - User: {args.user}")
    print(f"\nNext steps:")
    print(f"  1. Run: python app.py")
    print(f"  2. Select 'PostgreSQL' as data source")
    print(f"  3. Enter connection details")
    print(f"  4. Click 'Test Connection'")
    print(f"  5. Select '{args.ref_table}' and '{args.cur_table}'")
    print(f"  6. Click 'Fetch data + Compute'")
    print()


if __name__ == "__main__":
    main()
