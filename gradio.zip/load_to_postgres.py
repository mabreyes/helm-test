#!/usr/bin/env python3
"""
Load synthetic drift monitoring data into PostgreSQL.

This script follows DDD/SRP architecture by separating concerns:
- PostgresLoader: Single responsibility for database operations
- CLI orchestration: Coordinates the use case
"""

import argparse
import sys

from monitor.infrastructure import (
    PostgresConnectionConfig,
    PostgresRepository,
    SyntheticDataGenerator,
)


class PostgresDataLoaderApplication:
    """
    Application service: Load drift monitoring data to PostgreSQL.

    Single Responsibility: Orchestrate the data loading use case.
    """

    def __init__(
        self,
        repository: PostgresRepository,
        generator: SyntheticDataGenerator,
    ):
        """
        Initialize with dependencies.

        Args:
            repository: PostgreSQL repository
            generator: Synthetic data generator
        """
        self._repository = repository
        self._generator = generator

    def load_synthetic_data(
        self,
        reference_n: int,
        current_n: int,
        drift_strength: float,
        ref_table: str,
        cur_table: str,
        drop_existing: bool = False,
    ) -> tuple[int, int]:
        """
        Generate and load synthetic data to PostgreSQL.

        Single Responsibility: Orchestrate the complete workflow.

        Args:
            reference_n: Number of reference samples
            current_n: Number of current samples
            drift_strength: Drift magnitude
            ref_table: Reference table name
            cur_table: Current table name
            drop_existing: Whether to drop existing tables

        Returns:
            Tuple of (ref_row_count, cur_row_count)
        """
        # Generate data
        reference_df, current_df = self._generator.generate(
            reference_n=reference_n,
            current_n=current_n,
            drift_strength=drift_strength,
        )

        # Drop existing tables if requested
        if drop_existing:
            self._repository.drop_table_if_exists(ref_table)
            self._repository.drop_table_if_exists(cur_table)

        # Load data
        self._repository.load_dataframe(reference_df, ref_table)
        self._repository.load_dataframe(current_df, cur_table)

        # Verify
        ref_count = self._repository.get_table_count(ref_table)
        cur_count = self._repository.get_table_count(cur_table)

        return ref_count, cur_count


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="Generate synthetic data and load into PostgreSQL")

    # Database connection arguments
    parser.add_argument("--host", default="localhost", help="PostgreSQL host")
    parser.add_argument("--port", type=int, default=5432, help="PostgreSQL port")
    parser.add_argument("--database", required=True, help="Database name")
    parser.add_argument("--user", default="postgres", help="Database user")
    parser.add_argument("--password", required=True, help="Database password")

    # Data generation arguments
    parser.add_argument("--ref-n", type=int, default=2000, help="Reference rows")
    parser.add_argument("--cur-n", type=int, default=2000, help="Current rows")
    parser.add_argument(
        "--drift-strength", type=float, default=0.3, help="Drift strength (0.0-1.0)"
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed")

    # Table names
    parser.add_argument("--ref-table", default="reference_data", help="Reference table name")
    parser.add_argument("--cur-table", default="current_data", help="Current table name")

    # Options
    parser.add_argument("--drop-existing", action="store_true", help="Drop tables if they exist")

    args = parser.parse_args()

    print("=" * 60)
    print("PostgreSQL Data Loader - Drift Monitoring")
    print("=" * 60)

    # Create configuration
    config = PostgresConnectionConfig(
        host=args.host,
        port=args.port,
        database=args.database,
        user=args.user,
        password=args.password,
    )

    # Initialize services
    print("\n📊 Generating synthetic data...")
    print(f"   Reference rows: {args.ref_n}")
    print(f"   Current rows: {args.cur_n}")
    print(f"   Drift strength: {args.drift_strength}")
    print(f"   Seed: {args.seed}")

    generator = SyntheticDataGenerator(seed=args.seed)
    repository = PostgresRepository(config)

    # Test connection
    print("\n🔌 Connecting to PostgreSQL...")
    print(f"   Host: {args.host}:{args.port}")
    print(f"   Database: {args.database}")
    print(f"   User: {args.user}")

    status, _ = repository.test_connection()
    if "failed" in status.lower():
        print(f"   ❌ {status}")
        sys.exit(1)
    print(f"   ✅ {status}")

    # Create application service and execute
    app = PostgresDataLoaderApplication(repository, generator)

    print("\n💾 Loading data into PostgreSQL...")
    print(f"   Reference table: {args.ref_table}")
    print(f"   Current table: {args.cur_table}")

    if args.drop_existing:
        print("   🗑️ Dropping existing tables...")

    try:
        ref_count, cur_count = app.load_synthetic_data(
            reference_n=args.ref_n,
            current_n=args.cur_n,
            drift_strength=args.drift_strength,
            ref_table=args.ref_table,
            cur_table=args.cur_table,
            drop_existing=args.drop_existing,
        )

        print(f"   ✅ Loaded {ref_count} rows into '{args.ref_table}'")
        print(f"   ✅ Loaded {cur_count} rows into '{args.cur_table}'")

    except Exception as e:
        print(f"   ❌ Failed to load data: {e}")
        sys.exit(1)

    # Print summary
    print("\n" + "=" * 60)
    print("✅ SUCCESS!")
    print("=" * 60)
    print("\nYou can now use these tables in the dashboard:")
    print(f"  - Reference table: {args.ref_table}")
    print(f"  - Current table: {args.cur_table}")
    print("\nConnection details:")
    print(f"  - Host: {args.host}")
    print(f"  - Port: {args.port}")
    print(f"  - Database: {args.database}")
    print(f"  - User: {args.user}")
    print("\nNext steps:")
    print("  1. Run: python app.py")
    print("  2. Select 'PostgreSQL' as data source")
    print("  3. Enter connection details")
    print("  4. Click 'Test Connection'")
    print(f"  5. Select '{args.ref_table}' and '{args.cur_table}'")
    print("  6. Click 'Fetch data + Compute'")
    print()


if __name__ == "__main__":
    main()
