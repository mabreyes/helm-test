"""
Dashboard Module - ML Model Drift Detection Dashboard

A professional dashboard system built with Domain-Driven Design (DDD)
and Single Responsibility Principle (SRP) for visualizing drift analysis results.

Architecture Layers:
-------------------
- domain: Core dashboard business logic and models
- application: Use case orchestration for dashboard operations
- infrastructure: UI framework integration and external systems
- presentation: UI components and visualizations

Quick Start:
-----------
>>> from dashboard.application import DashboardApplicationService
>>> from dashboard.infrastructure import GradioDashboardBuilder
>>>
>>> # Create dashboard
>>> builder = GradioDashboardBuilder()
>>> app = builder.build_dashboard()
>>> app.launch()
"""

__version__ = "1.0.0"

# Application Layer
from .application.dashboard_service import DashboardApplicationService

# Infrastructure Layer
from .infrastructure.gradio_builder import GradioDashboardBuilder

# Presentation Layer
from .presentation.components import (
    MetricCardBuilder,
    DashboardComponentBuilder,
)

# Visualizations
from .presentation.visualizations import (
    plot_categorical_distributions,
    plot_chi_square_contributions,
    plot_euclidean_categorical,
    plot_jensen_shannon_categorical,
    plot_numeric_distributions,
    plot_numeric_ecdf,
    plot_wasserstein_distance,
)

__all__ = [
    # Version
    "__version__",
    # Application
    "DashboardApplicationService",
    # Infrastructure
    "GradioDashboardBuilder",
    # Presentation - Components
    "MetricCardBuilder",
    "DashboardComponentBuilder",
    # Presentation - Visualizations
    "plot_categorical_distributions",
    "plot_numeric_distributions",
    "plot_numeric_ecdf",
    "plot_chi_square_contributions",
    "plot_wasserstein_distance",
    "plot_jensen_shannon_categorical",
    "plot_euclidean_categorical",
]
