"""
Dashboard Application Service

Single Responsibility: Orchestrate dashboard use cases and coordinate between domain and infrastructure.
This service implements the business logic for dashboard workflows.
"""

from __future__ import annotations

from ..domain.models import DashboardState, FilterState, MetricCard, PlotConfiguration
from ..presentation.components import DashboardComponentBuilder, MetricCardBuilder


class DashboardApplicationService:
    """
    Application Service: Orchestrate dashboard use cases.

    Single Responsibility: Coordinate dashboard business logic and infrastructure.

    This service implements the use cases:
    - "As a data scientist, I want to view drift analysis metrics"
    - "As a data scientist, I want to filter and explore results"
    - "As a data scientist, I want to visualize drift patterns"
    """

    def __init__(self):
        """Initialize the dashboard service."""
        self._current_state = DashboardState()

    def create_metrics_from_analysis(
        self,
        total_features: int,
        drifted_features: int,
        stable_features: int,
        numerical_features: int,
        categorical_features: int,
        critical_drift: int,
        total_tests: int,
        avg_p_value: float,
        max_statistic: float,
        ref_samples: int,
        cur_samples: int,
        total_data_points: int,
    ) -> list[MetricCard]:
        """
        Create metric cards from drift analysis results.

        Single Responsibility: Transform analysis results into dashboard metrics.

        Args:
            total_features: Total number of features analyzed
            drifted_features: Number of features with drift
            stable_features: Number of stable features
            numerical_features: Number of numerical features
            categorical_features: Number of categorical features
            critical_drift: Number of features with critical drift
            total_tests: Total number of tests performed
            avg_p_value: Average p-value across tests
            max_statistic: Maximum test statistic
            ref_samples: Reference dataset sample count
            cur_samples: Current dataset sample count
            total_data_points: Total data points processed

        Returns:
            List of MetricCard objects
        """
        # Calculate percentages
        pct_drifted = 100.0 * drifted_features / max(total_features, 1)

        # Create metric cards
        metrics = []

        # Core metrics
        metrics.append(
            MetricCardBuilder.create_card(
                "Total Features", str(total_features), "Features analyzed", "blue"
            )
        )

        # Drift metrics with color coding
        drift_color = "red" if pct_drifted > 50 else ("purple" if pct_drifted > 20 else "green")
        metrics.append(
            MetricCardBuilder.create_card(
                "Features with Drift",
                str(drifted_features),
                f"{stable_features} features stable",
                drift_color,
            )
        )

        rate_color = "red" if pct_drifted > 50 else ("purple" if pct_drifted > 20 else "green")
        metrics.append(
            MetricCardBuilder.create_card(
                "Drift Rate",
                f"{pct_drifted:.1f}%",
                "Threshold: KS/Chi-square uses alpha",
                rate_color,
            )
        )

        # Feature type metrics
        metrics.append(
            MetricCardBuilder.create_card(
                "Stable Features",
                str(stable_features),
                "No drift detected",
                "green" if stable_features > 0 else "blue",
            )
        )

        metrics.append(
            MetricCardBuilder.create_card(
                "Numerical Features", str(numerical_features), "Continuous variables", "blue"
            )
        )

        metrics.append(
            MetricCardBuilder.create_card(
                "Categorical Features", str(categorical_features), "Discrete variables", "blue"
            )
        )

        # Critical drift metric
        critical_color = "red" if critical_drift > 0 else "green"
        metrics.append(
            MetricCardBuilder.create_card(
                "Critical Drift",
                str(critical_drift),
                "Features with 2+ failed tests",
                critical_color,
            )
        )

        # Test metrics
        metrics.append(
            MetricCardBuilder.create_card(
                "Total Tests Run", str(total_tests), "Statistical tests performed", "blue"
            )
        )

        # Statistical metrics with color coding
        pval_color = "red" if avg_p_value < 0.05 else ("purple" if avg_p_value < 0.1 else "green")
        metrics.append(
            MetricCardBuilder.create_card(
                "Avg P-Value", f"{avg_p_value:.4f}", "Significance tests only", pval_color
            )
        )

        stat_color = "red" if max_statistic > 1.0 else "blue"
        metrics.append(
            MetricCardBuilder.create_card(
                "Max Statistic", f"{max_statistic:.4f}", "Largest test statistic", stat_color
            )
        )

        # Data volume metrics
        metrics.append(
            MetricCardBuilder.create_card(
                "Reference Samples", str(ref_samples), "Baseline dataset size", "blue"
            )
        )

        metrics.append(
            MetricCardBuilder.create_card(
                "Current Samples", str(cur_samples), "Current dataset size", "blue"
            )
        )

        metrics.append(
            MetricCardBuilder.create_card(
                "Total Data Points", str(total_data_points), "All data processed", "blue"
            )
        )

        return metrics

    def update_filter_state(
        self, feature_filter: list[str], type_filter: list[str], test_filter: list[str]
    ) -> FilterState:
        """
        Update the dashboard filter state.

        Single Responsibility: Manage filter state transitions.

        Args:
            feature_filter: Selected features
            type_filter: Selected types
            test_filter: Selected tests

        Returns:
            Updated FilterState
        """
        new_filter_state = DashboardComponentBuilder.create_filter_state(
            feature_filter, type_filter, test_filter
        )
        self._current_state = self._current_state.update_filters(new_filter_state)
        return new_filter_state

    def create_plot_configuration(
        self, plot_type: str, bins: int = 40, feature: str | None = None
    ) -> PlotConfiguration:
        """
        Create plot configuration for visualization.

        Single Responsibility: Configure plot rendering parameters.

        Args:
            plot_type: Type of plot to render
            bins: Number of bins for histograms
            feature: Feature to plot (if applicable)

        Returns:
            PlotConfiguration object
        """
        config = PlotConfiguration(plot_type=plot_type, bins=bins, feature=feature)
        config.validate()
        self._current_state = self._current_state.update_plot_config(config)
        return config

    def get_current_state(self) -> DashboardState:
        """Get the current dashboard state."""
        return self._current_state

    def update_state_with_metrics(self, metrics: list[MetricCard]) -> DashboardState:
        """
        Update dashboard state with new metrics.

        Single Responsibility: Update state while maintaining immutability.

        Args:
            metrics: New metric cards

        Returns:
            Updated DashboardState
        """
        self._current_state = self._current_state.update_metrics(metrics)
        return self._current_state

    def get_filtered_tests(self, selected_types: list[str], all_tests: list[str]) -> list[str]:
        """
        Get test names for selected feature types.

        Single Responsibility: Apply filter logic to test selection.

        Args:
            selected_types: Selected feature types
            all_tests: All available tests

        Returns:
            Filtered list of test names
        """
        return DashboardComponentBuilder.get_tests_for_types(selected_types, all_tests)
