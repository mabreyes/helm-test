"""
Dashboard Application Layer

Use case orchestration for dashboard operations.
"""
