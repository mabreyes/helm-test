from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy.spatial.distance import jensenshannon
from scipy.stats import wasserstein_distance

from .theme import BRAND_COLORWAY, SC_DARK_BLUE, SC_LOGO_BLUE, SC_LOGO_GREEN

APPLE_FONT_STACK = "-apple-system, BlinkMacSystemFont, 'SF Pro Text','SF Pro Display','Helvetica Neue',Helvetica,Arial,'Apple Color Emoji','Segoe UI',Roboto,'Noto Sans','Liberation Sans',sans-serif"


def plot_numeric_distributions(
    ref: pd.Series,
    cur: pd.Series,
    bins: int = 40,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    fig = go.Figure()
    if len(ref_clean) > 0:
        fig.add_trace(
            go.Histogram(
                x=ref_clean,
                nbinsx=bins,
                name=ref_name,
                opacity=0.6,
                histnorm="probability",
                marker_color=SC_LOGO_BLUE,
            )
        )
    if len(cur_clean) > 0:
        fig.add_trace(
            go.Histogram(
                x=cur_clean,
                nbinsx=bins,
                name=cur_name,
                opacity=0.6,
                histnorm="probability",
                marker_color=SC_LOGO_GREEN,
            )
        )

    fig.update_layout(
        title="Probability Distribution (Histogram)<br><sub>Compare probability densities between reference and current datasets</sub>",
        barmode="overlay",
        xaxis_title="Value",
        yaxis_title="Probability",
        legend_title="Dataset",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
    )
    return fig


def plot_categorical_distributions(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    cur_counts = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=categories,
            y=ref_counts.values,
            name=ref_name,
            opacity=0.8,
            marker_color=SC_LOGO_BLUE,
        )
    )
    fig.add_trace(
        go.Bar(
            x=categories,
            y=cur_counts.values,
            name=cur_name,
            opacity=0.8,
            marker_color=SC_LOGO_GREEN,
        )
    )

    fig.update_layout(
        title="Category Proportions<br><sub>Compare category distributions between reference and current datasets</sub>",
        barmode="group",
        xaxis_title="Category",
        yaxis_title="Proportion",
        legend_title="Dataset",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
    )
    return fig


def plot_numeric_binned_probs(
    ref: pd.Series,
    cur: pd.Series,
    bins: int = 40,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 and len(cur_clean) == 0:
        return go.Figure()

    combined = np.concatenate(
        [
            ref_clean.values if len(ref_clean) else np.array([], dtype=float),
            cur_clean.values if len(cur_clean) else np.array([], dtype=float),
        ]
    )
    # Fallback single edge if everything empty
    if combined.size == 0:
        combined = np.array([0.0, 1.0])

    bin_edges = np.histogram_bin_edges(combined, bins=bins)
    ref_counts, _ = np.histogram(
        ref_clean.values if len(ref_clean) else np.array([], dtype=float),
        bins=bin_edges,
    )
    cur_counts, _ = np.histogram(
        cur_clean.values if len(cur_clean) else np.array([], dtype=float),
        bins=bin_edges,
    )

    def _normalize(counts: np.ndarray) -> np.ndarray:
        total = float(np.sum(counts))
        return (counts.astype(float) / total) if total > 0 else np.zeros_like(counts, dtype=float)

    p = _normalize(ref_counts)
    q = _normalize(cur_counts)
    centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0
    abs_diff = np.abs(q - p)

    fig = go.Figure()
    fig.add_trace(go.Bar(x=centers, y=p, name=ref_name, opacity=0.7, marker_color=SC_LOGO_BLUE))
    fig.add_trace(go.Bar(x=centers, y=q, name=cur_name, opacity=0.7, marker_color=SC_LOGO_GREEN))
    fig.add_trace(
        go.Scatter(
            x=centers,
            y=abs_diff,
            mode="lines",
            name="|Δ| (current - reference)",
            line={"dash": "dot", "width": 2, "color": SC_DARK_BLUE},
        )
    )

    fig.update_layout(
        title="Binned Probabilities (PSI Computation)<br><sub>Fixed bins used for PSI calculation - shows per-bin probability differences</sub>",
        barmode="overlay",
        xaxis_title="Value",
        yaxis_title="Probability",
        legend_title="Dataset",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
    )
    return fig


def plot_categorical_difference(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_probs = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    cur_probs = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    diff = (cur_probs - ref_probs).values
    colors = [SC_LOGO_GREEN if d >= 0 else "crimson" for d in diff]

    fig = go.Figure()
    fig.add_trace(
        go.Bar(x=categories, y=diff, marker_color=colors, name=f"Δ {cur_name}-{ref_name}")
    )

    fig.update_layout(
        title="Category Probability Shift<br><sub>Green bars show proportion increase, red bars show decrease from reference to current</sub>",
        xaxis_title="Category",
        yaxis_title="Probability difference",
        legend_title="Legend",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
    )
    return fig


def plot_chi_square_contributions(
    ref: pd.Series,
    cur: pd.Series,
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts().reindex(categories, fill_value=0)
    cur_counts = cur.value_counts().reindex(categories, fill_value=0)

    contingency = np.vstack([ref_counts.values, cur_counts.values]).astype(float)
    n_total = contingency.sum()
    if n_total <= 0:
        return go.Figure()
    row_sums = contingency.sum(axis=1, keepdims=True)
    col_sums = contingency.sum(axis=0, keepdims=True)
    expected = row_sums @ (col_sums / n_total)
    with np.errstate(divide="ignore", invalid="ignore"):
        contrib = (contingency - expected) ** 2 / np.where(expected > 0, expected, 1.0)
    per_category_contrib = contrib.sum(axis=0)

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=categories,
            y=per_category_contrib,
            name="Chi-square contribution",
            marker_color=SC_LOGO_BLUE,
        )
    )
    fig.update_layout(
        title="Chi-Square Test Contributions by Category<br><sub>Shows which categories contribute most to the Chi-square statistic</sub>",
        xaxis_title="Category",
        yaxis_title="Contribution",
        legend_title="Legend",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
    )
    return fig


def plot_numeric_ecdf(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    fig = go.Figure()

    if len(ref_clean) > 0:
        x_ref = ref_clean.sort_values().values
        y_ref = (pd.Series(range(1, len(x_ref) + 1)) / len(x_ref)).values
        fig.add_trace(
            go.Scatter(
                x=x_ref,
                y=y_ref,
                mode="lines",
                name=ref_name,
                line={"width": 2, "color": SC_LOGO_BLUE},
                line_shape="hv",
            )
        )

    if len(cur_clean) > 0:
        x_cur = cur_clean.sort_values().values
        y_cur = (pd.Series(range(1, len(x_cur) + 1)) / len(x_cur)).values
        fig.add_trace(
            go.Scatter(
                x=x_cur,
                y=y_cur,
                mode="lines",
                name=cur_name,
                line={"width": 2, "color": SC_LOGO_GREEN},
                line_shape="hv",
            )
        )

    fig.update_layout(
        title="Empirical Cumulative Distribution Function (ECDF)<br><sub>Used by KS test - maximum vertical distance measures distribution difference</sub>",
        xaxis_title="Value",
        yaxis_title="ECDF",
        legend_title="Dataset",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
    )

    return fig


def plot_wasserstein_distance(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    """
    Visualize Wasserstein distance (Earth-Mover's distance) between two distributions.
    Shows CDFs and highlights the area representing the distance.
    """
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 or len(cur_clean) == 0:
        return go.Figure()

    # Calculate Wasserstein distance
    w_dist = wasserstein_distance(ref_clean.values, cur_clean.values)

    # Create ECDFs
    x_ref = np.sort(ref_clean.values)
    y_ref = np.arange(1, len(x_ref) + 1) / len(x_ref)

    x_cur = np.sort(cur_clean.values)
    y_cur = np.arange(1, len(x_cur) + 1) / len(x_cur)

    # Create merged x-axis for area fill
    x_merged = np.sort(np.concatenate([x_ref, x_cur]))
    y_ref_interp = np.interp(x_merged, x_ref, y_ref, left=0, right=1)
    y_cur_interp = np.interp(x_merged, x_cur, y_cur, left=0, right=1)

    fig = go.Figure()

    # Add shaded area showing the "work" needed to transform one distribution to another
    fig.add_trace(
        go.Scatter(
            x=np.concatenate([x_merged, x_merged[::-1]]),
            y=np.concatenate([y_ref_interp, y_cur_interp[::-1]]),
            fill="toself",
            fillcolor="rgba(4, 115, 234, 0.25)",
            line={"width": 0},
            name="Wasserstein area",
            hoverinfo="skip",
        )
    )

    # Add reference CDF
    fig.add_trace(
        go.Scatter(
            x=x_ref,
            y=y_ref,
            mode="lines",
            name=ref_name,
            line={"width": 3, "color": SC_LOGO_BLUE},
            line_shape="hv",
        )
    )

    # Add current CDF
    fig.add_trace(
        go.Scatter(
            x=x_cur,
            y=y_cur,
            mode="lines",
            name=cur_name,
            line={"width": 3, "color": SC_LOGO_GREEN},
            line_shape="hv",
        )
    )

    fig.update_layout(
        title=f"Wasserstein Distance: {w_dist:.4f}<br><sub>Measures how far distributions moved (Earth-Mover's distance)</sub>",
        xaxis_title="Value",
        yaxis_title="Cumulative Probability",
        legend_title="Dataset",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
        hovermode="x unified",
    )

    return fig


def plot_jensen_shannon_divergence(
    ref: pd.Series,
    cur: pd.Series,
    bins: int = 40,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    """
    Visualize Jensen-Shannon divergence between two distributions.
    Shows probability distributions and their divergence.
    """
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 and len(cur_clean) == 0:
        return go.Figure()

    # Create bins on combined data
    combined = np.concatenate([ref_clean.values, cur_clean.values])
    bin_edges = np.histogram_bin_edges(combined, bins=bins)

    # Get histograms
    ref_counts, _ = np.histogram(ref_clean.values, bins=bin_edges)
    cur_counts, _ = np.histogram(cur_clean.values, bins=bin_edges)

    # Normalize to probabilities with smoothing
    epsilon = 1e-12
    p = (
        ref_counts.astype(float) / ref_counts.sum()
        if ref_counts.sum() > 0
        else np.zeros_like(ref_counts, dtype=float)
    )
    q = (
        cur_counts.astype(float) / cur_counts.sum()
        if cur_counts.sum() > 0
        else np.zeros_like(cur_counts, dtype=float)
    )
    p = p + epsilon
    p = p / p.sum()
    q = q + epsilon
    q = q / q.sum()

    # Calculate Jensen-Shannon distance
    js_dist = float(jensenshannon(p, q))

    # Calculate the mixture (M = (P + Q) / 2)
    m = (p + q) / 2.0

    # Bin centers for plotting
    centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0

    fig = go.Figure()

    # Add reference distribution
    fig.add_trace(
        go.Bar(
            x=centers,
            y=p,
            name=ref_name,
            opacity=0.7,
            marker_color=SC_LOGO_BLUE,
        )
    )

    # Add current distribution
    fig.add_trace(
        go.Bar(
            x=centers,
            y=q,
            name=cur_name,
            opacity=0.7,
            marker_color=SC_LOGO_GREEN,
        )
    )

    # Add mixture distribution
    fig.add_trace(
        go.Scatter(
            x=centers,
            y=m,
            mode="lines",
            name="Mixture M = (P+Q)/2",
            line={"width": 3, "color": SC_LOGO_GREEN, "dash": "dash"},
        )
    )

    # Add divergence indicators
    divergence = np.maximum(np.abs(p - m), np.abs(q - m))
    fig.add_trace(
        go.Scatter(
            x=centers,
            y=divergence,
            mode="lines",
            name="Max divergence from M",
            line={"width": 2, "color": "red", "dash": "dot"},
            yaxis="y2",
        )
    )

    fig.update_layout(
        title=f"Jensen-Shannon Distance: {js_dist:.4f}<br><sub>Symmetric bounded measure of distribution difference (0=identical, 1=completely different)</sub>",
        xaxis_title="Value",
        yaxis_title="Probability",
        yaxis2={
            "title": "Divergence",
            "overlaying": "y",
            "side": "right",
            "showgrid": False,
        },
        legend_title="Component",
        barmode="overlay",
        margin={"l": 10, "r": 60, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
        hovermode="x unified",
    )

    return fig


def plot_jensen_shannon_categorical(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    """
    Visualize Jensen-Shannon divergence for categorical features.
    Shows probability distributions and their divergence.
    """
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts().reindex(categories, fill_value=0)
    cur_counts = cur.value_counts().reindex(categories, fill_value=0)

    # Normalize to probabilities with smoothing
    epsilon = 1e-12
    p = ref_counts.values.astype(float) / ref_counts.sum()
    q = cur_counts.values.astype(float) / cur_counts.sum()
    p = p + epsilon
    p = p / p.sum()
    q = q + epsilon
    q = q / q.sum()

    # Calculate Jensen-Shannon distance
    js_dist = float(jensenshannon(p, q))

    # Calculate the mixture
    m = (p + q) / 2.0

    # Calculate KL divergences for each category
    kl_p_m = p * np.log2(p / m)
    kl_q_m = q * np.log2(q / m)

    fig = go.Figure()

    # Add reference distribution
    fig.add_trace(
        go.Bar(
            x=categories,
            y=p,
            name=ref_name,
            opacity=0.7,
            marker_color=SC_LOGO_BLUE,
        )
    )

    # Add current distribution
    fig.add_trace(
        go.Bar(
            x=categories,
            y=q,
            name=cur_name,
            opacity=0.7,
            marker_color=SC_LOGO_GREEN,
        )
    )

    # Add mixture distribution
    fig.add_trace(
        go.Scatter(
            x=categories,
            y=m,
            mode="markers+lines",
            name="Mixture M = (P+Q)/2",
            line={"width": 3, "color": SC_LOGO_GREEN, "dash": "dash"},
            marker={"size": 10, "symbol": "diamond"},
        )
    )

    # Add per-category contribution to JS divergence
    contribution = (kl_p_m + kl_q_m) / 2.0
    fig.add_trace(
        go.Bar(
            x=categories,
            y=contribution,
            name="JS contribution",
            marker_color="rgba(255, 0, 0, 0.3)",
            yaxis="y2",
        )
    )

    fig.update_layout(
        title=f"Jensen-Shannon Distance: {js_dist:.4f}<br><sub>Symmetric bounded measure of distribution difference (0=identical, ~0.69=completely different)</sub>",
        xaxis_title="Category",
        yaxis_title="Probability",
        yaxis2={
            "title": "JS Contribution",
            "overlaying": "y",
            "side": "right",
            "showgrid": False,
        },
        legend_title="Component",
        barmode="overlay",
        margin={"l": 10, "r": 80, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
    )

    return fig


def plot_euclidean_categorical(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    """
    Visualize Euclidean distance (L2 norm) for categorical features as vectors.
    Shows probability vectors as arrows from origin and the distance between them.
    """
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_probs = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    cur_probs = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)

    # Calculate Euclidean distance
    euclidean_dist = float(np.sqrt(np.sum((ref_probs.values - cur_probs.values) ** 2)))

    # For visualization, we'll show this as vectors in 2D space
    # We'll use the first two categories as x,y coordinates (or pad if only 1 category)
    n_cats = len(categories)

    if n_cats == 0:
        return go.Figure()

    # Create coordinate representation
    # For 2+ categories, use first two as x,y; for 1 category, use x-axis only
    if n_cats >= 2:
        ref_x, ref_y = ref_probs.values[0], ref_probs.values[1]
        cur_x, cur_y = cur_probs.values[0], cur_probs.values[1]
        other_label = f" (+{n_cats - 2} more dims)" if n_cats > 2 else ""
    else:
        ref_x, ref_y = ref_probs.values[0], 0.0
        cur_x, cur_y = cur_probs.values[0], 0.0
        other_label = ""

    fig = go.Figure()

    # Add reference vector (arrow from origin)
    fig.add_trace(
        go.Scatter(
            x=[0, ref_x],
            y=[0, ref_y],
            mode="lines+markers",
            name=f"{ref_name} vector",
            line={"width": 8, "color": SC_LOGO_BLUE},
            marker={"size": [0, 15], "symbol": ["circle", "arrow"], "angleref": "previous"},
            hovertemplate=f"<b>{ref_name}</b><br>x: %{{x:.3f}}<br>y: %{{y:.3f}}<extra></extra>",
        )
    )

    # Add current vector (arrow from origin)
    fig.add_trace(
        go.Scatter(
            x=[0, cur_x],
            y=[0, cur_y],
            mode="lines+markers",
            name=f"{cur_name} vector",
            line={"width": 8, "color": SC_LOGO_GREEN},
            marker={"size": [0, 15], "symbol": ["circle", "arrow"], "angleref": "previous"},
            hovertemplate=f"<b>{cur_name}</b><br>x: %{{x:.3f}}<br>y: %{{y:.3f}}<extra></extra>",
        )
    )

    # Add distance line between vector endpoints
    fig.add_trace(
        go.Scatter(
            x=[ref_x, cur_x],
            y=[ref_y, cur_y],
            mode="lines",
            name=f"L2 distance: {euclidean_dist:.4f}",
            line={"width": 3, "color": "red", "dash": "dash"},
            hovertemplate=f"Distance: {euclidean_dist:.4f}<extra></extra>",
        )
    )

    # Add origin point
    fig.add_trace(
        go.Scatter(
            x=[0],
            y=[0],
            mode="markers",
            name="Origin",
            marker={"size": 12, "color": "black", "symbol": "circle"},
            hovertemplate="Origin<extra></extra>",
        )
    )

    # Add shaded triangle showing the distance
    fig.add_trace(
        go.Scatter(
            x=[0, ref_x, cur_x, 0],
            y=[0, ref_y, cur_y, 0],
            fill="toself",
            fillcolor="rgba(255, 0, 0, 0.1)",
            line={"width": 0},
            name="Distance area",
            hoverinfo="skip",
            showlegend=False,
        )
    )

    # Set axis ranges to be symmetric and include some padding
    max_val = max(abs(ref_x), abs(ref_y), abs(cur_x), abs(cur_y), 0.1) * 1.2

    fig.update_layout(
        title=f"Euclidean Distance (L2 Norm): {euclidean_dist:.4f}{other_label}<br><sub>Geometric distance between probability vectors in {n_cats}-D space (showing first 2 dimensions)</sub>",
        xaxis={
            "title": f"P({categories[0]})" if n_cats >= 1 else "Dimension 1",
            "range": [-0.05, max_val],
            "zeroline": True,
            "zerolinewidth": 2,
            "zerolinecolor": "lightgray",
        },
        yaxis={
            "title": f"P({categories[1]})" if n_cats >= 2 else "Dimension 2",
            "range": [-0.05, max_val],
            "zeroline": True,
            "zerolinewidth": 2,
            "zerolinecolor": "lightgray",
            "scaleanchor": "x",
            "scaleratio": 1,
        },
        legend_title="Component",
        margin={"l": 10, "r": 10, "t": 80, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
        hovermode="closest",
    )

    return fig


def plot_drift_trend(
    trend_df: pd.DataFrame,
    value_col: str = "drift_rate",
    title: str = "Drift Trend Over Time",
    include_aggregate: bool = False,
) -> go.Figure:
    """
    Plot drift trendline over time with one series per feature/test.

    Expects DataFrame columns: ['bucket', 'feature', 'test', value_col]
    """
    if trend_df is None or len(trend_df) == 0:
        return go.Figure()

    df = trend_df.copy()
    df = df.sort_values("bucket")
    df["series"] = df["feature"].astype(str) + " / " + df["test"].astype(str)

    fig = go.Figure()
    for series_name, sub in df.groupby("series", sort=True):
        fig.add_trace(
            go.Scatter(
                x=sub["bucket"],
                y=sub[value_col],
                mode="lines+markers",
                name=series_name,
                line={"width": 2},
                marker={"size": 6},
            )
        )

    # Optional aggregate line across all series (weighted by n if present)
    if include_aggregate and "bucket" in df.columns:
        if "n" in df.columns:
            agg = (
                df.groupby("bucket").apply(
                    lambda g: (g[value_col] * g["n"]).sum() / g["n"].sum()
                    if g["n"].sum() > 0
                    else g[value_col].mean()
                )
            ).reset_index(name=value_col)
        else:
            agg = df.groupby("bucket")[value_col].mean().reset_index()
        fig.add_trace(
            go.Scatter(
                x=agg["bucket"],
                y=agg[value_col],
                mode="lines",
                name="All selected",
                line={"width": 3, "color": SC_DARK_BLUE},
            )
        )

    fig.update_layout(
        title=f"{title}<br><sub>Each line = feature / test; value = {value_col}</sub>",
        xaxis_title="Time",
        yaxis_title="Drift rate" if value_col == "drift_rate" else value_col,
        legend_title="Series",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
        hovermode="x unified",
    )
    return fig


def plot_metric_value_trend(
    trend_df: pd.DataFrame,
    metric_col: str,
    threshold_col: str | None = "avg_threshold",
    title: str | None = None,
    show_thresholds: bool = True,
    include_aggregate: bool = False,
) -> go.Figure:
    """
    Plot time-series trend of a metric (statistic, p_value, effect_size) with optional threshold lines.

    Expects columns: ['bucket','feature','test', metric_col] and optionally threshold_col.
    """
    if trend_df is None or len(trend_df) == 0 or metric_col not in trend_df.columns:
        return go.Figure()

    df = trend_df.copy().sort_values("bucket")
    df["series"] = df["feature"].astype(str) + " / " + df["test"].astype(str)

    fig = go.Figure()
    for series_name, sub in df.groupby("series", sort=True):
        # Metric line
        fig.add_trace(
            go.Scatter(
                x=sub["bucket"],
                y=sub[metric_col],
                mode="lines+markers",
                name=series_name,
                line={"width": 2},
                marker={"size": 6},
                hovertemplate=(
                    "%{x|%Y-%m-%d %H:%M}<br>"
                    + f"{series_name}<br>"
                    + f"{metric_col}: %{{y:.4f}}"
                    + (
                        "<br>threshold: %{customdata[0]:.4f}<br>%{customdata[1]}"
                        if show_thresholds and threshold_col and threshold_col in sub.columns
                        else ""
                    )
                    + "<extra></extra>"
                ),
                customdata=(
                    sub[[threshold_col]]
                    .assign(
                        rule=sub["test"].apply(
                            lambda t: "drift if p < threshold (alpha)"
                            if str(t).lower() in {"ks", "chi-square", "chi_square"}
                            else "drift if value >= threshold"
                        )
                    )
                    .values
                    if show_thresholds and threshold_col and threshold_col in sub.columns
                    else None
                ),
            )
        )
        # Threshold line per series (if available)
        if (
            show_thresholds
            and threshold_col
            and threshold_col in sub.columns
            and sub[threshold_col].notna().any()
        ):
            fig.add_trace(
                go.Scatter(
                    x=sub["bucket"],
                    y=sub[threshold_col],
                    mode="lines",
                    name=f"{series_name} threshold",
                    line={"width": 1.5, "dash": "dash", "color": SC_DARK_BLUE},
                    hoverinfo="skip",
                    showlegend=False,
                )
            )

    # Optional aggregate across all selected series
    if include_aggregate and "bucket" in df.columns:
        if "n" in df.columns:
            agg = (
                df.groupby("bucket").apply(
                    lambda g: (g[metric_col] * g["n"]).sum() / g["n"].sum()
                    if g["n"].sum() > 0
                    else g[metric_col].mean()
                )
            ).reset_index(name=metric_col)
        else:
            agg = df.groupby("bucket")[metric_col].mean().reset_index()
        fig.add_trace(
            go.Scatter(
                x=agg["bucket"],
                y=agg[metric_col],
                mode="lines",
                name="All selected",
                line={"width": 3, "color": SC_DARK_BLUE},
            )
        )

    fig.update_layout(
        title=(title or f"{metric_col} Trend Over Time")
        + "<br><sub>Each line = feature / test</sub>",
        xaxis_title="Time",
        yaxis_title=metric_col,
        legend_title="Series",
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
        hovermode="x unified",
    )
    return fig


def plot_metric_value_trend_by_test(
    trend_df: pd.DataFrame,
    metric_col: str,
    threshold_col: str | None = "avg_threshold",
    show_thresholds: bool = True,
    title: str | None = None,
) -> go.Figure:
    """
    Faceted time-series: one subplot per test with series per feature.

    Expects columns: ['bucket','feature','test', metric_col] and optional threshold_col.
    """
    if trend_df is None or len(trend_df) == 0 or metric_col not in trend_df.columns:
        return go.Figure()

    df = trend_df.copy().sort_values(["test", "bucket"])  # preserve test order
    tests = list(df["test"].astype(str).unique())
    if not tests:
        return go.Figure()

    fig = make_subplots(
        rows=len(tests),
        cols=1,
        shared_xaxes=True,
        vertical_spacing=0.06,
        subplot_titles=[f"{t}" for t in tests],
    )

    for i, t in enumerate(tests, start=1):
        sub = df[df["test"].astype(str) == t].copy()
        sub["series"] = sub["feature"].astype(str)
        for series_name, g in sub.groupby("series", sort=True):
            fig.add_trace(
                go.Scatter(
                    x=g["bucket"],
                    y=g[metric_col],
                    mode="lines+markers",
                    name=series_name if i == 1 else series_name,  # keep names
                    line={"width": 2},
                    marker={"size": 6},
                    hovertemplate=(
                        "%{x|%Y-%m-%d %H:%M}<br>"
                        + f"{t} · {series_name}<br>"
                        + f"{metric_col}: %{{y:.4f}}"
                        + (
                            "<br>threshold: %{customdata[0]:.4f}"
                            if show_thresholds and threshold_col and threshold_col in g.columns
                            else ""
                        )
                        + "<extra></extra>"
                    ),
                    customdata=(
                        g[[threshold_col]].values
                        if show_thresholds and threshold_col and threshold_col in g.columns
                        else None
                    ),
                ),
                row=i,
                col=1,
            )
            # Threshold line (optional)
            if (
                show_thresholds
                and threshold_col
                and threshold_col in g.columns
                and g[threshold_col].notna().any()
            ):
                fig.add_trace(
                    go.Scatter(
                        x=g["bucket"],
                        y=g[threshold_col],
                        mode="lines",
                        name=f"{series_name} threshold" if i == 1 else None,
                        line={"width": 1.2, "dash": "dash", "color": SC_DARK_BLUE},
                        hoverinfo="skip",
                        showlegend=False,
                    ),
                    row=i,
                    col=1,
                )

    fig.update_layout(
        title=(title or f"{metric_col} by Test"),
        margin={"l": 10, "r": 10, "t": 60, "b": 10},
        template="plotly_white",
        colorway=BRAND_COLORWAY,
        font={"family": APPLE_FONT_STACK},
        hovermode="x unified",
        showlegend=False,
    )
    fig.update_xaxes(title_text="Time", row=len(tests), col=1)
    fig.update_yaxes(title_text=metric_col, row=1, col=1)
    return fig
