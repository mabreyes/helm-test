"""
SC Brand Theme Constants

Defines the standardized SC brand colors used across the dashboard.
"""

# SC brand colors
SC_DARK_BLUE = "#020B43"  # Navbar dark blue (rgb(2, 11, 67))
SC_LOGO_BLUE = "#0473EA"  # SC logo blue
SC_LOGO_GREEN = "#38D200"  # SC logo green

# Recommended Plotly color cycle (reference, current, accent)
BRAND_COLORWAY = [SC_LOGO_BLUE, SC_LOGO_GREEN, SC_DARK_BLUE]

__all__ = [
    "SC_DARK_BLUE",
    "SC_LOGO_BLUE",
    "SC_LOGO_GREEN",
    "BRAND_COLORWAY",
]
