"""
Dashboard Presentation Layer

UI components and visualizations for the dashboard.
"""
