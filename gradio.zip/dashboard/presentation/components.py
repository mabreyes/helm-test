"""
Dashboard Components - Presentation Layer

Single Responsibility: Build UI components for the dashboard.
"""

from ..domain.models import FilterState, MetricCard


class MetricCardBuilder:
    """
    Builder for dashboard metric cards.

    Single Responsibility: Create HTML metric cards.
    """

    @staticmethod
    def create_card(label: str, value: str, subtitle: str, color: str = "blue") -> MetricCard:
        """
        Create a metric card with color.

        Args:
            label: Card title
            value: Main metric value
            subtitle: Additional context
            color: Color theme (blue, red, green)

        Returns:
            MetricCard domain object
        """
        return MetricCard(label=label, value=value, subtitle=subtitle, color=color)

    @staticmethod
    def create_empty_cards(count: int = 13) -> list[MetricCard]:
        """
        Create empty dashboard cards with a warning.

        Args:
            count: Number of cards to create

        Returns:
            List of MetricCard objects
        """
        warning_card = MetricCardBuilder.create_card(
            "No Data", "—", "Select a data source below to begin", "blue"
        )
        return [warning_card] * count


class DashboardComponentBuilder:
    """
    Builder for complex dashboard components.

    Single Responsibility: Construct multi-element UI components.
    """

    TESTS_BY_TYPE: dict[str, list[str]] = {
        "numerical": ["ks", "wasserstein", "psi"],
        "categorical": ["chi-square", "jensen-shannon", "euclidean", "psi"],
    }

    @staticmethod
    def get_tests_for_types(selected_types: list[str], all_tests: list[str]) -> list[str]:
        """
        Get test names for selected feature types.

        Args:
            selected_types: List of selected types ("numerical", "categorical")
            all_tests: Fallback list of all test names

        Returns:
            List of test names
        """
        tests: set[str] = set()
        for feature_type in selected_types:
            tests.update(DashboardComponentBuilder.TESTS_BY_TYPE.get(feature_type, []))
        return sorted(tests) or sorted(all_tests)

    @staticmethod
    def format_dataframe_with_styling(df) -> dict:
        """
        Format DataFrame with styling for display.

        Args:
            df: DataFrame to format

        Returns:
            Dictionary with styling information
        """
        # This can be expanded with more sophisticated formatting
        return {"data": df}

    @staticmethod
    def create_filter_state(
        feature_filter: list[str],
        type_filter: list[str],
        test_filter: list[str],
    ) -> FilterState:
        """
        Create a FilterState from individual filter lists.

        Args:
            feature_filter: Selected features
            type_filter: Selected types
            test_filter: Selected tests

        Returns:
            FilterState domain object
        """
        return FilterState(
            feature_filter=feature_filter,
            type_filter=type_filter,
            test_filter=test_filter,
        )
