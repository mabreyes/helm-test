"""
Dashboard Domain Layer

Core business logic and models for the dashboard system.
"""
