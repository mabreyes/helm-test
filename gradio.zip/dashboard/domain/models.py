"""
Dashboard Domain Models - Core business entities

Single Responsibility: Represent core dashboard business concepts and their invariants.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class DashboardSection(str, Enum):
    """Enumeration of dashboard sections."""

    METRICS = "metrics"
    FILTERS = "filters"
    RESULTS = "results"
    PLOTS = "plots"
    DATA_SOURCES = "data_sources"
    SETTINGS = "settings"


@dataclass(frozen=True)
class MetricCard:
    """
    Immutable value object representing a dashboard metric card.

    Single Responsibility: Encapsulate all information about a metric card.
    Domain Concept: A metric card displays a key performance indicator.
    """

    label: str
    value: str
    subtitle: str
    color: str = "blue"
    timestamp: datetime = field(default_factory=datetime.now)

    def to_html(self) -> str:
        """Convert to HTML representation."""
        return f"""
        <div class="dashboard-card {self.color}">
            <div class="metric-label">{self.label}</div>
            <div class="metric-value {self.color}">{self.value}</div>
            <div class="metric-subtitle">{self.subtitle}</div>
        </div>
        """

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "label": self.label,
            "value": self.value,
            "subtitle": self.subtitle,
            "color": self.color,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass(frozen=True)
class FilterState:
    """
    Immutable value object representing dashboard filter state.

    Single Responsibility: Encapsulate all filter selections.
    Domain Concept: The current state of all dashboard filters.
    """

    feature_filter: list[str] = field(default_factory=list)
    type_filter: list[str] = field(default_factory=list)
    test_filter: list[str] = field(default_factory=list)

    def is_empty(self) -> bool:
        """Check if any filters are active."""
        return not any([self.feature_filter, self.type_filter, self.test_filter])

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "feature_filter": self.feature_filter,
            "type_filter": self.type_filter,
            "test_filter": self.test_filter,
        }


@dataclass(frozen=True)
class PlotConfiguration:
    """
    Immutable value object representing plot configuration.

    Single Responsibility: Encapsulate plot rendering parameters.
    Domain Concept: Configuration for visualizing data.
    """

    plot_type: str
    bins: int = 40
    feature: str | None = None
    reference_name: str = "reference"
    current_name: str = "current"

    def validate(self) -> None:
        """Validate plot configuration."""
        if self.bins < 1:
            raise ValueError(f"bins must be positive, got {self.bins}")
        if not self.plot_type:
            raise ValueError("plot_type cannot be empty")


@dataclass(frozen=True)
class DashboardState:
    """
    Immutable aggregate representing the complete dashboard state.

    Single Responsibility: Track and provide access to dashboard state.
    Domain Concept: The complete state of the dashboard at a point in time.
    """

    metrics: tuple[MetricCard, ...] = field(default_factory=tuple)
    filter_state: FilterState = field(default_factory=FilterState)
    plot_config: PlotConfiguration | None = None
    last_updated: datetime = field(default_factory=datetime.now)

    def update_metrics(self, new_metrics: list[MetricCard]) -> DashboardState:
        """
        Update metrics and return new state.

        Single Responsibility: Update metrics while maintaining immutability.
        """
        return DashboardState(
            metrics=tuple(new_metrics),
            filter_state=self.filter_state,
            plot_config=self.plot_config,
            last_updated=datetime.now(),
        )

    def update_filters(self, new_filter_state: FilterState) -> DashboardState:
        """
        Update filter state and return new state.

        Single Responsibility: Update filters while maintaining immutability.
        """
        return DashboardState(
            metrics=self.metrics,
            filter_state=new_filter_state,
            plot_config=self.plot_config,
            last_updated=datetime.now(),
        )

    def update_plot_config(self, new_plot_config: PlotConfiguration) -> DashboardState:
        """
        Update plot configuration and return new state.

        Single Responsibility: Update plot config while maintaining immutability.
        """
        return DashboardState(
            metrics=self.metrics,
            filter_state=self.filter_state,
            plot_config=new_plot_config,
            last_updated=datetime.now(),
        )

    def get_metric_by_label(self, label: str) -> MetricCard | None:
        """Get a metric card by its label."""
        for metric in self.metrics:
            if metric.label == label:
                return metric
        return None

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "metrics": [metric.to_dict() for metric in self.metrics],
            "filter_state": self.filter_state.to_dict(),
            "plot_config": self.plot_config.__dict__ if self.plot_config else None,
            "last_updated": self.last_updated.isoformat(),
        }
