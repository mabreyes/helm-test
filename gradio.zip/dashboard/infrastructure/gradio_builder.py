"""
Gradio Dashboard Builder - Infrastructure Service

Single Responsibility: Build and configure Gradio-based dashboard interface.
This service handles the technical details of UI framework integration.
"""

from __future__ import annotations

from typing import Any, Protocol

import gradio as gr

from ..application.dashboard_service import DashboardApplicationService
from ..domain.models import MetricCard
from ..presentation.components import MetricCardBuilder


class DashboardBuilder(Protocol):
    """
    Protocol defining the interface for dashboard builders.

    Single Responsibility: Define the contract for dashboard construction.
    """

    def build_dashboard(self) -> Any:
        """
        Build and return a dashboard instance.

        Returns:
            Configured dashboard instance
        """
        ...


class GradioDashboardBuilder:
    """
    Infrastructure Service: Build Gradio-based dashboard.

    Single Responsibility: Handle the technical details of Gradio UI construction.
    """

    def __init__(self, dashboard_service: DashboardApplicationService | None = None):
        """
        Initialize with dependencies (Dependency Injection pattern).

        Args:
            dashboard_service: Application service for dashboard operations
        """
        self._dashboard_service = dashboard_service or DashboardApplicationService()

    def build_dashboard(self) -> gr.Blocks:
        """
        Build the complete Gradio dashboard.

        Single Responsibility: Construct the entire dashboard interface.

        Returns:
            Configured Gradio Blocks interface
        """
        dashboard = gr.Blocks(
            title="ML Model Drift Detection Dashboard",
            theme=gr.themes.Soft(),
            css=self._get_custom_css(),
        )

        with dashboard:
            # Header
            gr.Markdown(
                """
                # 🎯 ML Model Drift Detection Dashboard
                *Monitor data drift between reference and current datasets*
                """
            )

            # Create the main structure to match the original app
            self._create_main_tabs()

        return dashboard

    def _get_custom_css(self) -> str:
        """Get custom CSS for dashboard styling."""
        return """
        .dashboard-card {
            padding: 1rem;
            border-radius: 8px;
            margin: 0.5rem;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .dashboard-card.blue { background: #0473EA; color: white; }
        .dashboard-card.green { background: #38D200; color: white; }
        .dashboard-card.red { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: white; }
        .dashboard-card.purple { background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); color: #333; }
        .metric-label { font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem; }
        .metric-value { font-size: 2rem; font-weight: 700; margin-bottom: 0.5rem; }
        .metric-subtitle { font-size: 0.8rem; opacity: 0.9; }

        /* SC brand buttons */
        .gr-button-primary {
            background: #0473EA !important; /* SC logo blue */
            border: none !important;
            color: #ffffff !important;
            font-weight: 600 !important;
            border-radius: 0.75rem !important;
        }
        .gr-button-primary:hover {
            background: rgba(4, 115, 234, 0.9) !important; /* logo blue hover */
        }

        /* Download buttons — explicit brand colors */
        #download-csv-btn,
        #download-csv-btn button,
        #download-csv-btn .gr-button,
        #download-csv-btn a {
            background: #0473EA !important; /* SC logo blue */
            background-color: #0473EA !important;
            border: none !important;
            color: white !important;
            font-weight: 600 !important;
            border-radius: 0.75rem !important;
        }
        #download-csv-btn:hover,
        #download-csv-btn button:hover,
        #download-csv-btn .gr-button:hover,
        #download-csv-btn a:hover {
            background: rgba(4, 115, 234, 0.9) !important;
            background-color: rgba(4, 115, 234, 0.9) !important;
        }

        #download-json-btn,
        #download-json-btn button,
        #download-json-btn .gr-button,
        #download-json-btn a {
            background: #38D200 !important; /* SC logo green */
            background-color: #38D200 !important;
            border: none !important;
            color: white !important;
            font-weight: 600 !important;
            border-radius: 0.75rem !important;
        }
        #download-json-btn:hover,
        #download-json-btn button:hover,
        #download-json-btn .gr-button:hover,
        #download-json-btn a:hover {
            background: rgba(56, 210, 0, 0.9) !important;
            background-color: rgba(56, 210, 0, 0.9) !important;
        }

        /* Force specific primary action buttons to SC dark blue */
        #upload-files-btn,
        #upload-files-btn button,
        #upload-files-btn .gr-button,
        #load-pg-btn,
        #load-pg-btn button,
        #load-pg-btn .gr-button,
        #compute-synth-btn,
        #compute-synth-btn button,
        #compute-synth-btn .gr-button,
        #test-notification-btn,
        #test-notification-btn button,
        #test-notification-btn .gr-button,
        #refresh-table-btn,
        #refresh-table-btn button,
        #refresh-table-btn .gr-button,
        #test-conn-btn,
        #test-conn-btn button,
        #test-conn-btn .gr-button {
            background: #0473EA !important; /* SC logo blue */
            color: #ffffff !important;
            border: none !important;
            background-image: none !important;
        }

        #upload-files-btn button:hover,
        #load-pg-btn button:hover,
        #compute-synth-btn button:hover,
        #test-notification-btn button:hover,
        #refresh-table-btn button:hover,
        #test-conn-btn button:hover,
        #upload-files-btn .gr-button:hover,
        #load-pg-btn .gr-button:hover,
        #compute-synth-btn .gr-button:hover,
        #test-notification-btn .gr-button:hover,
        #refresh-table-btn .gr-button:hover,
        #test-conn-btn .gr-button:hover {
            background: rgba(4, 115, 234, 0.9) !important;
        }
        """

    def _create_main_tabs(self) -> None:
        """Create the main tab structure to match the original app."""
        # Data source and controls section (above tabs)
        self._create_data_source_and_controls()

        # Main dashboard content
        with gr.Tabs():
            self._create_overview_tab()
            self._create_results_tab()
            self._create_statistics_tab()
            self._create_explore_tab()

    def _create_data_source_and_controls(self) -> None:
        """Create data source selection and analysis controls above the main tabs."""
        # Data Sources
        with gr.Group(elem_classes="bento-card"):
            gr.Markdown("### 📊 Data Sources")

            # File upload
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Upload CSV Files")
                    gr.File(label="Reference Dataset (CSV)")
                    gr.File(label="Current Dataset (CSV)")
                    gr.Button("📤 Load Files", variant="primary", elem_id="upload-files-btn")

                with gr.Column():
                    gr.Markdown("#### PostgreSQL Connection")
                    with gr.Row():
                        gr.Textbox(label="Host", value="localhost")
                        gr.Number(label="Port", value=5432)
                    gr.Textbox(label="Database")
                    gr.Textbox(label="Username")
                    gr.Textbox(label="Password", type="password")
                    gr.Button("🔗 Test Connection", elem_id="test-conn-btn")
                    gr.Markdown("")

                    gr.Dropdown(label="Reference Table")
                    gr.Dropdown(label="Current Table")
                    gr.Button("📥 Load from Database", variant="primary", elem_id="load-pg-btn")

            # Generate synthetic data
            gr.Markdown("#### Generate Synthetic Data")
            with gr.Row():
                gr.Slider(100, 5000, value=2000, step=100, label="Reference samples")
                gr.Slider(100, 5000, value=2000, step=100, label="Current samples")
            gr.Slider(1, 1000, value=42, step=1, label="Random seed")
            gr.Slider(0.0, 1.0, value=0.2, step=0.05, label="Drift strength")
            gr.Button("🎲 Generate & Analyze", variant="primary", elem_id="compute-synth-btn")

        # Analysis Controls
        with gr.Group(elem_classes="bento-card"):
            gr.Markdown("### ⚙️ Analysis Controls")

            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Statistical Thresholds")
                    gr.Slider(0.01, 0.1, value=0.05, step=0.01, label="Alpha (significance level)")
                    gr.Slider(0.01, 0.5, value=0.1, step=0.01, label="Wasserstein threshold")
                    gr.Slider(0.01, 0.5, value=0.1, step=0.01, label="Jensen-Shannon threshold")
                    gr.Slider(0.01, 0.5, value=0.1, step=0.01, label="Euclidean threshold")
                    gr.Slider(0.01, 0.5, value=0.1, step=0.01, label="PSI threshold")
                    gr.Slider(10, 200, value=40, step=5, label="Histogram bins")

        # Notification settings
        with gr.Group(elem_classes="bento-card"):
            gr.Markdown("#### Notification Settings")
            gr.Checkbox(
                value=True,
                label="Enable system notifications",
                info="Show desktop notifications when drift is detected",
            )
            gr.Checkbox(
                value=True, label="Enable notification sound", info="Play sound with notifications"
            )
            gr.Slider(
                1,
                10,
                value=1,
                step=1,
                label="Minimum drift threshold",
                info="Number of drifted features required to notify",
            )
        gr.Button("Test Notification", variant="primary", elem_id="test-notification-btn")
        gr.Markdown("", elem_classes="connection-status")

    def _create_overview_tab(self) -> None:
        """Create the Overview tab with metric cards."""
        with gr.Tab("Overview"):
            # Create empty cards with warning
            empty_cards = self._create_empty_cards()

            gr.Markdown("### Primary Metrics")
            with gr.Row():
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[0])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[1])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[2])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[3])

            gr.Markdown("### Feature Breakdown")
            with gr.Row():
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[4])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[5])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[6])

            gr.Markdown("### Statistical Insights")
            with gr.Row():
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[7])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[8])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[9])

            gr.Markdown("### Data Volume")
            with gr.Row():
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[10])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[11])
                with gr.Column(scale=1):
                    gr.HTML(value=empty_cards[12])

            gr.Markdown("", elem_classes="timestamp-display")

            gr.Markdown("### Test Results Summary")

            # Create empty table with helpful message
            import pandas as pd

            empty_counts = pd.DataFrame(
                {
                    "test": ["No data loaded yet"],
                    "total": ["—"],
                    "drifted": ["—"],
                    "rate": ["Select a data source above"],
                }
            )
            gr.Dataframe(value=empty_counts, interactive=False, wrap=True)

    def _create_results_tab(self) -> None:
        """Create the Results tab."""
        with gr.Tab("Results"):
            with gr.Row():
                gr.Dropdown(choices=[], multiselect=True, label="Features")
                gr.Dropdown(choices=[], multiselect=True, label="Type")
                gr.Dropdown(choices=[], multiselect=True, label="Test")
            gr.Button("Refresh table", variant="primary", elem_id="refresh-table-btn")
            gr.Dataframe(interactive=False, wrap=True)
            with gr.Row():
                gr.DownloadButton(label="Download results (CSV)", elem_id="download-csv-btn")
                gr.DownloadButton(label="Download results (JSON)", elem_id="download-json-btn")

    def _create_statistics_tab(self) -> None:
        """Create the Statistics tab."""
        with gr.Tab("Statistics"):
            gr.Markdown("### Summary Statistics Comparison")
            gr.Markdown(
                "Compare descriptive statistics between reference and current datasets for numerical features."
            )
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Reference Dataset Statistics",
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Current Dataset Statistics",
                    )

            gr.Markdown("### Missing Values Analysis")
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Reference Dataset Missing Values",
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Current Dataset Missing Values",
                    )

            gr.Markdown("### Data Types")
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Reference Dataset Data Types",
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Current Dataset Data Types",
                    )

            gr.Markdown("### Categorical Features Analysis")
            gr.Dataframe(
                interactive=False,
                wrap=True,
                label="Categorical Features Statistics",
            )

    def _create_explore_tab(self) -> None:
        """Create the Explore tab for visualizations."""
        with gr.Tab("Explore"):
            gr.Markdown("### Data Distribution Analysis")

            with gr.Row():
                gr.Dropdown(
                    choices=[], label="Select Feature", info="Choose a feature to visualize"
                )
                gr.Dropdown(
                    choices=["distribution", "ecdf", "binned", "difference"],
                    value="distribution",
                    label="Plot Type",
                )

            gr.Plot(label="Feature Distribution")

    def _create_empty_cards(self) -> list[str]:
        """Create empty metric cards for initial display."""
        empty_cards = MetricCardBuilder.create_empty_cards()
        return [card.to_html() for card in empty_cards]

    def _create_empty_metrics_html(self) -> str:
        """Create HTML for empty metrics display."""
        empty_cards = MetricCardBuilder.create_empty_cards()
        return "".join([card.to_html() for card in empty_cards])

    def create_metrics_html(self, metrics: list[MetricCard]) -> str:
        """
        Convert metric cards to HTML.

        Single Responsibility: Transform domain objects to HTML representation.

        Args:
            metrics: List of metric cards

        Returns:
            HTML string for metrics display
        """
        return "".join([metric.to_html() for metric in metrics])
