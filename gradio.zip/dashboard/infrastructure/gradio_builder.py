"""
Gradio Dashboard Builder - Infrastructure Service

Single Responsibility: Build and configure Gradio-based dashboard interface.
This service handles the technical details of UI framework integration.
"""

from __future__ import annotations

import gradio as gr
from typing import Any, Protocol

from ..application.dashboard_service import DashboardApplicationService
from ..domain.models import MetricCard
from ..presentation.components import MetricCardBuilder


class DashboardBuilder(Protocol):
    """
    Protocol defining the interface for dashboard builders.
    
    Single Responsibility: Define the contract for dashboard construction.
    """

    def build_dashboard(self) -> Any:
        """
        Build and return a dashboard instance.

        Returns:
            Configured dashboard instance
        """
        ...


class GradioDashboardBuilder:
    """
    Infrastructure Service: Build Gradio-based dashboard.

    Single Responsibility: Handle the technical details of Gradio UI construction.
    """

    def __init__(self, dashboard_service: DashboardApplicationService | None = None):
        """
        Initialize with dependencies (Dependency Injection pattern).

        Args:
            dashboard_service: Application service for dashboard operations
        """
        self._dashboard_service = dashboard_service or DashboardApplicationService()

    def build_dashboard(self) -> gr.Blocks:
        """
        Build the complete Gradio dashboard.

        Single Responsibility: Construct the entire dashboard interface.

        Returns:
            Configured Gradio Blocks interface
        """
        dashboard = gr.Blocks(
            title="ML Model Drift Detection Dashboard",
            theme=gr.themes.Soft(),
            css=self._get_custom_css(),
        )

        with dashboard:
            # Header
            gr.Markdown(
                """
                # 🎯 ML Model Drift Detection Dashboard
                *Monitor data drift between reference and current datasets*
                """
            )

            # Create the main structure to match the original app
            self._create_main_tabs()

        return dashboard

    def _get_custom_css(self) -> str:
        """Get custom CSS for dashboard styling."""
        return """
        .dashboard-card {
            padding: 1rem;
            border-radius: 8px;
            margin: 0.5rem;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .dashboard-card.blue { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        .dashboard-card.green { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; }
        .dashboard-card.red { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: white; }
        .dashboard-card.purple { background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); color: #333; }
        .metric-label { font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem; }
        .metric-value { font-size: 2rem; font-weight: 700; margin-bottom: 0.5rem; }
        .metric-subtitle { font-size: 0.8rem; opacity: 0.9; }
        """

    def _create_main_tabs(self) -> None:
        """Create the main tab structure to match the original app."""
        # Data source and controls section (above tabs)
        self._create_data_source_and_controls()

        # Main dashboard content
        with gr.Tabs():
            self._create_overview_tab()
            self._create_results_tab()
            self._create_statistics_tab()
            self._create_explore_tab()

    def _create_data_source_and_controls(self) -> None:
        """Create data source selection and analysis controls above the main tabs."""
        # Data Sources
        with gr.Group(elem_classes="bento-card"):
            gr.Markdown("### 📊 Data Sources")

            # File upload
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Upload CSV Files")
                    ref_file = gr.File(label="Reference Dataset (CSV)")
                    cur_file = gr.File(label="Current Dataset (CSV)")
                    upload_btn = gr.Button("📤 Load Files", variant="primary")

                with gr.Column():
                    gr.Markdown("#### PostgreSQL Connection")
                    with gr.Row():
                        pg_host = gr.Textbox(label="Host", value="localhost")
                        pg_port = gr.Number(label="Port", value=5432)
                    pg_database = gr.Textbox(label="Database")
                    pg_user = gr.Textbox(label="Username")
                    pg_password = gr.Textbox(label="Password", type="password")
                    test_conn_btn = gr.Button("🔗 Test Connection")
                    conn_status = gr.Markdown("")

                    ref_table = gr.Dropdown(label="Reference Table")
                    cur_table = gr.Dropdown(label="Current Table")
                    load_pg_btn = gr.Button("📥 Load from Database", variant="primary")

            # Generate synthetic data
            gr.Markdown("#### Generate Synthetic Data")
            with gr.Row():
                ref_n = gr.Slider(100, 5000, value=2000, step=100, label="Reference samples")
                cur_n = gr.Slider(100, 5000, value=2000, step=100, label="Current samples")
            seed = gr.Slider(1, 1000, value=42, step=1, label="Random seed")
            drift_strength = gr.Slider(0.0, 1.0, value=0.2, step=0.05, label="Drift strength")
            compute_synth_btn = gr.Button("🎲 Generate & Analyze", variant="primary")

        # Analysis Controls
        with gr.Group(elem_classes="bento-card"):
            gr.Markdown("### ⚙️ Analysis Controls")

            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Statistical Thresholds")
                    alpha = gr.Slider(0.01, 0.1, value=0.05, step=0.01, label="Alpha (significance level)")
                    wasserstein_threshold = gr.Slider(0.01, 0.5, value=0.1, step=0.01, label="Wasserstein threshold")
                    js_threshold = gr.Slider(0.01, 0.5, value=0.1, step=0.01, label="Jensen-Shannon threshold")
                    euclidean_threshold = gr.Slider(0.01, 0.5, value=0.1, step=0.01, label="Euclidean threshold")
                    psi_threshold = gr.Slider(0.01, 0.5, value=0.1, step=0.01, label="PSI threshold")
                    bins = gr.Slider(10, 200, value=40, step=5, label="Histogram bins")

        # Notification settings
        with gr.Group(elem_classes="bento-card"):
            gr.Markdown("#### Notification Settings")
            notify_enabled = gr.Checkbox(
                value=True,
                label="Enable system notifications",
                info="Show desktop notifications when drift is detected",
            )
            notify_sound = gr.Checkbox(
                value=True, label="Enable notification sound", info="Play sound with notifications"
            )
            notify_min_drift = gr.Slider(
                1,
                10,
                value=1,
                step=1,
                label="Minimum drift threshold",
                info="Number of drifted features required to notify",
            )
        test_notification_btn = gr.Button("Test Notification", variant="primary")
        test_notification_status = gr.Markdown("", elem_classes="connection-status")

    def _create_overview_tab(self) -> None:
        """Create the Overview tab with metric cards."""
        with gr.Tab("Overview"):
            # Create empty cards with warning
            empty_cards = self._create_empty_cards()

            gr.Markdown("### Primary Metrics")
            with gr.Row():
                with gr.Column(scale=1):
                    total_features_card = gr.HTML(value=empty_cards[0])
                with gr.Column(scale=1):
                    drifted_features_card = gr.HTML(value=empty_cards[1])
                with gr.Column(scale=1):
                    drift_rate_card = gr.HTML(value=empty_cards[2])
                with gr.Column(scale=1):
                    stable_features_card = gr.HTML(value=empty_cards[3])

            gr.Markdown("### Feature Breakdown")
            with gr.Row():
                with gr.Column(scale=1):
                    numerical_features_card = gr.HTML(value=empty_cards[4])
                with gr.Column(scale=1):
                    categorical_features_card = gr.HTML(value=empty_cards[5])
                with gr.Column(scale=1):
                    critical_drift_card = gr.HTML(value=empty_cards[6])

            gr.Markdown("### Statistical Insights")
            with gr.Row():
                with gr.Column(scale=1):
                    total_tests_card = gr.HTML(value=empty_cards[7])
                with gr.Column(scale=1):
                    avg_pvalue_card = gr.HTML(value=empty_cards[8])
                with gr.Column(scale=1):
                    max_statistic_card = gr.HTML(value=empty_cards[9])

            gr.Markdown("### Data Volume")
            with gr.Row():
                with gr.Column(scale=1):
                    ref_samples_card = gr.HTML(value=empty_cards[10])
                with gr.Column(scale=1):
                    cur_samples_card = gr.HTML(value=empty_cards[11])
                with gr.Column(scale=1):
                    total_datapoints_card = gr.HTML(value=empty_cards[12])

            updated_timestamp = gr.Markdown("", elem_classes="timestamp-display")

            gr.Markdown("### Test Results Summary")

            # Create empty table with helpful message
            import pandas as pd
            empty_counts = pd.DataFrame(
                {
                    "test": ["No data loaded yet"],
                    "total": ["—"],
                    "drifted": ["—"],
                    "rate": ["Select a data source above"],
                }
            )
            counts_table = gr.Dataframe(value=empty_counts, interactive=False, wrap=True)

    def _create_results_tab(self) -> None:
        """Create the Results tab."""
        with gr.Tab("Results"):
            with gr.Row():
                feat_filter = gr.Dropdown(choices=[], multiselect=True, label="Features")
                type_filter = gr.Dropdown(choices=[], multiselect=True, label="Type")
                test_filter = gr.Dropdown(choices=[], multiselect=True, label="Test")
            apply_filters = gr.Button("Refresh table", variant="primary")
            results_table = gr.Dataframe(interactive=False, wrap=True)
            with gr.Row():
                download_csv = gr.DownloadButton(
                    label="Download results (CSV)", elem_id="download-csv-btn"
                )
                download_json = gr.DownloadButton(
                    label="Download results (JSON)", elem_id="download-json-btn"
                )

    def _create_statistics_tab(self) -> None:
        """Create the Statistics tab."""
        with gr.Tab("Statistics"):
            gr.Markdown("### Summary Statistics Comparison")
            gr.Markdown(
                "Compare descriptive statistics between reference and current datasets for numerical features."
            )
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    summary_stats_ref_table = gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Reference Dataset Statistics",
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    summary_stats_cur_table = gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Current Dataset Statistics",
                    )

            gr.Markdown("### Missing Values Analysis")
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    missing_values_ref_table = gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Reference Dataset Missing Values",
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    missing_values_cur_table = gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Current Dataset Missing Values",
                    )

            gr.Markdown("### Data Types")
            with gr.Row():
                with gr.Column():
                    gr.Markdown("#### Reference Dataset")
                    data_types_ref_table = gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Reference Dataset Data Types",
                    )
                with gr.Column():
                    gr.Markdown("#### Current Dataset")
                    data_types_cur_table = gr.Dataframe(
                        interactive=False,
                        wrap=True,
                        label="Current Dataset Data Types",
                    )

            gr.Markdown("### Categorical Features Analysis")
            categorical_stats_table = gr.Dataframe(
                interactive=False,
                wrap=True,
                label="Categorical Features Statistics",
            )

    def _create_explore_tab(self) -> None:
        """Create the Explore tab for visualizations."""
        with gr.Tab("Explore"):
            gr.Markdown("### Data Distribution Analysis")

            with gr.Row():
                selected_feature = gr.Dropdown(
                    choices=[],
                    label="Select Feature",
                    info="Choose a feature to visualize"
                )
                plot_type = gr.Dropdown(
                    choices=["distribution", "ecdf", "binned", "difference"],
                    value="distribution",
                    label="Plot Type"
                )

            plot = gr.Plot(label="Feature Distribution")

    def _create_empty_cards(self) -> list[str]:
        """Create empty metric cards for initial display."""
        empty_cards = MetricCardBuilder.create_empty_cards()
        return [card.to_html() for card in empty_cards]

    def _create_empty_metrics_html(self) -> str:
        """Create HTML for empty metrics display."""
        empty_cards = MetricCardBuilder.create_empty_cards()
        return "".join([card.to_html() for card in empty_cards])

    def create_metrics_html(self, metrics: list[MetricCard]) -> str:
        """
        Convert metric cards to HTML.

        Single Responsibility: Transform domain objects to HTML representation.

        Args:
            metrics: List of metric cards

        Returns:
            HTML string for metrics display
        """
        return "".join([metric.to_html() for metric in metrics])
