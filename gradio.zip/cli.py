"""
CLI for drift monitoring using the new DDD architecture.

This script provides command-line access to drift detection functionality.
"""

from __future__ import annotations

import argparse

from monitor.application import DriftAnalyzer
from monitor.domain import DriftThresholds
from monitor.infrastructure import DataRepository, ReportWriter, SyntheticDataGenerator


def cmd_generate(args: argparse.Namespace) -> None:
    """Generate synthetic datasets with controlled drift."""
    generator = SyntheticDataGenerator(seed=args.seed)
    ref, cur = generator.generate(
        reference_n=args.ref_n,
        current_n=args.cur_n,
        drift_strength=args.drift_strength,
    )

    repository = DataRepository()
    ref_path, cur_path = repository.save_datasets(ref, cur, args.outdir)

    print(f"Saved reference to {ref_path}")
    print(f"Saved current to {cur_path}")


def cmd_detect(args: argparse.Namespace) -> None:
    """Run drift detection on two datasets."""
    # Load data
    repository = DataRepository()
    reference = repository.load_dataset(args.reference)
    current = repository.load_dataset(args.current)

    # Configure thresholds
    thresholds = DriftThresholds(
        alpha=args.alpha,
        psi_threshold=args.psi_threshold,
        js_threshold=args.js_threshold,
        wasserstein_threshold=args.wasserstein_threshold,
    )

    # Analyze drift
    analyzer = DriftAnalyzer()
    analysis_result = analyzer.analyze_drift(reference, current, thresholds)

    # Save report
    writer = ReportWriter()
    csv_path, json_path = writer.save_report(analysis_result, args.outdir)

    # Display summary
    print("\n" + "=" * 80)
    print("DRIFT ANALYSIS SUMMARY")
    print("=" * 80)
    print(f"Total features analyzed: {analysis_result.total_features}")
    print(f"Total tests performed: {analysis_result.total_tests}")
    print(f"Drift rate: {analysis_result.get_drift_rate():.1%}")
    print(f"\nDrifted features: {len(analysis_result.get_drifted_features())}")
    for feature in analysis_result.get_drifted_features():
        print(f"  - {feature}")

    critical = analysis_result.get_critical_drifts()
    if critical:
        print(f"\nCritical drift (multiple tests failed): {len(critical)}")
        for feature in critical:
            print(f"  - {feature}")

    print("\nReports saved:")
    print(f"  CSV:  {csv_path}")
    print(f"  JSON: {json_path}")
    print("=" * 80 + "\n")


def build_parser() -> argparse.ArgumentParser:
    """Build argument parser with subcommands."""
    parser = argparse.ArgumentParser(
        description="Drift monitoring CLI - DDD Architecture",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate synthetic data with drift
  python cli.py generate --drift-strength 0.3 --outdir data

  # Detect drift between two datasets
  python cli.py detect --reference data/reference.csv --current data/current.csv
        """,
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # Generate command
    p_gen = sub.add_parser("generate", help="Generate synthetic datasets")
    p_gen.add_argument("--outdir", default="data", help="Output directory for CSVs")
    p_gen.add_argument(
        "--ref-n", type=int, default=2000, dest="ref_n", help="Number of reference samples"
    )
    p_gen.add_argument(
        "--cur-n", type=int, default=2000, dest="cur_n", help="Number of current samples"
    )
    p_gen.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    p_gen.add_argument(
        "--drift-strength",
        type=float,
        default=0.2,
        dest="drift_strength",
        help="Drift magnitude (0.0=no drift, higher=more drift)",
    )
    p_gen.set_defaults(func=cmd_generate)

    # Detect command
    p_det = sub.add_parser("detect", help="Run drift detection on two CSV files")
    p_det.add_argument("--reference", required=True, help="Reference CSV path")
    p_det.add_argument("--current", required=True, help="Current CSV path")
    p_det.add_argument(
        "--alpha", type=float, default=0.05, help="Significance level for statistical tests"
    )
    p_det.add_argument(
        "--psi-threshold",
        type=float,
        default=0.1,
        dest="psi_threshold",
        help="PSI threshold for drift detection",
    )
    p_det.add_argument(
        "--js-threshold",
        type=float,
        default=0.1,
        dest="js_threshold",
        help="Jensen-Shannon threshold for drift detection",
    )
    p_det.add_argument(
        "--wasserstein-threshold",
        type=float,
        default=0.1,
        dest="wasserstein_threshold",
        help="Wasserstein distance threshold",
    )
    p_det.add_argument("--outdir", default="outputs", help="Output directory for reports")
    p_det.set_defaults(func=cmd_detect)

    return parser


def main() -> None:
    """Main entry point for CLI."""
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
