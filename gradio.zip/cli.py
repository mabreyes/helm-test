from __future__ import annotations

import argparse
import os

import pandas as pd

from monitor.data import generate_synthetic_data, save_datasets
from monitor.drift import detect_drift
from monitor.report import save_report


def cmd_generate(args: argparse.Namespace) -> None:
    ref, cur = generate_synthetic_data(
        reference_n=args.ref_n,
        current_n=args.cur_n,
        seed=args.seed,
        drift_strength=args.drift_strength,
    )
    ref_path, cur_path = save_datasets(ref, cur, args.outdir)
    print(f"Saved reference to {ref_path}")
    print(f"Saved current to {cur_path}")


def cmd_detect(args: argparse.Namespace) -> None:
    reference = pd.read_csv(args.reference)
    current = pd.read_csv(args.current)

    results = detect_drift(reference, current, alpha=args.alpha)
    csv_path, json_path = save_report(results, args.outdir)

    print(results)
    print(f"Saved report: {csv_path}\nSaved report: {json_path}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Drift monitoring CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_gen = sub.add_parser("generate", help="Generate synthetic datasets")
    p_gen.add_argument("--outdir", default="data", help="Output directory for CSVs")
    p_gen.add_argument("--ref-n", type=int, default=2000, dest="ref_n")
    p_gen.add_argument("--cur-n", type=int, default=2000, dest="cur_n")
    p_gen.add_argument("--seed", type=int, default=42)
    p_gen.add_argument(
        "--drift-strength", type=float, default=0.2, dest="drift_strength"
    )
    p_gen.set_defaults(func=cmd_generate)

    p_det = sub.add_parser("detect", help="Run drift detection on two CSVs")
    p_det.add_argument("--reference", required=True, help="Reference CSV path")
    p_det.add_argument("--current", required=True, help="Current CSV path")
    p_det.add_argument(
        "--alpha", type=float, default=0.05, help="Significance threshold"
    )
    p_det.add_argument(
        "--outdir", default="outputs", help="Output directory for reports"
    )
    p_det.set_defaults(func=cmd_detect)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
