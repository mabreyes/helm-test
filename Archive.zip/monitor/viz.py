from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

APPLE_FONT_STACK = "-apple-system, BlinkMacSystemFont, 'SF Pro Text','SF Pro Display','Helvetica Neue',Helvetica,Arial,'Apple Color Emoji','Segoe UI',Roboto,'Noto Sans','Liberation Sans',sans-serif"


def plot_numeric_distributions(
    ref: pd.Series,
    cur: pd.Series,
    bins: int = 40,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    fig = go.Figure()
    if len(ref_clean) > 0:
        fig.add_trace(
            go.Histogram(
                x=ref_clean,
                nbinsx=bins,
                name=ref_name,
                opacity=0.6,
                histnorm="probability",
            )
        )
    if len(cur_clean) > 0:
        fig.add_trace(
            go.Histogram(
                x=cur_clean,
                nbinsx=bins,
                name=cur_name,
                opacity=0.6,
                histnorm="probability",
            )
        )

    fig.update_layout(
        barmode="overlay",
        xaxis_title="Value",
        yaxis_title="Probability",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=30, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_categorical_distributions(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    cur_counts = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)

    fig = go.Figure()
    fig.add_trace(go.Bar(x=categories, y=ref_counts.values, name=ref_name, opacity=0.8))
    fig.add_trace(go.Bar(x=categories, y=cur_counts.values, name=cur_name, opacity=0.8))

    fig.update_layout(
        barmode="group",
        xaxis_title="Category",
        yaxis_title="Proportion",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=30, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_numeric_binned_probs(
    ref: pd.Series,
    cur: pd.Series,
    bins: int = 40,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    if len(ref_clean) == 0 and len(cur_clean) == 0:
        return go.Figure()

    combined = np.concatenate(
        [
            ref_clean.values if len(ref_clean) else np.array([], dtype=float),
            cur_clean.values if len(cur_clean) else np.array([], dtype=float),
        ]
    )
    # Fallback single edge if everything empty
    if combined.size == 0:
        combined = np.array([0.0, 1.0])

    bin_edges = np.histogram_bin_edges(combined, bins=bins)
    ref_counts, _ = np.histogram(
        ref_clean.values if len(ref_clean) else np.array([], dtype=float),
        bins=bin_edges,
    )
    cur_counts, _ = np.histogram(
        cur_clean.values if len(cur_clean) else np.array([], dtype=float),
        bins=bin_edges,
    )

    def _normalize(counts: np.ndarray) -> np.ndarray:
        total = float(np.sum(counts))
        return (
            (counts.astype(float) / total)
            if total > 0
            else np.zeros_like(counts, dtype=float)
        )

    p = _normalize(ref_counts)
    q = _normalize(cur_counts)
    centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0
    abs_diff = np.abs(q - p)

    fig = go.Figure()
    fig.add_trace(go.Bar(x=centers, y=p, name=ref_name, opacity=0.7))
    fig.add_trace(go.Bar(x=centers, y=q, name=cur_name, opacity=0.7))
    fig.add_trace(
        go.Scatter(
            x=centers,
            y=abs_diff,
            mode="lines",
            name="|Δ| (current - reference)",
            line=dict(dash="dot", width=2),
        )
    )

    fig.update_layout(
        barmode="overlay",
        xaxis_title="Value",
        yaxis_title="Probability",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=30, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_categorical_difference(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_probs = ref.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    cur_probs = cur.value_counts(normalize=True).reindex(categories, fill_value=0.0)
    diff = (cur_probs - ref_probs).values
    colors = ["seagreen" if d >= 0 else "crimson" for d in diff]

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=categories, y=diff, marker_color=colors, name=f"Δ {cur_name}-{ref_name}"
        )
    )

    fig.update_layout(
        xaxis_title="Category",
        yaxis_title="Probability difference",
        legend_title="Legend",
        margin=dict(l=10, r=10, t=30, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_chi_square_contributions(
    ref: pd.Series,
    cur: pd.Series,
) -> go.Figure:
    ref = ref.astype("object").fillna("<NA>")
    cur = cur.astype("object").fillna("<NA>")

    categories = sorted(set(ref.unique()).union(set(cur.unique())))
    ref_counts = ref.value_counts().reindex(categories, fill_value=0)
    cur_counts = cur.value_counts().reindex(categories, fill_value=0)

    contingency = np.vstack([ref_counts.values, cur_counts.values]).astype(float)
    n_total = contingency.sum()
    if n_total <= 0:
        return go.Figure()
    row_sums = contingency.sum(axis=1, keepdims=True)
    col_sums = contingency.sum(axis=0, keepdims=True)
    expected = row_sums @ (col_sums / n_total)
    with np.errstate(divide="ignore", invalid="ignore"):
        contrib = (contingency - expected) ** 2 / np.where(expected > 0, expected, 1.0)
    per_category_contrib = contrib.sum(axis=0)

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=categories,
            y=per_category_contrib,
            name="Chi-square contribution",
            marker_color="steelblue",
        )
    )
    fig.update_layout(
        xaxis_title="Category",
        yaxis_title="Contribution",
        legend_title="Legend",
        margin=dict(l=10, r=10, t=30, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )
    return fig


def plot_numeric_ecdf(
    ref: pd.Series,
    cur: pd.Series,
    ref_name: str = "reference",
    cur_name: str = "current",
) -> go.Figure:
    ref_clean = pd.to_numeric(ref, errors="coerce").dropna()
    cur_clean = pd.to_numeric(cur, errors="coerce").dropna()

    fig = go.Figure()

    if len(ref_clean) > 0:
        x_ref = ref_clean.sort_values().values
        y_ref = (pd.Series(range(1, len(x_ref) + 1)) / len(x_ref)).values
        fig.add_trace(
            go.Scatter(
                x=x_ref,
                y=y_ref,
                mode="lines",
                name=ref_name,
                line=dict(width=2),
                line_shape="hv",
            )
        )

    if len(cur_clean) > 0:
        x_cur = cur_clean.sort_values().values
        y_cur = (pd.Series(range(1, len(x_cur) + 1)) / len(x_cur)).values
        fig.add_trace(
            go.Scatter(
                x=x_cur,
                y=y_cur,
                mode="lines",
                name=cur_name,
                line=dict(width=2),
                line_shape="hv",
            )
        )

    fig.update_layout(
        xaxis_title="Value",
        yaxis_title="ECDF",
        legend_title="Dataset",
        margin=dict(l=10, r=10, t=30, b=10),
        template="plotly_white",
        font=dict(family=APPLE_FONT_STACK),
    )

    return fig
