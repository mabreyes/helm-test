# Drift Monitoring (KS for numerical, Chi-square for categorical)

## Setup

```bash
python -m venv .venv
source .venv/bin/activate  # on macOS/Linux
pip install -r requirements.txt
```

## CLI Usage

Generate synthetic reference/current datasets:
```bash
python cli.py generate --outdir data --ref-n 2000 --cur-n 2000 --drift-strength 0.3 --seed 42
```

Run drift detection on two CSVs (auto-detects column types):
```bash
python cli.py detect --reference data/reference.csv --current data/current.csv --alpha 0.05 --outdir outputs
```

This will print a summary and save `outputs/drift_report.csv` and `outputs/drift_report.json`.

## Dashboard

Launch the interactive dashboard:
```bash
python app.py
```

- Use the left controls to either generate synthetic data or upload your own reference/current CSVs.
- Set the significance level (alpha) to flag drift.
- View per-feature tests, distributions, and export results.

## Notes
- KS test is used for numerical columns.
- Chi-square test is used for categorical columns.
- Missing values are ignored for numerical tests and treated as a separate category for categorical tests.
