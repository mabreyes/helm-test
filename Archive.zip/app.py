from __future__ import annotations

import argparse
import os
from typing import Any, Dict, List, Optional, Tuple
import tempfile

import gradio as gr
import pandas as pd

from monitor.data import generate_synthetic_data
from monitor.drift import detect_drift, identify_column_types
from monitor.viz import (
    plot_categorical_distributions,
    plot_numeric_distributions,
    plot_numeric_ecdf,
    plot_numeric_binned_probs,
    plot_categorical_difference,
    plot_chi_square_contributions,
)

TESTS_BY_TYPE: Dict[str, List[str]] = {
    "numerical": ["ks", "jensen-shannon", "psi"],
    "categorical": ["chi-square", "jensen-shannon", "psi"],
}


def _read_csv_from_gradio(file_obj: Any) -> pd.DataFrame:
    if file_obj is None:
        raise gr.Error("Please provide a CSV file.")
    path = getattr(file_obj, "name", None) or getattr(file_obj, "path", None)
    if not path:
        raise gr.Error("Could not read uploaded file.")
    return pd.read_csv(path)


def _write_temp_file(name: str, data: bytes) -> str:
    tmpdir = tempfile.mkdtemp(prefix="drift_")
    path = os.path.join(tmpdir, name)
    with open(path, "wb") as f:
        f.write(data)
    return path


def _tests_for_types(selected_types: List[str], all_tests: List[str]) -> List[str]:
    out: set[str] = set()
    for t in selected_types:
        out.update(TESTS_BY_TYPE.get(t, []))
    # Fallback to all if none resolved
    return sorted(out) or sorted(all_tests)


def _compute_from_dfs(
    reference: pd.DataFrame,
    current: pd.DataFrame,
    alpha: float,
    js_threshold: float,
    psi_threshold: float,
    bins: int,
) -> Tuple[
    str,
    pd.DataFrame,
    object,
    object,
    object,
    pd.DataFrame,
    str,
    str,
    pd.DataFrame,
    Dict[str, str],
    List[str],
    List[str],
    List[str],
    object,
    Any,
]:
    results = detect_drift(
        reference,
        current,
        alpha=alpha,
        js_threshold=js_threshold,
        psi_threshold=psi_threshold,
        bins=bins,
    )

    total_features = len(results["feature"].unique()) if not results.empty else 0
    drifted = (
        int(results.groupby("feature")["drift_detected"].any().sum())
        if not results.empty
        else 0
    )
    pct_drifted = 100.0 * drifted / max(total_features, 1)
    metrics_md = (
        f"**Total features**: {total_features}\n\n"
        f"**Features with drift**: {drifted}\n\n"
        f"**% Drifted**: {pct_drifted:.1f}%\n\n"
        f"Thresholds: KS/Chi-square uses alpha; JS and PSI use the sliders."
    )

    if results.empty:
        counts = pd.DataFrame({"test": [], "total": [], "drifted": [], "rate": []})
    else:
        counts = (
            results.groupby(["test"])["drift_detected"]
            .agg(total="count", drifted="sum")
            .reset_index()
        )
        counts["rate"] = (counts["drifted"] / counts["total"]).round(3)

    feature_type_map: Dict[str, str] = (
        results.groupby("feature")["feature_type"].first().to_dict()
        if not results.empty
        else {}
    )
    all_features = (
        sorted(results["feature"].unique().tolist()) if not results.empty else []
    )
    all_types = (
        sorted(results["feature_type"].unique().tolist()) if not results.empty else []
    )
    all_tests = sorted(results["test"].unique().tolist()) if not results.empty else []

    feat_filter_update = gr.update(choices=all_features, value=[])
    type_filter_update = gr.update(choices=all_types, value=all_types)
    test_filter_update = gr.update(choices=all_tests, value=all_tests)

    table_view = results

    csv_path = _write_temp_file(
        "drift_report.csv", results.to_csv(index=False).encode("utf-8")
    )
    json_path = _write_temp_file(
        "drift_report.json", results.to_json(orient="records", indent=2).encode("utf-8")
    )

    selected_feature_update = gr.update(
        choices=list(reference.columns),
        value=(list(reference.columns)[0] if len(reference.columns) else None),
    )
    if reference.shape[1] > 0:
        first_feature = reference.columns[0]
        numeric_cols, categorical_cols = identify_column_types(reference)
        if first_feature in numeric_cols:
            init_fig = plot_numeric_distributions(
                reference[first_feature], current[first_feature], bins=bins
            )
        else:
            init_fig = plot_categorical_distributions(
                reference[first_feature], current[first_feature]
            )
    else:
        init_fig = None

    return (
        metrics_md,
        counts,
        feat_filter_update,
        type_filter_update,
        test_filter_update,
        table_view,
        csv_path,
        json_path,
        results,
        feature_type_map,
        all_features,
        all_types,
        all_tests,
        selected_feature_update,
        init_fig,
    )


def _build_compute_response(
    reference: pd.DataFrame,
    current: pd.DataFrame,
    alpha: float,
    js_threshold: float,
    psi_threshold: float,
    bins: int,
) -> Tuple[
    str,
    pd.DataFrame,
    object,
    object,
    object,
    pd.DataFrame,
    str,
    str,
    pd.DataFrame,
    Dict[str, str],
    List[str],
    List[str],
    List[str],
    object,
    Any,
    pd.DataFrame,
    pd.DataFrame,
]:
    (
        m_md,
        counts,
        feat_u,
        type_u,
        test_u,
        table_view,
        csv_b,
        json_b,
        results,
        feat_type_map,
        all_feats,
        all_types,
        all_tests,
        feature_u,
        init_fig,
    ) = _compute_from_dfs(
        reference,
        current,
        float(alpha),
        float(js_threshold),
        float(psi_threshold),
        int(bins),
    )
    return (
        m_md,
        counts,
        feat_u,
        type_u,
        test_u,
        table_view,
        csv_b,
        json_b,
        results,
        feat_type_map,
        all_feats,
        all_types,
        all_tests,
        feature_u,
        init_fig,
        reference,
        current,
    )


def _apply_filters(
    results: Optional[pd.DataFrame],
    feat_filter: List[str],
    type_filter: List[str],
    test_filter: List[str],
) -> Tuple[pd.DataFrame, str, str]:
    if results is None or len(results) == 0:
        empty = pd.DataFrame()
        return empty, "", ""

    filtered = results.copy()
    if feat_filter:
        filtered = filtered[filtered["feature"].isin(feat_filter)]
    if type_filter:
        filtered = filtered[filtered["feature_type"].isin(type_filter)]
    if test_filter:
        filtered = filtered[filtered["test"].isin(test_filter)]

    table_view = filtered
    csv_path = _write_temp_file(
        "drift_report.csv", filtered.to_csv(index=False).encode("utf-8")
    )
    json_path = _write_temp_file(
        "drift_report.json",
        filtered.to_json(orient="records", indent=2).encode("utf-8"),
    )
    return table_view, csv_path, json_path


def _on_feat_change(
    selected_feats: List[str],
    feature_type_map: Dict[str, str],
    type_choices: List[str],
    test_choices: List[str],
) -> Tuple[object, object]:
    if not selected_feats:
        return gr.update(value=type_choices), gr.update(
            choices=test_choices, value=test_choices
        )
    selected_types = sorted(
        {feature_type_map.get(f) for f in selected_feats if f in feature_type_map}
    )
    test_for_types = _tests_for_types(selected_types, test_choices)
    return gr.update(value=selected_types), gr.update(
        choices=test_for_types, value=test_for_types
    )


def _on_type_change(selected_types: List[str], all_tests: List[str]) -> object:
    test_for_types = _tests_for_types(selected_types, all_tests)
    return gr.update(choices=test_for_types, value=test_for_types)


def _render_plot(
    reference: Optional[pd.DataFrame],
    current: Optional[pd.DataFrame],
    feature: Optional[str],
    bins: int,
    plot_type: str,
) -> Any:
    if (
        reference is None
        or current is None
        or not feature
        or feature not in reference.columns
        or feature not in current.columns
    ):
        return None
    numeric_cols, categorical_cols = identify_column_types(reference)
    if feature in numeric_cols:
        if plot_type == "CDF":
            return plot_numeric_ecdf(reference[feature], current[feature])
        if plot_type == "Binned probs (JS/PSI)":
            return plot_numeric_binned_probs(
                reference[feature], current[feature], bins=bins
            )
        return plot_numeric_distributions(
            reference[feature], current[feature], bins=bins
        )
    if plot_type == "Categorical diff":
        return plot_categorical_difference(reference[feature], current[feature])
    if plot_type == "Chi-square contrib":
        return plot_chi_square_contributions(reference[feature], current[feature])
    return plot_categorical_distributions(reference[feature], current[feature])


with gr.Blocks(title="Drift Monitoring") as demo:
    gr.Markdown("# Drift Monitoring")

    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("### Controls")
            mode = gr.Radio(
                ["Synthetic demo", "Upload CSVs"],
                value="Synthetic demo",
                label="Data source",
            )

            with gr.Group(visible=True) as synthetic_group:
                ref_n = gr.Number(value=2000, label="Reference rows", precision=0)
                cur_n = gr.Number(value=2000, label="Current rows", precision=0)
                drift_strength = gr.Slider(
                    minimum=0.0,
                    maximum=1.0,
                    value=0.2,
                    step=0.05,
                    label="Drift strength",
                )
                seed = gr.Number(value=42, label="Seed", precision=0)
                compute_synth = gr.Button("Generate data + Compute", variant="primary")

            with gr.Group(visible=False) as upload_group:
                ref_file = gr.File(label="Upload reference CSV", file_types=[".csv"])
                cur_file = gr.File(label="Upload current CSV", file_types=[".csv"])
                compute_upload = gr.Button("Compute", variant="primary")

            alpha = gr.Slider(
                0.001, 0.2, value=0.05, step=0.001, label="Alpha (KS/Chi-square)"
            )
            js_threshold = gr.Slider(
                0.0, 1.0, value=0.10, step=0.01, label="JS distance threshold"
            )
            psi_threshold = gr.Slider(
                0.0, 1.0, value=0.10, step=0.01, label="PSI threshold"
            )
            bins = gr.Slider(
                10, 200, value=40, step=5, label="Histogram bins (numeric)"
            )

        with gr.Column(scale=3):
            with gr.Tabs():
                with gr.Tab("Overview"):
                    metrics_md = gr.Markdown()
                    counts_table = gr.Dataframe(interactive=False, wrap=True)

                with gr.Tab("Results"):
                    with gr.Row():
                        feat_filter = gr.Dropdown(
                            choices=[], multiselect=True, label="Features"
                        )
                        type_filter = gr.Dropdown(
                            choices=[], multiselect=True, label="Type"
                        )
                        test_filter = gr.Dropdown(
                            choices=[], multiselect=True, label="Test"
                        )
                    apply_filters = gr.Button("Apply filters")
                    results_table = gr.Dataframe(interactive=False, wrap=True)
                    with gr.Row():
                        download_csv = gr.DownloadButton(label="Download results (CSV)")
                        download_json = gr.DownloadButton(
                            label="Download results (JSON)"
                        )

                with gr.Tab("Explore"):
                    selected_feature = gr.Dropdown(choices=[], label="Select a feature")
                    plot_type = gr.Radio(
                        [
                            "Histogram",
                            "CDF",
                            "Binned probs (JS/PSI)",
                            "Categorical diff",
                            "Chi-square contrib",
                        ],
                        value="Histogram",
                        label="Plot type",
                    )
                    plot = gr.Plot()

    results_state = gr.State(None)
    feature_type_map_state = gr.State({})
    feature_choices_state = gr.State([])
    type_choices_state = gr.State([])
    test_choices_state = gr.State([])
    reference_state = gr.State(None)
    current_state = gr.State(None)

    def _toggle_groups(selected_mode: str):
        return gr.update(visible=(selected_mode == "Synthetic demo")), gr.update(
            visible=(selected_mode == "Upload CSVs")
        )

    mode.change(_toggle_groups, inputs=mode, outputs=[synthetic_group, upload_group])

    def _compute_synth_handler(
        ref_n_val: float,
        cur_n_val: float,
        seed_val: float,
        drift_strength_val: float,
        alpha_val: float,
        js_val: float,
        psi_val: float,
        bins_val: int,
    ):
        reference, current = generate_synthetic_data(
            int(ref_n_val), int(cur_n_val), int(seed_val), float(drift_strength_val)
        )
        return _build_compute_response(
            reference,
            current,
            float(alpha_val),
            float(js_val),
            float(psi_val),
            int(bins_val),
        )

    compute_synth.click(
        _compute_synth_handler,
        inputs=[
            ref_n,
            cur_n,
            seed,
            drift_strength,
            alpha,
            js_threshold,
            psi_threshold,
            bins,
        ],
        outputs=[
            metrics_md,
            counts_table,
            feat_filter,
            type_filter,
            test_filter,
            results_table,
            download_csv,
            download_json,
            results_state,
            feature_type_map_state,
            feature_choices_state,
            type_choices_state,
            test_choices_state,
            selected_feature,
            plot,
            reference_state,
            current_state,
        ],
    )

    def _compute_upload_handler(
        ref_file_obj: Any,
        cur_file_obj: Any,
        alpha_val: float,
        js_val: float,
        psi_val: float,
        bins_val: int,
    ):
        if ref_file_obj is None or cur_file_obj is None:
            raise gr.Error("Provide both reference and current CSV files.")
        reference = _read_csv_from_gradio(ref_file_obj)
        current = _read_csv_from_gradio(cur_file_obj)
        return _build_compute_response(
            reference,
            current,
            float(alpha_val),
            float(js_val),
            float(psi_val),
            int(bins_val),
        )

    compute_upload.click(
        _compute_upload_handler,
        inputs=[ref_file, cur_file, alpha, js_threshold, psi_threshold, bins],
        outputs=[
            metrics_md,
            counts_table,
            feat_filter,
            type_filter,
            test_filter,
            results_table,
            download_csv,
            download_json,
            results_state,
            feature_type_map_state,
            feature_choices_state,
            type_choices_state,
            test_choices_state,
            selected_feature,
            plot,
            reference_state,
            current_state,
        ],
    )

    feat_filter.change(
        _on_feat_change,
        inputs=[
            feat_filter,
            feature_type_map_state,
            type_choices_state,
            test_choices_state,
        ],
        outputs=[type_filter, test_filter],
    )
    type_filter.change(
        _on_type_change,
        inputs=[type_filter, test_choices_state],
        outputs=[test_filter],
    )

    def _apply_filters_handler(
        results: Optional[pd.DataFrame], f: List[str], t: List[str], tests: List[str]
    ):
        table_view, csv_path, json_path = _apply_filters(
            results, f or [], t or [], tests or []
        )
        return table_view, csv_path, json_path

    apply_filters.click(
        _apply_filters_handler,
        inputs=[results_state, feat_filter, type_filter, test_filter],
        outputs=[results_table, download_csv, download_json],
    )

    selected_feature.change(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )
    bins.change(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )

    plot_type.change(
        _render_plot,
        inputs=[reference_state, current_state, selected_feature, bins, plot_type],
        outputs=[plot],
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Gradio Drift Monitoring app")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "7860")))
    parser.add_argument("--host", type=str, default=os.environ.get("HOST", "0.0.0.0"))
    args = parser.parse_args()

    os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")

    demo.launch(
        server_name=args.host, server_port=args.port, inbrowser=False, show_error=True
    )


if __name__ == "__main__":
    main()
