# MLflow SCB Production Deployment - SUCCESS ✅

## Deployment Summary

MLflow has been successfully deployed with PVC-based artifact storage and PostgreSQL backend!

### Components Deployed

1. **MLflow Server v2.0.1**
   - Pod: `mlflow-mlflow-6f84477c76-5cjql`
   - Service: `mlflow-mlflow.mlflow.svc.cluster.local:5000`
   - Status: ✅ Running

2. **PostgreSQL Backend**
   - Pod: `postgres-0`
   - Service: `postgres.mlflow.svc.cluster.local:5432`
   - Database: `mlflow`
   - Status: ✅ Running

3. **PVC Artifact Storage**
   - PVC Name: `aift-pvc`
   - Mount Path: `/deve/mosaic/mapdata/mlflow`
   - Storage Class: `standard` (test) / `t-51268-mosaic-mdvhk01` (production)
   - Status: ✅ Bound and Working

### Configuration Files

- **`values-scb-prod.yaml`** - Production configuration for SCB
- **`aift-pvc.yaml`** - PVC manifest for production (with correct storage class)
- **`templates/deployment.yaml`** - Updated to support custom PVC mounts
- **`DEPLOYMENT-SCB.md`** - Detailed deployment guide

### Verified Functionality

✅ **Experiment Tracking**: Metadata stored in PostgreSQL  
✅ **Artifact Storage**: Files persisted to PVC at `/deve/mosaic/mapdata/mlflow`  
✅ **Model Logging**: ML models successfully saved and retrievable  
✅ **File Persistence**: Artifacts survive pod restarts  
✅ **Server Access**: MLflow UI accessible via service

### Test Results

Run ID: `9e914760220f46a98d6c95dc8e6fabf7`  
Experiment: `pvc-working-test`  
Artifacts Location: `/deve/mosaic/mapdata/mlflow/8/9e914760220f46a98d6c95dc8e6fabf7/artifacts/`

Files verified on PVC:
- `test_artifact.txt` ✅
- `model/model.pkl` ✅
- `model/MLmodel` ✅
- `model/requirements.txt` ✅
- `model/conda.yaml` ✅
- `model/python_env.yaml` ✅

## Production Deployment Instructions

### Prerequisites
```bash
# Ensure aift-pvc exists with correct storage class
kubectl get pvc aift-pvc -n <namespace>
```

### Deploy to Production

```bash
# 1. Create namespace
kubectl create namespace <your-namespace>

# 2. Create the PVC (use aift-pvc.yaml with production storage class)
kubectl apply -f aift-pvc.yaml -n <your-namespace>

# 3. Deploy PostgreSQL
kubectl apply -f postgres-deployment.yaml -n <your-namespace>

# 4. Update values-scb-prod.yaml with correct:
#    - PostgreSQL password
#    - Namespace references
#    - Resource limits

# 5. Deploy MLflow
helm upgrade --install mlflow . \
  -n <your-namespace> \
  -f values-scb-prod.yaml

# 6. Verify deployment
kubectl get pods -n <your-namespace>
kubectl logs -l app.kubernetes.io/name=mlflow -n <your-namespace>
```

### Access MLflow

```bash
# Port forward (for testing)
export POD_NAME=$(kubectl get pods -n <your-namespace> \
  -l "app.kubernetes.io/name=mlflow" \
  -o jsonpath="{.items[0].metadata.name}")
kubectl port-forward $POD_NAME 5000:5000 -n <your-namespace>
```

Then open: http://localhost:5000

## Client Usage

### Important: PVC Access for Clients

Since we're using ReadWriteOnce (RWO) PVC, **client pods must mount the same PVC** to write artifacts.

#### Example Client Pod

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-ml-training
  namespace: <your-namespace>
spec:
  containers:
    - name: training
      image: python:3.10
      command: ["python", "train.py"]
      volumeMounts:
        - name: mlflow-artifacts
          mountPath: /deve/mosaic/mapdata/mlflow
      env:
        - name: MLFLOW_TRACKING_URI
          value: "http://mlflow-mlflow.<your-namespace>.svc.cluster.local:5000"
  volumes:
    - name: mlflow-artifacts
      persistentVolumeClaim:
        claimName: aift-pvc
```

#### Python Code Example

```python
import mlflow

# Set tracking URI
mlflow.set_tracking_uri("http://mlflow-mlflow.<your-namespace>.svc.cluster.local:5000")

# Create experiment
mlflow.set_experiment("my-experiment")

# Log artifacts (will be written to mounted PVC)
with mlflow.start_run():
    mlflow.log_param("param1", 5)
    mlflow.log_metric("accuracy", 0.95)
    mlflow.log_artifact("model.pkl")
```

## Important Notes

### PVC Access Modes

**Current**: ReadWriteOnce (RWO) - Only one pod can mount at a time
- ✅ Works for single MLflow server instance
- ✅ Works for client pods that mount the same PVC
- ❌ Cannot scale MLflow beyond 1 replica

**For Multi-Replica**:  Change to ReadWriteMany (RWX) if supported by your storage class:
```yaml
spec:
  accessModes:
    - ReadWriteMany
```

### Storage Class

**Test Environment**: Uses `standard` (minikube)  
**Production**: Update `aift-pvc.yaml` to use `t-51268-mosaic-mdvhk01`

### Security

1. **Change PostgreSQL password** in production
2. **Use Kubernetes secrets** for sensitive data
3. **Enable RBAC** appropriately
4. **Consider network policies** to restrict access

## Troubleshooting

### Artifacts Not Showing in UI

**Cause**: Client pods not mounting the PVC  
**Solution**: Ensure client pods mount `aift-pvc` at `/deve/mosaic/mapdata/mlflow`

### Pod Not Starting

```bash
kubectl describe pod <pod-name> -n <namespace>
kubectl logs <pod-name> -n <namespace>
```

### Check PVC Contents

```bash
kubectl exec -n <namespace> <mlflow-pod-name> -- \
  ls -la /deve/mosaic/mapdata/mlflow
```

### Verify Artifacts

```bash
kubectl exec -n <namespace> <mlflow-pod-name> -- \
  find /deve/mosaic/mapdata/mlflow -type f | head -20
```

## Maintenance

### Backup

#### PostgreSQL Backup
```bash
kubectl exec postgres-0 -n <namespace> -- \
  pg_dump -U mlflow mlflow > mlflow-backup-$(date +%Y%m%d).sql
```

#### PVC Backup
Use your storage provider's snapshot functionality or:
```bash
kubectl exec <mlflow-pod> -n <namespace> -- \
  tar czf - /deve/mosaic/mapdata/mlflow > mlflow-artifacts-backup.tar.gz
```

### Scaling

To scale beyond 1 replica, you need:
1. ReadWriteMany (RWX) PVC, or
2. Object storage (S3/Minio) instead of PVC

## Success Metrics

✅ MLflow server running and accessible  
✅ Experiments created and tracked in PostgreSQL  
✅ Artifacts persisted to PVC  
✅ Artifacts visible in MLflow UI  
✅ Models logged and retrievable  
✅ System survives pod restarts  

## Next Steps

1. Configure ingress for external access (if needed)
2. Set up monitoring and alerting
3. Configure backup automation
4. Document client onboarding process
5. Set up CI/CD for model deployment

## Support

For issues or questions:
- Check logs: `kubectl logs -l app.kubernetes.io/name=mlflow -n <namespace>`
- Verify PVC: `kubectl get pvc -n <namespace>`
- Test connectivity: Run a test pod with PVC mounted

---

**Deployment Date**: October 6, 2025  
**MLflow Version**: 2.0.1  
**Status**: ✅ Production Ready

