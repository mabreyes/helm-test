# SCB Production Deployment Guide

## Overview
This guide covers deploying MLflow in SCB production environment using:
- **Backend Store**: PostgreSQL for metadata
- **Artifact Store**: Existing PVC (aift-pvc) mounted at `/deve/mosaic/mapdata/mlflow`
- **MLflow Version**: 2.0.1

## Prerequisites

1. **Existing PVC**: `aift-pvc` must exist in the target namespace
2. **Postgres**: Ensure PostgreSQL is deployed and accessible
3. **Kubernetes Access**: kubectl configured with appropriate permissions
4. **Namespace**: Target namespace created (e.g., `mlflow`)

## Deployment Steps

### 1. Create Namespace (if not exists)
```bash
kubectl create namespace mlflow
```

### 2. Deploy PostgreSQL (if not already deployed)
```bash
# Apply the postgres deployment manifest
kubectl apply -f - <<EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: postgres-config
  namespace: mlflow
data:
  POSTGRES_DB: mlflow
  POSTGRES_USER: mlflow
  POSTGRES_PASSWORD: <CHANGE_THIS_PASSWORD>
---
apiVersion: v1
kind: Service
metadata:
  name: postgres
  namespace: mlflow
spec:
  ports:
    - port: 5432
  selector:
    app: postgres
  type: ClusterIP
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
  namespace: mlflow
spec:
  serviceName: postgres
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
        - name: postgres
          image: postgres:15-alpine
          ports:
            - containerPort: 5432
          envFrom:
            - configMapRef:
                name: postgres-config
          volumeMounts:
            - name: postgres-storage
              mountPath: /var/lib/postgresql/data
              subPath: postgres
  volumeClaimTemplates:
    - metadata:
        name: postgres-storage
      spec:
        accessModes: ["ReadWriteOnce"]
        storageClassName: t-51268-mosaic-mdvhk01
        resources:
          requests:
            storage: 10Gi
EOF
```

### 3. Update Configuration
Edit `values-scb-prod.yaml` and update the PostgreSQL connection string:
```yaml
mlflow:
  backendStore:
    connectionString: "postgresql://mlflow:<PASSWORD>@postgres.mlflow.svc.cluster.local:5432/mlflow"
```

### 4. Verify PVC Exists
```bash
kubectl get pvc aift-pvc -n mlflow
```

Expected output:
```
NAME       STATUS   VOLUME   CAPACITY   ACCESS MODES   STORAGECLASS
aift-pvc   Bound    ...      ...        RWO/RWX        t-51268-mosaic-mdvhk01
```

### 5. Deploy MLflow
```bash
cd /path/to/scb-mlflow-helm

# Install/Upgrade MLflow
helm upgrade --install mlflow . \
  -n mlflow \
  -f values-scb-prod.yaml
```

### 6. Verify Deployment
```bash
# Check pod status
kubectl get pods -n mlflow

# Check MLflow logs
kubectl logs -l app.kubernetes.io/name=mlflow -n mlflow --tail=50

# Verify artifact storage mount
kubectl exec -l app.kubernetes.io/name=mlflow -n mlflow -- ls -la /deve/mosaic/mapdata/mlflow
```

## Access MLflow UI

### Port Forward (for testing)
```bash
export POD_NAME=$(kubectl get pods --namespace mlflow -l "app.kubernetes.io/name=mlflow,app.kubernetes.io/instance=mlflow" -o jsonpath="{.items[0].metadata.name}")
kubectl --namespace mlflow port-forward $POD_NAME 5000:5000
```

Then access: http://localhost:5000

### Ingress (for production)
1. Update `values-scb-prod.yaml`:
```yaml
ingress:
  enabled: true
  className: "nginx"  # or your ingress class
  hosts:
    - host: mlflow-scb.your-domain.com
      paths:
        - path: /
          pathType: Prefix
```

2. Reapply:
```bash
helm upgrade mlflow . -n mlflow -f values-scb-prod.yaml
```

## Using MLflow

### From Python Client
```python
import mlflow

# Set tracking URI
mlflow.set_tracking_uri("http://mlflow-mlflow.mlflow.svc.cluster.local:5000")

# Or if using ingress
mlflow.set_tracking_uri("http://mlflow-scb.your-domain.com")

# Create experiment and log
mlflow.set_experiment("my-experiment")

with mlflow.start_run():
    mlflow.log_param("param1", 5)
    mlflow.log_metric("metric1", 0.85)
    mlflow.log_artifact("model.pkl")
```

### From Kubernetes Pods
Pods in the same cluster can access MLflow directly:
```python
mlflow.set_tracking_uri("http://mlflow-mlflow.mlflow.svc.cluster.local:5000")
```

## Important Notes

### PVC Access Mode
- If using **ReadWriteOnce (RWO)**: Only one pod can mount the PVC at a time
  - Client pods cannot directly write to PVC
  - Artifacts must go through MLflow server (--serve-artifacts is enabled)
  
- If using **ReadWriteMany (RWX)**: Multiple pods can mount the PVC
  - Clients can mount the same PVC and write directly
  - Better performance for large artifacts

### Artifact Upload
The configuration includes `--serve-artifacts` flag, which means:
- Clients upload artifacts to MLflow server via HTTP
- Server writes artifacts to the PVC
- This works with RWO PVC but has some overhead

### Security Considerations
1. **Change default PostgreSQL password** in production
2. **Enable network policies** to restrict access
3. **Configure RBAC** appropriately
4. **Use secrets** for sensitive data:
```bash
kubectl create secret generic mlflow-db-secret \
  --from-literal=connection-string='postgresql://...' \
  -n mlflow
```

Then reference in values:
```yaml
mlflow:
  backendStore:
    connectionString: ""
  extraEnvFrom:
    - secretRef:
        name: mlflow-db-secret
```

## Troubleshooting

### Pod not starting
```bash
kubectl describe pod -l app.kubernetes.io/name=mlflow -n mlflow
```

### PVC not mounting
```bash
kubectl get pvc aift-pvc -n mlflow
kubectl describe pvc aift-pvc -n mlflow
```

### Check artifact storage
```bash
kubectl exec -l app.kubernetes.io/name=mlflow -n mlflow -- ls -la /deve/mosaic/mapdata/mlflow
```

### View MLflow logs
```bash
kubectl logs -l app.kubernetes.io/name=mlflow -n mlflow -f
```

## Scaling

To enable autoscaling:
```yaml
autoscaling:
  enabled: true
  minReplicas: 2
  maxReplicas: 10
  targetCPUUtilizationPercentage: 70
```

**Note**: With RWO PVC, you cannot scale beyond 1 replica. Use RWX PVC or object storage (S3/Minio) for multi-replica deployments.

## Backup and Recovery

### Backup PostgreSQL
```bash
kubectl exec postgres-0 -n mlflow -- pg_dump -U mlflow mlflow > mlflow-backup.sql
```

### Backup Artifacts (PVC)
Create a backup job or snapshot the PVC through your storage provider.

## Monitoring

Add monitoring annotations:
```yaml
podAnnotations:
  prometheus.io/scrape: "true"
  prometheus.io/port: "5000"
  prometheus.io/path: "/metrics"
```

## Support

For issues or questions, refer to:
- [MLflow Documentation](https://mlflow.org/docs/latest/index.html)
- [Helm Chart Repository](https://github.com/your-org/scb-mlflow-helm)

